// Run PTC Diagnostics
function PTCmainPTCdiagFunc() {
	var rawModem = document.getElementById("PTCmainPTCdiag").value;
	var modem = removeSpaces(rawModem);
    
	if (modem != "0") {
		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		if (pass == "0") {
			$("#launchPasswordSave").modal("show");		
		} else {
			activexactivexwinTab01 = window.open('ptctabs.ptcdiag://' + modem + "_" + pass);
			//activexactivexwinTab01.close();
		}
	} else {
		alert ("Digi Modem number is required !!");
	}
}



// Run Beacon Test
function PTCmainBeaconTestFunc() {
	var rawWMSid = document.getElementById("PTCmainBeaconTest").value;
	var wmsID = removeSpaces(rawWMSid);
	
	if (wmsID != "") {
		var fullWMSid = "7802"+wmsID+document.getElementById("PTCmainWIU_Nbr").value;
		var DC = document.getElementById("PTCmainDataCenter").value; 
                //get password from cookie
		  readCookie("wssm");
		  pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		  if (pass == "0") {
		        $("#launchPasswordSave").modal("show");		

		 
		  } else {
			if (DC == "UPC") {
				activexactivexwinTab02 = window.open('ptctabs.beacontest://' + "UPC" + "_" + fullWMSid + "_" + pass);
				//activexactivexwinTab02.close();
			} else {
				activexactivexwinTab02 = window.open('ptctabs.beacontest://' +  "DEX" + "_" + fullWMSid + "_" + pass);
				//activexactivexwinTab02.close();
			}
		}		
	} else {
		alert ("WMS ID is required !!");
	}
}

// Run Subdivision Query
function PTCmainQuerySubFunc() {
	var rawSub = document.getElementById("PTCmainQuerySub").value;
	var sub = removeSpaces(rawSub);
	
	// get password from cookie
	readCookie("wssm");
	//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
	if (pass == "") {
		$("#launchPasswordSave").modal("show");
	} else {
		if (sub == "") {
			sub = "ALL";
			activexwinTab03 = window.open('ptctabs.querysub://' + sub + "_" + pass);
			//activexwinTab03.close();
		} else {
			activexwinTab03 = window.open('ptctabs.querysub://' +  sub + "_" + pass);
			//activexwinTab03.close();
		}
	}
}

// Convert to HEX w.up.<wms id>.<wiu id>
function PTCconvertHEXFunc() {
	var rawWMSid = document.getElementById("PTCconvertHEX").value;
	var wmsID = removeSpaces(rawWMSid);
	
	var wiuID = "303" + document.getElementById("PTChexWIU_Nbr").value;
	
	if (wmsID != "") {
		
		// Converting ASCII to HEX
		var arr = [];
		for (var n = 0, l = wmsID.length; n < l; n ++) 
		 {
			var hex = Number(wmsID.charCodeAt(n)).toString(16);
			arr.push(hex);
		 }
		wmsID_toHEX = arr.join('');
		
		// Creating final value
		var final_HEX = "772E75702E" + wmsID_toHEX.toUpperCase() + "2E" + wiuID;
		
		// Sending value to textbox
		document.getElementById("PTCconvertedHEX").value = final_HEX;
		
		// Copying value to clipboard
		var copyText = document.getElementById("PTCconvertedHEX");
		
		copyText.select();
		document.execCommand("Copy");
	
		alert ("HEX Value is copied to Clipboard !!");
		
	} else {
		alert ("WMS ID is required !!");
	}
}


// Open loco WinSCP - LOG10E
function PTCopenPTClocoLOG() {
	var loco = removeSpaces(document.getElementById('PTCptcLOCOlog').value);
	
	if (loco != "") {
		activexwinTab04 = window.open('ptctabs.locowinscp://' + loco);
		//activexwinTab04.close();
	} else {
		alert ("LOCO ID is required !!");
	}
}


// Run wayside WSSM Query
function PTCbackWSSMqueryWayFunc() {
	var wmsID = removeSpaces(document.getElementById("PTCbackWSSMqueryWay").value);

	if (wmsID != "") {
		var wmsIDprefix = document.getElementById("PTCwssm_wiu_id_prefix").value;
		var fullWMSid = wmsIDprefix+wmsID+document.getElementById("PTCwssm_wiu_id").value;
		var DC = document.getElementById("PTCmainDataCenter4wayside").value;
		
		var QueryType = document.getElementById("PTCwssm_query_type").value;
		if (QueryType == "u") {
			var QueryHours = "01";
		} else {
			if (removeSpaces(document.getElementById("PTCwssm_type_hrs").value) == "") {
				var QueryHours = "01";
			} else {
				var check_QueryHours = removeSpaces(document.getElementById("PTCwssm_type_hrs").value);
				if (check_QueryHours.length == "1") {
					QueryHours = "0" + check_QueryHours;
				} else {
					QueryHours = check_QueryHours;
				}
			}
		}

		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);

		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			if (DC == "UPC") {
				activexwinTab05 = window.open('ptctabs.queryway://' + "UPC" + "_" + fullWMSid + "_" + QueryType + "_" + QueryHours + "_" + pass);
				//activexwinTab05.close();
			} else {
				activexwinTab05 = window.open('ptctabs.queryway://' + "DEX" + "_" + fullWMSid + "_" + QueryType + "_" + QueryHours + "_" + pass);
				//activexwinTab05.close();
			}
		}		
	} else {
		alert ("WMS ID is required !!");
	}
}



///////////////////////////////// New Functions Added by Vance //////////////////////////////
//console.log()
function ResendOTA() {
	var ATTnumSpaceless = removeSpaces(document.getElementById("resendOTA").value);
	var ATTpass = removeSpaces(document.getElementById("att_eod_pwd").value);
	var ATTnum = removeDashes(ATTnumSpaceless);
	
	if (ATTnum != "") {
		
		if (ATTpass == "") {
	
			alert("Please Enter the EOD password.");
		} else {
			activexwinTab10 = window.open("noctools.resendOTA://" + ATTnum + "_" + ATTpass);
			//activexwinTab10.close();
		}
	} else {
		alert ("SIM or Phone number is required !!");
	}
}

function CellRouterLaunch() {
	var routerName = removeSpaces(document.getElementById("CellRouter").value);
	var tcspassword = removeSpaces(document.getElementById("cell_tcs_pwd").value);

	if (routerName != "") {
		if (tcspassword != "") {
			$("#launchSaveCiscoPassword").modal("show");
		} else {
			alert("Please enter your TCS password.");
		}
	} else {
		alert("Please provide a valid name for the Cell Router being Troubleshooted.");
	}
}

function TroubleshootCellRouter() {
	var routerName = removeSpaces(document.getElementById("CellRouter").value);
	var ciscopass = removeSpaces(document.getElementById("CiscoPassword").value);
	var tcspassword = removeSpaces(document.getElementById("cell_tcs_pwd").value);
	
	if (ciscopass != "") {
		$("#launchSaveCiscoPassword").modal("hide");
		activexwinTab11 = window.open("noctools.troubleshootcell://" + routerName + "_" + ciscopass + "_" + tcspassword);
	} else {
		alert("Please enter the current Cisco password.");
	}
}

function RemoteID() {
	var ControlPoint = removeSpaces(document.getElementById("CPtoID").value);

	if (ControlPoint != "") {
		activexwinTab12 = window.open("noctools.RadioIDlookup://" + ControlPoint);
	} else {
		alert("Please enter a Control Point.");
	}
}

function CompareDeviceConfig() {
	var TestConfigDevice = removeSpaces(document.getElementById("testedDevice").value);
	var vxPassword = removeSpaces(document.getElementById("vx1082_pwd").value);
	
	if (TestConfigDevice != "") {
		if (vxPassword != "") {
			activexwinTab13 = window.open("noctools.TestConfig://" + TestConfigDevice + "_" + vxPassword);
			activexwinTab14 = window.open("G:\\DCOS\\ALL\\NOC\\NOC dashboard\\3.3\\bin\\ConfigReports");
		} else {
			alert("Please enter your vx1082 password.");
		}
	} else {
		alert("Please provide a valid device name you'd like to test.");
	}
}


function QuerySiteTTN() {
	var SiteName = removeSpaces(document.getElementById("TTNsite").value);

	if (SiteName != "") {
		//activexwinTab15 = window.open("noctools.querySiteTTN://" + SiteName);
		//activexwinTab15 = window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/prov/Site_Location.cfm?Action=Show&szMNEM=" + SiteName);
		activexwinTab15 = window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/locations/query_site_locations.cfm?KYWD=" + SiteName.toUpperCase() + "&SABV=&cbSignalSites=True&cbSiteSummary=checked&MNGR=&NonManagerList=icom060%2Cicom095%2Cicom134%2Cicom142&FAC_TYPE_ID=&SIG_FAC_TYPE=&SBDV_NAME=&MP=&NPA=&NXX=&DISP_OPTS=Browser&ScreenSize=&DISP_RCDS=&DISP_FAC_ASET_NBR=&DISP_SITE_CERT=&MTCE_TYPE_ID=&GIS_INFO=ShowIfAvailableDEC&GIS_SRC=&STATUS=ACTIVE&AGCY_KYWD=&flgHF=True&METHOD=Submit");
	} else {
		alert("Please enter the name of the site.");
	}
}





////////////////////////////////////////////////////////////////////////////////////////////

// Query message content with number of messages
function PTCbackWSSMqueryContentFunc() {
	var wmsID = removeSpaces(document.getElementById("PTCbackWSSMqueryContent").value);
	var message_count = removeSpaces(document.getElementById("PTCwssm_latest_number").value);
	//while (message_count.length < 4) {
		//message_count = "0" + message_count;
	//}
	
	if (wmsID != "" && message_count != "") {
		var wmsIDprefix = document.getElementById("PTCwssm_wiu_id_content_prefix").value;
		var fullWMSid = wmsIDprefix+wmsID+document.getElementById("PTCwssm_wiu_id_content").value;
		var DC = document.getElementById("PTCmainDataCenter4waysideContent").value;
		
		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			if (DC == "UPC") {
				//alert ('ptctabs.latemsg://' + "UPC" + "_" + fullWMSid + "_" + message_count + "_" + pass);
				activexwinTab06 = window.open('ptctabs.latemsg://' + "UPC" + "_" + fullWMSid + "_" + message_count + "_" + pass);
				//activexwinTab06.close();
			} else {
				activexwinTab06 = window.open('ptctabs.latemsg://' + "DEX" + "_" + fullWMSid + "_" + message_count + "_" + pass);
				//activexwinTab06.close();
			}
		}		
	} else {
		alert ("WMS ID and Number of Messages are both required !!");
	}
}


// Run Base WSSM Query
function PTCbackWSSMqueryBaseFunc() {
	var radioID = removeSpaces(document.getElementById("PTCbackWSSMqueryBase").value);
	var empADD = removeSpaces(document.getElementById("PTCbackWSSMqueryBaseEMP").value);
	
	if (radioID != "" || empADD != "") {
		var DC = document.getElementById("PTCmainDataCenter4base").value;
		
		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		if (radioID != "") {
			var emp_add = Number(radioID) - 4718591;
		} else {
			var emp_add = empADD;
		}
		
		while (emp_add.toString().length < 6) {
			emp_add = "0"+emp_add;
		}
		
		emp_add = "up.v."+emp_add;	
		
		var QueryType = document.getElementById("PTCwssm_bquery_type").value;
		if (QueryType == "u") {
			var QueryHours = "01";
		} else {
			if (removeSpaces(document.getElementById("PTCwssm_btype_hrs").value) == "") {
				var QueryHours = "01";
			} else {
				var check_QueryHours = removeSpaces(document.getElementById("PTCwssm_btype_hrs").value);
				if (check_QueryHours.length == "1") {
					QueryHours = "0" + check_QueryHours;
				} else {
					QueryHours = check_QueryHours;
				}				
			}
		}


		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			if (DC == "UPC") {
				activexwinTab07 = window.open('ptctabs.querybase://' + "UPC" + "_" + emp_add + "_" + QueryType + "_" + QueryHours + "_" + pass);
				//activexwinTab07.close();
			} else {
				activexwinTab07 = window.open('ptctabs.querybase://' + "DEX" + "_" + emp_add + "_" + QueryType + "_" + QueryHours + "_" + pass);
				//activexwinTab07.close();
			}
		}		
	} else {
		alert ("Radio ID or EMP address is required !!");
	}
}


// Query message content with time frame
function PTCbackWSSMqueryContent2Func() {
	var wmsID = removeSpaces(document.getElementById("PTCbackWSSMqueryContent2").value);
	TIME_FRAME = document.getElementById("WSSMtimeframe").value;
	
	if (wmsID != "" && TIME_FRAME != "") {
		var wmsIDprefix = document.getElementById("PTCwssm_wiu_id_content2_prefix").value;
		var fullWMSid = wmsIDprefix+wmsID+document.getElementById("PTCwssm_wiu_id_content2").value;
		var DC = document.getElementById("PTCmainDataCenter4waysideContent2").value;

		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		TFS = TIME_FRAME.split("-");
		
		EPOCH_FROM = TFS[0].slice(0, -1); // Get rid of space at the end
		EPOCH_TO = TFS[1].substr(1); // Get rid of space at the front
		//EPOCH_FROM = EPOCH_FROM.replace(/\s/g, ''); // deletes all spaces
		//EPOCH_TO = EPOCH_TO.replace(/\s/g, ''); // deletes all spaces
		
		//alert ("'"+EPOCH_FROM+"'");
		//alert ("'"+EPOCH_TO+"'");
		
		if (document.getElementById('WSSMcurrent').checked) {
			if (pass == "") {
				$("#launchPasswordSave").modal("show");		
			} else {
				if (DC == "UPC") {
					//alert ('ptctabs.msg1://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
					activexwinTab08 = window.open('ptctabs.msg1://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
					//activexwinTab08.close();
				} else {
					activexwinTab08 = window.open('ptctabs.msg1://' + "DEX" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
					//activexwinTab08.close();
				}
			}			
		} else {
			if (pass == "") {
				$("#launchPasswordSave").modal("show");		
			} else {
				if (DC == "UPC") {
					//alert ('ptctabs.msg2://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
					activexwinTab09 = window.open('ptctabs.msg2://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
					//activexwinTab09.close();
				} else {
					activexwinTab09 = window.open('ptctabs.msg2://' + "DEX" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
					//activexwinTab09.close();
				}
			}	
		}
	} else {
		alert ("WMS ID and Time Frame are both required");
	}
}

function IPXconfig() {
	$("#launchIPXconfig").modal("show");
}

function GenerateIPXconfig() {
	var ipx = removeSpaces(document.getElementById("IPXname").value);
	var tcspwd = removeSpaces(document.getElementById("ipxTCSpass").value);
	if (ipx != "") {
		if (tcspwd != "") {
			$("#launchIPXconfig").modal("hide");
			//activexwinTab20 = window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/device.cfm?myDevName='+ ipx +'&Action=Show&flgHF=True');
			activexwinTab21 = window.open('noctools.ipxConfig://'+ ipx + '_' + tcspwd);
			//activexwinTab22 = window.open("G:\\DCOS\\ALL\\NOC\\IPX Config Files");
		} else {
			alert("Please enter your TCS password.");
		}
	} else {
		alert("Please enter a valid name for the IPX1000.");
	}
}
