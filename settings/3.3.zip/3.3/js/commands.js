//UPDATES Log
//
// Author: Rick Baden
//
// Contributors: Rick Baden, Vance Keller, Taylor Cook
// Current Maintainer: Taylor Cook
//
//
//
//
//Please record all updates in this section up here, prefaced with the date and followed with your initials.
//
//
// 9/23/20 - Updated Wayside PSM function to match the new PSM Link - TGC
// 9/30/20 - Updated Loco and Base PSM function to matcht he new PSM Link - TGC
//
//
//
//
//
//
//
//
//


// Removing unwanted spaces - use this function by adding - onblur="this.value=removeSpaces(this.value);" to the textbox //
function removeSpaces(string) {
	return string.split(' ').join('');
}

// Removing unwanted dashes - use this function by adding - onblur="this.value=removeDashes(this.value);" to the textbox //
function removeDashes(string) {
	return string.split('-').join('');
}

// Start of IP Dropdown *************************************************************************************

// Change Any IP address to decimal and query that IP
function findanyIP() {
	var rawip = document.getElementById('ipadd').value;
	var ip = removeSpaces(rawip);
	var d = ip.split('.');
	var result = ((((((+d[0]) * 256) + (+d[1])) * 256) + (+d[2])) * 256) + (+d[3]);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/ipAddress.cfm?ipAddress=" + result + "&Action=Show&flgHF=False");
}

// find device or user
function checkDeviceUser() {
	var rawip = document.getElementById('userip').value;
	var rawid = document.getElementById('userid').value;
	var ip = removeSpaces(rawip);
	var id = removeSpaces(rawid);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/show_dns.cfm?flgHF=True&flgDebug=False&flgFirstPost=False&flgHideShow=Hide&device=" + ip + "&hidSubnetAddress=&hidMask=&hidSegmNbr=&UserId=" + id + "&szCustom=Servers&szCustom=PCs&szCustom=Other&radResults=Device&radDNSsource=dns_ttn&IPAlarms=T&tivDetail=Down&Apps=T&SiteScope=None&appKeyword=&cmWizDays=1&cmWizTypes=Unix_Server_Request&cmWizTypes=Novell_Server_Request&cmWizTypes=Win32_Server_Request&cmWizTypes=WebLogic&UserShort=T&cbMAC=T&ButtonPressed=Search#RicolaTab_0_0");
}

// find ping status
function checkPingStatus() {
	var rawmnem = document.getElementById('pingstatus').value;
	var mnem = removeSpaces(rawmnem);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/ping_status.cfm?Mnemonic=" + mnem + "&Segment=&Subnet=&SubnetMask=&SubnetGroup=&OSPFArea=&Device=&Attr1=&Attr2=&Attr3=&Attr4=&StatusUp=true&StatusDown=true&DEV_INFC=true&DHCP_IP_ADDR=true&SRVR_IP_ADDR=true&OTHR_IP_ADDR=true&LastChangeQlfr=Less&Days=&Hours=&Minutes=&SortBy=3&Submit=Submit");
}

// find dhcp IP address
function finddhcpIP() {
	var rawip = document.getElementById('dhcpip').value;
	var ip = removeSpaces(rawip);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_dhcp_stations.cfm?szNAME=&szMAC=&szIP=" + ip + "&szSegm=&szPhNbr=&DEV_TYPE_ID=&flgHideShow=Hide&flgHF=True&ButtonPressed=Search");
}

// find dhcp phone
function finddhcpPhone() {
	var rawphone = document.getElementById('dhcpphone').value;
	var phone = removeSpaces(rawphone);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_dhcp_stations.cfm?szNAME=&szMAC=&szIP=&szSegm=&szPhNbr=" + phone + "&DEV_TYPE_ID=&flgHideShow=Hide&flgHF=True&ButtonPressed=Search");
}

// End of IP Dropdown *************************************************************************************


// Start of AEI Dropdown *************************************************************************************

// check AIE
function checkAEI() {
	var rawid = document.getElementById('aeisitenumber').value;
	var aeisite = rawid.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/aei/query_aei.cfm?SITE=" + aeisite + "&ALRM_STAT=ACTV&ALRM_END_TIME=&ORDR_BY=NEW_OLD&flgHF=True&szPage=1&ButtonPressed=Submit");
}

// find AEI site info
function aeiSiteTrace() {
	var rawid = document.getElementById('aeiSiteTrace').value;
	var aeisite = rawid.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/aei/aei_srch.cfm?AEI_SITE_NBR=" + aeisite + "&ButtonPressed=Submit");
}

// Trace the train
function traceTrain() {
	var rawtrain = document.getElementById('traintrace').value;
	var cleantrain = removeSpaces(rawtrain);
	var train = cleantrain.toUpperCase();
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/AEI_Trace_Train.cfm?TRN_SYMB=" + train + "&EQMT_NAME=&szDaysSearch=144h&szResults=Telecom&flgHideShow=Hide&ButtonPressed=Search");
}

// check CIE
function checkCIE() {
	var rawid = document.getElementById('ciesitenumber').value;
	var ciesite = rawid.split(' ').join('');
	window.open("https://home.www.uprr.com/mdd/cie-monitor-app/secure/jas/siteSummary?siteId=" + ciesite);
}

// find AEI tickets
function ticketTrace() {
	var rawid = document.getElementById('tickettrace').value;
	var aeisite = rawid.split(' ').join('');
	var countIT = aeisite.toString().length;

	if (countIT == 3) {
		aeisite = "0" + aeisite
	}

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var today = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=aei" + aeisite + "&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + today + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

// Trace the Equipment
function traceEquip() {
	var rawequip = document.getElementById('equiptrace').value;
	var cleanequip = removeSpaces(rawequip);
	var equip = cleanequip.toUpperCase();
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/AEI_Trace_Train.cfm?TRN_SYMB=&EQMT_NAME=" + equip + "&szDaysSearch=144h&szResults=Telecom&flgHideShow=Hide&ButtonPressed=Search");
}

// End of AEI Dropdown *************************************************************************************


// Start of Site Dropdown *************************************************************************************

// find MNEM
function findMNEM() {
	var rawmnem = document.getElementById('siteMNEM').value;
	var mnem = rawmnem.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_devices.cfm?szDeviceName=&szDeviceNbr=&szDeviceType=&szDeviceClass=&szRoutingDomain=&VRF_ID=&szMnemonic=" + mnem + "&szWLANSSID=&szSortBy=D.DEV_NAME&szAutomate=&szUserID=&szCircuitProv=&szConsoleInfo=&szDispatchRecords=&szDisplay=Browser&ScreenSize=&szIP=F&szStartsWith=N&szDeviceStatus=SHOW&DEV_TYPE=H,T,A,M&SRVR_TYPE_ID=&SRVR_TYPE_ATTR_ID=&HDW_DEV_TYPE_NAME=&ACCS_PNT_GRP_ID=&ACCS_PNT_GRP_ASSN_TYPE=&MNGR=&szAttr1=&szAttr2=&szAttr3=&szAttr4=&szAttr5=&szAttr6=&szMnemID=");
}

// find Rectifier
function findRECT() {
	var rawrect = document.getElementById('rectMNEM').value;
	var rect = removeSpaces(rawrect);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_devices.cfm?szDeviceName=&szDeviceNbr=&szDeviceType=&szDeviceClass=&szRoutingDomain=&VRF_ID=&szMnemonic=" + rect + "&szWLANSSID=&szSortBy=D.DEV_NAME&szAutomate=&szUserID=&szCircuitProv=&szConsoleInfo=&szDispatchRecords=&szDisplay=Browser&ScreenSize=&szIP=F&szStartsWith=N&szDeviceStatus=&DEV_TYPE=H,T,A,M&SRVR_TYPE_ID=4484&SRVR_TYPE_ATTR_ID=&HDW_DEV_TYPE_NAME=&ACCS_PNT_GRP_ID=&ACCS_PNT_GRP_ASSN_TYPE=&szAttr1=&szAttr2=&szAttr3=&szAttr4=&szAttr5=&szAttr6=&szMnemID=");
}

// find spare device
function findSPARES() {
	var rawspare = document.getElementById('siteSPARES').value;
	var spare = removeSpaces(rawspare);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_devices.cfm?szDeviceName=&&szMnemonic=" + spare + "&szSortBy=D.DEV_NAME&szDisplay=Browser&ScreenSize=1920|1040&szIP=F&szStartsWith=N&szDeviceStatus=SHOW&DEV_TYPE=H,T,A,M&szAttr1=spare&szAttr2=spares");
}

// find PTC Spare WMS 
function findPTCSpare() {
	var rawmnem = document.getElementById('PTCsiteMNEM').value;
	var mnem = rawmnem.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/equipment/spar_srch.cfm?LOCA_KYWD=" + mnem + "&DIST=100&DISP_OPTS=Map&TMPT_ID=12822&ButtonPressed=True");
}

// find Analog Phone
function findAnalog() {
	var rawphone = document.getElementById('analogPhone').value;
	var phone = rawphone.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/prov/span_cost_query.cfm?LSE_ID=" + phone + "&PRIM_VNDR_NAME=&szDT_RNGE=LAST_1&szStartDate=&szEndDate=&szCOST_CLAS_NAME=access&szCOST_CLAS_NAME=port&szCOST_CLAS_NAME=other&szCOST_CLAS_NAME=tax&TYPE_ID=&COST_CODE=&ACCT_CODE=&T_CITY=&T_SABV=&T_MNEM=&COST_DESC_KYWD=&USAG_TYPE=&szType=&AUDT_IND=&GRP_BY=&ORD_BY=Leases&flgHideShow=Hide&flgHF=True&ButtonPressed=Submit");
}

// Query site alarms
function findALARMS() {
	var rawalarms = document.getElementById('siteALARMS').value;
	var site = removeSpaces(rawalarms);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/Show_Alarms.cfm?szCity=" + site);
}

// End of Site Dropdown *************************************************************************************

// Start of Radios Dropdown *************************************************************************************

// Launch VPGate or Frontier Server
function launchRCDserver() {
	var server = document.getElementById('radioServers').value;
	var port = document.getElementById('servertype').value;
	window.open("http://" + server + "/" + port);
}

// Launch Console
function lunchAvtecConsole() {
	var rawString = document.getElementById('consoleAvtec').value;
	var String = removeSpaces(rawString);
	window.open("http://" + String + ":3080");
}

// find Circuit Type
function findCircuit() {
	var rawcircuit = document.getElementById('circuitType').value;
	var circuit = removeSpaces(rawcircuit);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/LW_Data_Sheet.cfm?szCrct_Prfx=&szCrct_Sufx=" + circuit + "&codeline=&szMNEM=&szExpand=N%2CY&flgEngrView=True&szStatus=Active&szSearchType=&flgHideShow=Hide&ButtonPressed=Search&hidOrigSwitchPathSeq=&hidTunnelID=&hidRemoteID=&hidSwitchPathSeq=&hidSwitchPathNbr=&hidIPXaction=&hidIPXcommand=");
}

// find Dispatcher
function findDISP() {
	var raw_dispatcher = document.getElementById('dispNum').value;
	var dispatcher = removeSpaces(raw_dispatcher);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/network/rcd/rcd_dspr_srch.cfm?KYWD=" + dispatcher + "&ASSN_TYPE=&flgHF=True&szPage=1");
}

// find RCD endpoint with server details
function findRCDendpoint() {
	var rawrcd = document.getElementById('rcdendpoint').value;
	var rcd = removeSpaces(rawrcd);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/network/rcd/rcd_epnt_srch.cfm?RCD_EPNT_TYPE_ID=&KYWD=" + rcd + "&RCD_SRVR_ID=&ORDR_BY=RCD_EPNT_NAME&flgHF=True&szPage=1&ButtonPressed=Submit");
}

// End of Radios Dropdown *************************************************************************************

// Start of CTC/SOC Dropdown *************************************************************************************

// find the HBD
function findHBD() {
	var rawhbd = document.getElementById('sochbd').value;
	var hbd = removeSpaces(rawhbd);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/network/query_hotbox.cfm?HBD_CRCT_NAME=" + hbd + "&HBD_SRVR_ID=&HEAD_END_IPX_SEGM_NAME=&HBD_SRVR_UDP_PORT_NBR=&FAR_END_IPX_SEGM_NAME=&flgHF=True&ButtonPressed=Submit");
}

// find the code line
function findCTCcodeline() {
	var rawcode = document.getElementById('CTCcodeline').value;
	var code = removeSpaces(rawcode);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/LW_Data_Sheet.cfm?szCrct_Prfx=&szCrct_Sufx=&codeline=" + code + "&szMNEM=&szExpand=N%2CY&flgEngrView=True&szStatus=&szSearchType=&flgHideShow=Hide&ButtonPressed=Search&hidOrigSwitchPathSeq=&hidTunnelID=&hidRemoteID=&hidSwitchPathSeq=&hidSwitchPathNbr=&hidIPXaction=&hidIPXcommand=");
}

// read the Signal ticket
function readSOCticket() {
	var socraw = document.getElementById('socticket').value;
	var soc1 = removeSpaces(socraw);
	var soc = soc1.toUpperCase();
	//window.open("https://home.www.uprr.com/emp/it/oss/remedy/view_rdy_tckt.cfm?rdy_tckt=" + soc);
	window.open("https://home.www.uprr.com/emp/it/oss/remedy/openticket.cfm?remedyticket=" + soc);
}

// read the Signal ticket - Old one
function readSOCticket_old() {
	var socraw = document.getElementById('socticket').value;
	var soc = removeSpaces(socraw);
	window.open("https://home.www.uprr.com/emp/it/oss/remedy/openticket.cfm?remedyticket=" + soc);
}

// Control Point Map
function findCPsoc() {
	var rawcp = document.getElementById('cpSOC').value;
	var cp = removeSpaces(rawcp);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/GIS/Query_Signal_GIS.cfm?codeline=&cpnbr=" + cp + "&szDisplay=Medium+Map&ScreenSize=&cbNames=T&cbTelecom=T&flgHideShow=Hide&flgHF=True&ButtonPressed=Search");
}

// End of CTC/SOC Dropdown ************************************************************************************


// Start of PTC Dropdown *************************************************************************************

// find PTC Base Device
function findPTCBase() {
	var rawbase = document.getElementById('ptcbasedevice').value;
	var base = rawbase.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_devices.cfm?szDeviceName=&szDeviceNbr=&szDeviceType=5224&szDeviceClass=&szRoutingDomain=&VRF_ID=&szMnemonic=" + base + "&szWLANSSID=&szSortBy=D.DEV_NAME&szAutomate=&szUserID=&szCircuitProv=&szConsoleInfo=&szDispatchRecords=&szDisplay=Browser&ScreenSize=&szIP=F&szStartsWith=N&szDeviceStatus=&DEV_TYPE=H,T,A,M&SRVR_TYPE_ID=&SRVR_TYPE_ATTR_ID=&HDW_DEV_TYPE_NAME=&ACCS_PNT_GRP_ID=&ACCS_PNT_GRP_ASSN_TYPE=&szAttr1=&szAttr2=&szAttr3=&szAttr4=&szAttr5=&szAttr6=&szMnemID=");
}

// find PTC Base Device
function findPTCWayside() {
	var rawwayside = document.getElementById('ptcwaysidedevice').value;
	var wayside = rawwayside.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/vetms/query_wayside_details.cfm?SBDV_NAME=&MNGR_USER_ID=&KYWD=" + wayside + "&PTOTO=&ETOTO=&flgHF=True&szPage=1&ButtonPressed=Submit");
}

// find PTC Wayside Device NMT
function NMTBaseQ() {
	var selectedValue = document.getElementById("NMTBase").value;
	var rawKey = document.getElementById("BaseKey").value;
	var Key = rawKey.split(' ').join('');
	var searchThis;

	if (selectedValue == "mnem") {
		searchThis = "mnemonic=" + Key
	} else {
		searchThis = "rdioid=" + Key
	}

	window.open("https://home.www.uprr.com/emp/it/nmt/secure/base/search_action.cfm?" + searchThis);
}

// open PTC Base or Wayside PSM
function openPSMgui() {
	var entity = document.getElementById('PSMkeyword').value;
	var rawmnem = document.getElementById('PSM_keyword').value;
	var mnem = rawmnem.split(' ').join('');

	if (entity == "base") {
		window.open("https://home.www.uprr.com/obc/ptc_monlogview/index.html#/nmt/secure/home/bases/" + mnem);
	} else {
		window.open("https://home.www.uprr.com/obc/ptc_monlogview/index.html#/nmt/secure/home/waysides/" + mnem);
	}
}

// find PTC Base Device VET
function findPTCBaseVET() {
	var rawbase = document.getElementById('ptcbasedeviceVET').value;
	var rawradio = document.getElementById('ptcbaseradioVET').value;
	var base = rawbase.split(' ').join('');
	var radio = rawradio.split(' ').join('');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/prov/Query_Equipment.cfm?urlRandom=&hidDigitalOnly=False&hidMNEM=&hidLocaID=&szMNEM=" + base + "&ScreenSize=&szMNEMhidden=&szState=&szCity=&szManager=&FAC_TYPE_ID=&SBDV_NAME=&szNodeName=&szDisplay=Browser&ScreenSize=&szClass=&szTemplate=&szUsage=All&szService=Yes&szService=Proposed&szRack_Assn=ALL&szAUDIT_STAT=ALL&szAttrID=3769&szNarrowband=ALL&szFrequency=&PTC_RDIO_ID=" + radio + "&szFCCCallSign=&indFCCDetail=Never&szCrct_Prfx=&flgActiveStatus=true&flgPendingStatus=true&flgHideShow=Hide&flgHF=True&ButtonPressed=Search");
}

// find PTC Wayside Device NMT
function NMTWaysideQ() {
	var selectedValue = document.getElementById("NMTWayside").value;
	var rawKey = document.getElementById("WaysideKey").value;
	var Key = rawKey.split(' ').join('');
	var searchThis;

	if (selectedValue == "mnem") {
		searchThis = "mnemonic=" + Key
	} else if (selectedValue == "wmsid") {
		searchThis = "wmsid=" + Key
	} else {
		searchThis = "rdioid=" + Key
	}

	window.open("https://home.www.uprr.com/emp/it/nmt/secure/wayside/search_action.cfm?" + searchThis);
}

// Query Subs for Waysides
function QuerySub4Waysides() {
	var RAWsubdivision = document.getElementById("SubWaysides").value;
	var subdivision = RAWsubdivision.split(' ').join('+');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/vetms/query_wayside_details.cfm?SBDV_NAME=" + subdivision + "&flgHF=True&szPage=1&ButtonPressed=Submit");
}

// Open HUE browser
function RunHUEtool() {
	window.open("http://prod-hue-phdp001.hdp.tla.uprr.com:8000/accounts/login/");
}

function PTCbackSSHwssm() {
	readCookie("wssm");
	//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
	if (pass == "") {
		$("#launchPasswordSave").modal("show");
	} else {
		commandswinTab01 = window.open('ptctabs.sshwssm://');
		//commandswinTab01.close();
		//WshShell.Run("file:///G:/DCOS/NOC/Sayuj/aei/docs/t2000/ssh_aei.bat " + currentUsername + " " + pass);
	}
}

function PTCbackStopChartFol() {
	commandswinTab01 = window.open('ptctabs.stopfolder://');
	//commandswinTab01.close();
	//WshShell.Run("file:///G:/all/iots297/wssm/weekly%20meetings", 1, false);
}

// End of PTC Dropdown ************************************************************************************


// Start of Vendor Dropdown *************************************************************************************

// Create AT&T ticket
function createATTticket() {
	var ticket = document.getElementById('createatt').value;
	var cleanTicket = removeSpaces(ticket);
	window.open("https://www.cnm.att.com/emfe/QNCreateTicket?reportTbl=0&tblValue=" + cleanTicket + "&stateCodeValue=&serviceidtypeValue=&trunkgrpandmessageValue=&testFocusControlID1=idfield1&tblCktValue=DHEC994429ATI&searchStringForASE=%25DHEC994429ATI%25&oorInd=null&ASEState=null&isASE_ADEinEMDB=&isASE_ADEinEMDBNotProvisioned=&aseflow=&adeflow=&isASEinEBTA=&searchStringForEditForASE=S%3A2%3ADHEC994429ATI&button=&clci=&qnfromscreen=quick+navigate&phone=&isProvForTesting=1&isProvForCCA=1&isProvForIP=0&isProvForPhone=1&fromtransporttfn=yes&transporttfn=&circuit_format=&state=&ccid=&cac=&isValidPhoneForUser=&isPOTSDataFound=&localPhoneInd=&circuitId=");
}

// find lease circuit
function findLease() {
	var circuitraw = document.getElementById('querylease').value;
	var circuitclean = removeSpaces(circuitraw);
	var circuit = circuitclean.toUpperCase();
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/prov/Show_Spans.cfm?szState=&szCity=&szSpan=&szTypeID=&szLocaID=&szCOMS_ID=&szLeaseID=" + circuit + "&flgVendor=1&szMNEM=&flgExcludeICL=False&flgLeaseOnly=True&szStatus=110");
}


// Check AT&T ticket status
function checkATTticket() {
	var ticket = document.getElementById('checkatt').value;
	var cleanTicket = removeSpaces(ticket);
	window.open("https://www.cnm.att.com/emfe/CheckTktStatus?searchType=1&searchVal=" + cleanTicket);
}

// find the company that phone belongs to
function findPhone() {
	var rawstr = document.getElementById('findphone').value;
	var firstclean = rawstr.split(' ').join('');
	var secondclean = firstclean.split('-').join('');
	var areacode = secondclean.slice(0, 3);
	var middlecode = secondclean.slice(3, 6);
	var lastcode = secondclean.slice(6);
	window.open("http://www.fonefinder.net/findome.php?npa=" + areacode + "&nxx=" + middlecode + "&thoublock=" + lastcode + "&usaquerytype=Search+by+Number&cityname=");
}

// End of Vendor Dropdown *************************************************************************************


// Start of Misc Dropdown *************************************************************************************

// find e-com
function findEcom() {
	var rawecom = document.getElementById('ecomnumber').value;
	var ecom = removeSpaces(rawecom);
	window.open("https://home.www.uprr.com/emp/it/telecom/coms/secure/coms2/coms.cfm?Action=Show&COMS_ID=" + ecom + "&flgHF=False");
}

// find e-com with keyword
function findEcomkey() {
	var rawecom = document.getElementById('ecomkeyword').value;
	var ecom = removeSpaces(rawecom);
	window.open("https://home.www.uprr.com/emp/it/telecom/coms/secure/reports/query_coms_keyword.cfm?szKeyword=" + ecom + "&szSRCH=RQTR%2CWQ&szFormLabel=&szStatus=&szSubmit_Date_From=&szSubmit_Date_To=02%2F21%2F2016&szCity=&szState=&szZip=&szCategories=&szSubcategories=&szSortBy=Submit+Date&szPage=1&ButtonPressed=Search");
}

// Check the site when tech checkout
function techCheckout() {
	var rawsite = document.getElementById('outmnem').value;
	var site = removeSpaces(rawsite);
	sitewindow1 = window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=IP_T&szNewAlarms=10m&RefreshTime=120&screenHeight=950&screenWidth=1670&szFontClass=txtsv&szSort1=POLL_TMST%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&szAlarm1=" + site + "&szSuppress=consolidateByTicketDevice&&SHOW_SMRY_FLAG=True")

	sitewindow2 = window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=180&screenHeight=950&screenWidth=1670&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,5&cbSystems=IPX1000-RTU,ABNS,Avtec,PBX,Hump_NOC,PTC-RADIO,PTC-ITCM,PTC-HACC&szAlarm1=" + site + "&&SHOW_SMRY_FLAG=True");

	var siteAlarms = document.getElementById('pingStatusMnem');

	if (siteAlarms.checked == 1) {
		sitewindow3 = window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/ping_status.cfm?Mnemonic=" + site + "&Segment=&Subnet=&SubnetMask=&SubnetGroup=&OSPFArea=&Device=&Attr1=&Attr2=&Attr3=&Attr4=&StatusUp=true&StatusDown=true&DEV_INFC=true&DHCP_IP_ADDR=true&SRVR_IP_ADDR=true&OTHR_IP_ADDR=true&LastChangeQlfr=Less&Days=&Hours=&Minutes=&SortBy=3&Submit=Submit");
	}
}

function close_techCheckout() {
	sitewindow1.close();
	sitewindow2.close();
	var siteAlarms = document.getElementById('pingStatusMnem');

	if (siteAlarms.checked == 1) {
		sitewindow3.close();
	}
}

// find ticket queue
function checkQueue() {
	var rawuserid1 = document.getElementById('ticketqueue').value;
	var rawuserid2 = rawuserid1.split(' ').join('');
	var userid = rawuserid2.toUpperCase();

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var today = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szUSER_ID=&szBEGINNING_OWNER=" + userid + "&szFIRST_CONTACT_ID=&szPROBLEM_CODE=&szCAUSE_ID=&szFIRST_LOCATION_ID=&szPARENT_PROB=&szVENDOR_ID=&szVENDOR_TKT_NO=&szINVENTORY_ID=&szLATA_SERVER=&szCODELINE=&szTRAIN_CAR_ID=&szSUBDIVISION=&szMAC_ADDRESS=&szKEYWORD_DESC=&szSOLUTION=&KYWD_WH=&szSYSTEM_ID=&szCOMPONENT_ID=&szITEM_ID=&szMODULE_ID=&szPROBLEM_TYPE_ID=&szSTART_PROBLEM_ID=&szEND_PROBLEM_ID=&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + today + "&szSTART_OPEN_TIME=&szEND_OPEN_TIME=&szSTART_CLOSE_DATE=&szEND_CLOSE_DATE=&szSTART_CLOSE_TIME=&szEND_CLOSE_TIME=&szMGR_GANG_ID=&szTECH_NAME=&szTECH_ID=&szFIX_DATE=&szRESTORE_DATE=&szSCHED_RESTORE_DATE=&szSCHED_SERV_DATE=&szSEVERITY=&szMILE_POLE=&szMNEMONIC=&szFLX_PRO_VCHR2=&szCITY=&szSTATE=&szSERV_CONTACT_LNAME=&szINTERNAL_TKT=&szDRAWING1=&szLEASED_CKT_ID=&szAPP_NAME=&szGANG_ID=&szAPP_ID=&flgHF=false&szPage=1&ButtonPressed=Submit");
}


// find User
function findUser() {
	var rawuserid = document.getElementById('finduserid').value;
	var cleanuserid = removeSpaces(rawuserid);
	var userid = cleanuserid.toUpperCase();
	window.open("https://home.www.uprr.com/emp/hr/phonebook/secure/employee.cfm?USER_ID=" + userid);
}

// find unclosed tickets
function checkUnclosed() {
	var rawuserid1 = document.getElementById('unclosedtickets').value;
	var rawuserid2 = rawuserid1.split(' ').join('');
	var userid = rawuserid2.toUpperCase();

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var today = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szUSER_ID=&szBEGINNING_OWNER=" + userid + "&szFIRST_CONTACT_ID=&szPROBLEM_CODE=NOT_CLOSED&szCAUSE_ID=&szFIRST_LOCATION_ID=&szPARENT_PROB=&szVENDOR_ID=&szVENDOR_TKT_NO=&szINVENTORY_ID=&szLATA_SERVER=&szCODELINE=&szTRAIN_CAR_ID=&szSUBDIVISION=&szMAC_ADDRESS=&szKEYWORD_DESC=&szSOLUTION=&KYWD_WH=&szSYSTEM_ID=&szCOMPONENT_ID=&szITEM_ID=&szMODULE_ID=&szPROBLEM_TYPE_ID=&szSTART_PROBLEM_ID=&szEND_PROBLEM_ID=&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + today + "&szSTART_OPEN_TIME=&szEND_OPEN_TIME=&szSTART_CLOSE_DATE=&szEND_CLOSE_DATE=&szSTART_CLOSE_TIME=&szEND_CLOSE_TIME=&szMGR_GANG_ID=&szTECH_NAME=&szTECH_ID=&szFIX_DATE=&szRESTORE_DATE=&szSCHED_RESTORE_DATE=&szSCHED_SERV_DATE=&szSEVERITY=&szMILE_POLE=&szMNEMONIC=&szFLX_PRO_VCHR2=&szCITY=&szSTATE=&szSERV_CONTACT_LNAME=&szINTERNAL_TKT=&szDRAWING1=&szLEASED_CKT_ID=&szAPP_NAME=&szGANG_ID=&szAPP_ID=&flgHF=false&szPage=1&ButtonPressed=Submit");
}

// find tech's ticket queue
function checktechQueue() {
	var rawuserid1 = document.getElementById('techticketqueue').value;
	var rawuserid2 = rawuserid1.split(' ').join('');
	var string = rawuserid2.toUpperCase();
	getalpha = string.replace(/\d/g, '');
	getnum = string.match(/\d/g).join([]);

	if (getalpha == '') {
		userid = 'ICOM' + getnum
	} else {
		userid = string
	}

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var today = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?hidREMOTE_USER=&szUSER_ID=&szBEGINNING_OWNER=&szFIRST_CONTACT_ID=&szPROBLEM_CODE=&szCAUSE_ID=&szFIRST_LOCATION_ID=&szPARENT_PROB=&szVENDOR_ID=&szVENDOR_TKT_NO=&szINVENTORY_ID=&szLATA_SERVER=&szCODELINE=&szTRAIN_CAR_ID=&szSUBDIVISION=&szMAC_ADDRESS=&szKEYWORD_DESC=&szSOLUTION=&KYWD_WH=&szSYSTEM_ID=&szCOMPONENT_ID=&szITEM_ID=&szMODULE_ID=&szPROBLEM_TYPE_ID=&szSTART_PROBLEM_ID=&szEND_PROBLEM_ID=&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + today + "&szSTART_OPEN_TIME=&szEND_OPEN_TIME=&szSTART_CLOSE_DATE=&szEND_CLOSE_DATE=&szSTART_CLOSE_TIME=&szEND_CLOSE_TIME=&szMGR_GANG_ID=&szTECH_NAME=&szTECH_ID=" + userid + "&szFIX_DATE=&szRESTORE_DATE=&szSCHED_RESTORE_DATE=&szSCHED_SERV_DATE=&szSEVERITY=&szMILE_POLE=&szMNEMONIC=&szFLX_PRO_VCHR2=&szCITY=&szSTATE=&szSERV_CONTACT_LNAME=&szINTERNAL_TKT=&szDRAWING1=&szLEASED_CKT_ID=&szAPP_NAME=&szGANG_ID=&szAPP_ID=&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function findcmWizard() {
	// TODO write logic that takes you to CMWizard main page if no CMwizard id is entered by user
	var rawWizard = document.getElementById('cmWizard').value;
	var cmWizard = removeSpaces(rawWizard);
	window.open("https://home.www.uprr.com/cmp/secure/jas/change/showchangerequest/" + cmWizard);
}

// Lookup Zebra Device
function ZebraLookup() {
	var rawid = document.getElementById('zebra-device-serial').value;
	var zebraserial = rawid.split(' ').join('');
	if (zebraserial == "") {
		window.open("https://home.www.uprr.com/mas/admin/secure/#/devices/");
	} else {
		window.open("https://home.www.uprr.com/mas/admin/secure/#/device/" + zebraserial);
	}
}

// End of Misc Dropdown *************************************************************************************



// Start of Search Dropdown *************************************************************************************

// Search KM Docs
function searchKMdocs() {
	var keyword = document.getElementById('searchKMdoc').value;
	window.open("https://home.www.uprr.com/knw/secure/index.html#/osg/search/engine?text=" + keyword);
}


function ticketFor2Years() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	yyyyL = yyyy - 1;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=01%2F01%2F" + yyyyL + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketForYear() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketFor3Months() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	// getting date a week ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth() + 1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if (ddL < 10) {
		ddL = '0' + ddL
	}
	if (mmL < 10) {
		mmL = '0' + mmL
	}
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=" + yesterdayIs + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketForMonth() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	var thisMonth = mm + '%2F01%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=" + thisMonth + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketFor7Days() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	// getting date a week ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 7);
	var mmL = yesterday.getMonth() + 1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if (ddL < 10) {
		ddL = '0' + ddL
	}
	if (mmL < 10) {
		mmL = '0' + mmL
	}
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=" + yesterdayIs + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketFor24Hours() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	// getting yesterday's date
	var yesterday = new Date(today);
	yesterday.setDate(dd - 1);
	var mmL = yesterday.getMonth() + 1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if (ddL < 10) {
		ddL = '0' + ddL
	}
	if (mmL < 10) {
		mmL = '0' + mmL
	}
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=" + yesterdayIs + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function ticketForToday() {
	var lata = document.getElementById('searchLata').value;
	var desc = document.getElementById('searchDesc').value;
	var solu = document.getElementById('searchSolu').value;
	var work = document.getElementById('searchWork').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=" + lata + "&szKEYWORD_DESC=" + desc + "&szSOLUTION=" + solu + "&KYWD_WH=" + work + "&szSTART_OPEN_DATE=" + todayIs + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

// End of Search Dropdown ***********************************************************************************


// Save WSSM password
function PTCsaveWSSMpassword() {
	var password = removeSpaces(document.getElementById("PTCmyWSSMpassword").value);
	createCookie("wssm", password);
	$("#launchPasswordSave").modal("hide");
	//alert ("WSSM Password has been saved for this session.");
}

// ************ Main dropdown menu ************

function PTCmainWMSconnectFunc() {
	var useApp = $('input[name="mainApptype"]:checked').val();
	var rawModem = document.getElementById("PTCmainWMSconnect").value;
	var modem = removeSpaces(rawModem);
	if (useApp == "connectZOC") {
		commandswinTab01 = window.open('ptctabs.conzoc://' + modem);
		//commandswinTab01.close();
	} else {
		commandswinTab01 = window.open('ptctabs.conputty://' + modem);
		//commandswinTab01.close();
	}
}

function PTCticketFor3Month() {
	var desc = document.getElementById('PTCsearchDesc').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth() + 1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if (ddL < 10) {
		ddL = '0' + ddL
	}
	if (mmL < 10) {
		mmL = '0' + mmL
	}
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC=" + desc + "&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE=" + yesterdayIs + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");

}

function SearchForTrains() {
	var site = removeSpaces(document.getElementById("PTCmainSIGlocation").value);
	if (site != "") {
		app = window.open('ptctabs.searchfortrains://' + site);
	} else {
		alert('Please enter a valid SIG Location.');
	}
}

function PTCticketForYear() {
	var desc = document.getElementById('PTCsearchDesc').value;

	// getting today's date
	var today = new Date();
	var mm = today.getMonth() + 1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;

	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC=" + desc + "&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE=01%2F01%2F" + yyyy + "&szEND_OPEN_DATE=" + todayIs + "&flgHF=false&szPage=1&ButtonPressed=Submit");
}

function PTCopenEnforcementsResults() {
	window.open("https://home.www.uprr.com/ptc/dashboard/secure/index.html#/brake-enforcements-summary");
}

// ************ Wayside dropdown menu ************

// find PTC Wayside Device NMT
function PTCNMTWaysideQ() {
	var selectedValue = document.getElementById("PTCNMTWayside").value;
	var rawKey = document.getElementById("PTCWaysideKey").value;
	var Key = removeSpaces(rawKey);
	var searchThis;

	if (selectedValue == "mnem") {
		searchThis = "mnemonic=" + Key
	} else if (selectedValue == "wmsid") {
		searchThis = "wmsid=" + Key
	} else {
		searchThis = "rdioid=" + Key
	}

	window.open("https://home.www.uprr.com/emp/it/nmt/secure/wayside/search_action.cfm?" + searchThis);
}
//////////////////////////////////////////////////////////////////////////////////////////////
//Launch function to search for base radio once wayside mnemonic, radio ID, or WMS ID is given.
function FindBaseRadio() {
	$("#launchSaveTCSpassword").modal("show");
}
function SearchForBase() {
	var Value = removeSpaces(document.getElementById("PTCWaysideKey").value);
	var tcsPass = removeSpaces(document.getElementById("ptcTCSpass").value);
	var xtermw = document.getElementById("XtermWcheck");
	if (tcsPass != "") {
		if (Value != "") {
			$("#launchSaveTCSpassword").modal("hide");
			PTCbaseFind = window.open('ptctabs.searchforbase://' + Value + '_' + tcsPass + '_' + xtermw.checked);
		} else {
			alert('Please enter a valid SIG mnemonic, WMS ID, or wayside radio ID.')
		}
	} else {
		alert('Please enter your TCS Password.');
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////
//Launch function to search for base radio once wayside mnemonic, radio ID, or WMS ID is given.
function LaunchBEMtest() {
	$("#launchSaveTCSpasswordBEM").modal("show");
}
function TestBEMAlarms() {
	var tcsPass = removeSpaces(document.getElementById("TCSpassBEM").value);
	if (tcsPass != "") {
		$("#launchSaveTCSpasswordBEM").modal("hide");
		AlarmTest = window.open('ptctabs.testBEMalarms://' + tcsPass);
	} else {
		alert('Please enter your TCS Password.');
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////
// temp Reboot Modem Link
function PTCopenPTCWaysideModemReboot() {
	var rawwayside = document.getElementById('PTCptcwaysidedeviceGUI').value;
	var wayside = removeSpaces(rawwayside);
	window.open("https://home.www.uprr.com/nmt/system-monitor/secure/#/waysides/" + wayside);
}
// open PTC Wayside GUI
function PTCopenPTCWaysideGUI() {
	var rawwayside = document.getElementById('PTCptcwaysidedeviceGUI').value;
	var wayside = removeSpaces(rawwayside);
	window.open("https://home.www.uprr.com/obc/ptc_monlogview/secure/index.html#/nmt/secure/home/waysides/" + wayside);
}

// open PTC ROA
function PTCopenPTCroa() {
	var wmsid = removeSpaces(document.getElementById('PTCptcROA').value);
	window.open("https://home.www.uprr.com/nmt/web/secure/index.html#!/rshc/wms/" + wmsid);
}

// open PTC NMT Map
function PTCgotoMAP() {
	var getId = removeSpaces(document.getElementById('PTCptcMap').value);
	window.open("https://home.www.uprr.com/nmt/web/secure/index.html#!/map/" + getId);
}

// find PTC W Device
function PTCfindPTCWayside() {
	var rawwayside = document.getElementById('PTCptcwaysidedevice').value;
	var wayside = removeSpaces(rawwayside);
	if (wayside.indexOf('.') > -1) {
		PTCfindSIGWayside();
	} else {
		window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/vetms/query_wayside_details.cfm?SBDV_NAME=&MNGR_USER_ID=&KYWD=" + wayside + "&PTOTO=&ETOTO=&flgHF=True&szPage=1&ButtonPressed=Submit");
	}
}

// find VETMS W SIG
function PTCfindSIGWayside() {
	var sig_location = document.getElementById('PTCptcwaysidedevice').value;
	var sig_Wayside = removeSpaces(sig_location);
	if (sig_Wayside != "") {
		newTabWindow01 = window.open('ptctabs.SearchSigVETMS://' + sig_Wayside);
	} else {
		alert("Please enter a valid SIG ID to query through VETMS.");
	}
}


// Query Subs for Waysides
function PTCQuerySub4Waysides() {
	var RAWsubdivision = document.getElementById("PTCSubWaysides").value;
	var subdivision = RAWsubdivision.split(' ').join('+');
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/r2/vetms/query_wayside_details.cfm?SBDV_NAME=" + subdivision + "&flgHF=True&szPage=1&ButtonPressed=Submit");
}



// ************ Base dropdown menu ************

// find PTC Base Device
function PTCfindPTCBase() {
	var rawbase = document.getElementById('PTCptcbasedevice').value;
	var base = removeSpaces(rawbase);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/network/show_devices.cfm?szDeviceName=&szDeviceNbr=&szDeviceType=5224&szDeviceClass=&szRoutingDomain=&VRF_ID=&szMnemonic=" + base + "&szWLANSSID=&szSortBy=D.DEV_NAME&szAutomate=&szUserID=&szCircuitProv=&szConsoleInfo=&szDispatchRecords=&szDisplay=Browser&ScreenSize=&szIP=F&szStartsWith=N&szDeviceStatus=&DEV_TYPE=H,T,A,M&SRVR_TYPE_ID=&SRVR_TYPE_ATTR_ID=&HDW_DEV_TYPE_NAME=&ACCS_PNT_GRP_ID=&ACCS_PNT_GRP_ASSN_TYPE=&szAttr1=&szAttr2=&szAttr3=&szAttr4=&szAttr5=&szAttr6=&szMnemID=");
}

// find PTC Wayside Device NMT
function PTCNMTBaseQ() {
	var selectedValue = document.getElementById("PTCNMTBase").value;
	var rawKey = document.getElementById("PTCBaseKey").value;
	var Key = removeSpaces(rawKey);
	var searchThis;

	if (selectedValue == "mnem") {
		searchThis = "mnemonic=" + Key
	} else {
		searchThis = "rdioid=" + Key
	}

	window.open("https://home.www.uprr.com/emp/it/nmt/secure/base/search_action.cfm?" + searchThis);
}

// open PTC Base GUI
function PTCopenPTCBaseGUI() {
	var rawbase = document.getElementById('PTCptcbasedeviceGUI').value;
	var base = removeSpaces(rawbase);
	window.open("https://home.www.uprr.com/obc/ptc_monlogview/secure/index.html#/nmt/secure/home/bases/" + base);
}

// find PTC Base Device VET
function PTCfindPTCBaseVET() {
	var rawbase = document.getElementById('PTCptcbasedeviceVET').value;
	var rawradio = document.getElementById('PTCptcbaseradioVET').value;
	var base = removeSpaces(rawbase);
	var radio = removeSpaces(rawradio);
	window.open("https://home.www.uprr.com/emp/it/telecom/ttn/secure/prov/Query_Equipment.cfm?urlRandom=&hidDigitalOnly=False&hidMNEM=&hidLocaID=&szMNEM=" + base + "&ScreenSize=&szMNEMhidden=&szState=&szCity=&szManager=&FAC_TYPE_ID=&SBDV_NAME=&szNodeName=&szDisplay=Browser&ScreenSize=&szClass=&szTemplate=&szUsage=All&szService=Yes&szService=Proposed&szRack_Assn=ALL&szAUDIT_STAT=ALL&szAttrID=3769&szNarrowband=ALL&szFrequency=&PTC_RDIO_ID=" + radio + "&szFCCCallSign=&indFCCDetail=Never&szCrct_Prfx=&flgActiveStatus=true&flgPendingStatus=true&flgHideShow=Hide&flgHF=True&ButtonPressed=Search");
}




function getRadio() {
	var raw_emp_add = document.getElementById('emp_add').value;
	var emp_add = removeSpaces(raw_emp_add);
	if (emp_add == '') {
		alert('EMP Address cannot be blank !');
	} else {
		var radio_id = Number(emp_add) + 4718591;
		document.getElementById('radio_id').value = radio_id;
	}
}

function getEMP() {
	var raw_radio_id = document.getElementById('radio_id').value;
	var radio_id = removeSpaces(raw_radio_id);
	if (radio_id == '') {
		alert('Radio ID cannot be blank !');
	} else {
		var emp_add = Number(radio_id) - 4718591;
		while (emp_add.toString().length < 6) {
			emp_add = "0" + emp_add;
		}
		document.getElementById('emp_add').value = "up.v." + emp_add;
	}
}



// ************ Locomotive dropdown menu ************

// open PTC Loco GUI
function PTCopenPTClocoGUI() {
	var loco = removeSpaces(document.getElementById('PTCptcLOCOgui').value).toUpperCase();
	window.open("https://home.www.uprr.com/obc/ptc_monlogview/secure/index.html#/nmt/secure/home/locomotives/" + loco);
}

// Login to Loco
function ptcLocoRLogs() {
	var loco = removeSpaces(document.getElementById('ptcLocoRLogs').value);
	commandswinTab01 = window.open('https://home.www.uprr.com/docs/ui/secure/#/application/NetworkManagementTool?folder=25683ffa-3d89-4e6e-916f-94483c3964e6&hideFolders=&filters=%5B%7B"key":"search-term","type":"String","not":false,"operation":"equals","value":"' + loco + '"%7D%5D&show=%5B%5D&sort=Last%20Updated%20(Newest)');
	//commandswinTab01.close();
}

// Loco ITCM Broker Restart
function PTCopenPTClocoITCM() {
	var loco = removeSpaces(document.getElementById('PTCptcLOCOITCM').value);
	commandswinTab01 = window.open('ptctabs.locoITCMrestart://' + loco);
	//commandswinTab01.close();
}

function PTClocoInitResults() {
	window.open("http://vw1901/AmoReports/Pages/Report.aspx?ItemPath=%2fUser+Reports%2fRSHC+Initialization+Results+-+All#");
}

// ************ Back office dropdown menu ************

function PTCbackHUEtool() {
	//alert ("Data has been copied to clipboard. You can paste it in HUE tool now.");
	window.open("http://prod-hue-phdp001.hdp.tla.uprr.com:8000/beeswax/");
}

function PTCbackStopChartFol() {
	commandswinTab01 = window.open('ptctabs.stopfolder://');
	//commandswinTab01.close();
}


// ************ EOTR dropdown menu ************

// open PTC EOTR tool
function PTCopenEOTRtool() {
	var raweotr = document.getElementById('PTCeotrID').value;
	var eotrid = removeSpaces(raweotr);
	commandswinTab01 = window.open('ptctabs.eotrtool://' + eotrid);
}



// ************ Commands dropdown menu ************

function runCommand4Putty() {
	$("#commandTDzoc1").hide();
	$("#commandTDzoc2").hide();
	$("#commandTDzoc3").hide();
	$("#commandTDzoc4").hide();
	$("#commandTDputty1").show();
	$("#commandTDputty2").show();
	$("#commandTDputty3").show();
	$("#commandTDputty4").show();
}

function runCommand4Zoc() {
	$("#commandTDzoc1").show();
	$("#commandTDzoc2").show();
	$("#commandTDzoc3").show();
	$("#commandTDzoc4").show();
	$("#commandTDputty1").hide();
	$("#commandTDputty2").hide();
	$("#commandTDputty3").hide();
	$("#commandTDputty4").hide();
}


// ************************ Cookie Function ************************

// Creating Cookie

function createCookie(name, value)		//WSSM:	name is "wssm"	value is [password]
{
	var expires = "";
	document.cookie = name + "=" + value + ";" + expires + "; path=/";
	alert('Cookies are currently incompatible with Chrome.\nYour password will remain in this pop-up until the browser is refreshed.');
}

// Read Cookie
function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');

	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1); //delete spaces
		}
		if (c.indexOf(nameEQ) == 0) {
			pass = c.substring(nameEQ.length, c.length);
		} else {
			pass = "";
		}
	}
	//alert (pass);
}


/*
//TEST CHROME COOKIES (Still failing)
function createCookie(name, value)		//WSSM:	name is "wssm"	value is [password]
{
	var expires = new Date();
	expires.setTime( expires.getTime()+(100*60*60*24*100) );
		document.cookie = name + "=" + value + ";" + ((expires==null) ? "" :  ";expires=" + expires.toGMTString());	//	"wssm=UPRR123;; path=/"
		alert (document.cookie);	// wssm=UPRR0536
}


function readCookie(name)
{
	var cookieName = name + "="
		  var docCookie = document.cookie
		  var cookieStart
		  var end

		  if (docCookie.length>0) {
			cookieStart = docCookie.indexOf(cookieName)
			if (cookieStart != -1) {
			  cookieStart = cookieStart + cookieName.length
			  end = docCookie.indexOf(";",cookieStart)
			  if (end == -1) {
				end = docCookie.length
			  }
			  return unescape(docCookie.substring(cookieStart,end))
			}
	}
		  return false

}
*/


function checkToggle() {
	$('#launchForm input').iCheck('toggle');
}
// end of launch side menu


// Cisco Topics
function runCiscoTopics() {
	window.open('http://cisco.sayujzworld.com', '_blank');
	//logMeIn("ciscoGuide");
}

// NOC Topics
function runNOCtopics() {
	window.open('G:/DCOS/ALL/NOC/NOC dashboard/3.3/Markdown.md', '_blank');
	//logMeIn("nocGuide");
}

// Script for Launch left side menu
function launch() {
	var myup = document.getElementById('myup');
	var ttnIs = document.getElementById('ttnIs');
	var pemMap = document.getElementById('pemMap');

	var ip = document.getElementById('ip');
	var badger = document.getElementById('badger');
	var badger_wzoPTC = document.getElementById('badger_wzoPTC');
	var ptc = document.getElementById('ptc');
	var entry = document.getElementById('entry');
	var aei = document.getElementById('aei');

	var ip_n = document.getElementById('ip_n');
	var badger_n_ = document.getElementById('badger_n');
	var badger_n_wzoPTC = document.getElementById('badger_n_wzoPTC');
	var ptc_n = document.getElementById('ptc_n');

	$("#launchModal_N").modal("hide");

	if (myup.checked == 1) {
		window.open('https://home.www.uprr.com/myup', '_blank');
	}
	if (ttnIs.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/index.cfm', '_blank');
	}
	if (pemMap.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/GIS/up_map.cfm?calcWidth=1572&calcHeight=805', '_blank');
	}
	if (ip.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=IP_T&szNewAlarms=10m&RefreshTime=120&screenHeight=950&screenWidth=1670&szFontClass=txtsv&szSort1=POLL_TMST%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&szSuppress=suppressHeadEndTunnelAlarms,suppressTicketedL2Children,suppressPTCnonRootCause,consolidateByTicketDevice&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (badger.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1910&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=IPX1000-RTU,AMNET,Avtec,PBX,Hump_NOC,RCL,RDY_TRM,IPNET,BREEZE&szSuppress=alwaysShowDegradationBelow,suppressEntry,suppressDegradationTrendingSame&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (badger_wzoPTC.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1910&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=IPX1000-RTU,AMNET,Avtec,PBX,Hump_NOC,PTC-RADIO,PTC-ITCM,PTC-HACC,PTC-ITCR,RCL,RDY_TRM,IPNET,PTC-LCM,EOT&szSuppress=alwaysShowDegradationBelow,suppressEntry,suppressDegradationTrendingSame&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (ptc.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1670&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=PTC-RADIO,PTC-ITCM,PTC-HACC,PTC-ITCR,RDY_TRM,IPNET,PTC-LCM,EOT&szSuppress=alwaysShowDegradationBelow,suppressEntry&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (entry.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szSort1=tiv_date_reception DESC&szAlarm1=MAINTAINER,ENTRY,"MTR PRES"&RefreshTime=180&screenHeight=950&screenWidth=1670', '_blank');
	}
	if (aei.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=AEI_T&szSort1=tiv_date_reception DESC&RefreshTime=180&screenHeight=950&screenWidth=1670', '_blank');
	}
	if (ip_n.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=IP_T&szNewAlarms=10m&RefreshTime=120&screenHeight=950&screenWidth=1670&szFontClass=txtsv&szSort1=POLL_TMST%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&szAlarm1=-update&szSuppress=suppressAssigned,suppressTicketed,suppressHeadEndTunnelAlarms,suppressTicketedL2Children,suppressPTCnonRootCause,consolidateByTicketDevice&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (badger_n.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1670&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=IPX1000-RTU,AMNET,Avtec,PBX,Hump_NOC,PTC-RADIO,PTC-ITCM,PTC-HACC,PTC-ITCR,RCL,RDY_TRM,IPNET,PTC-LCM,EOT&szSuppress=suppressAssigned,suppressTicketed,suppressEntry&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (badger_n_wzoPTC.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1670&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=IPX1000-RTU,AMNET,Avtec,PBX,Hump_NOC,RCL,RDY_TRM,IPNET,BREEZE&szSuppress=suppressAssigned,suppressTicketed,suppressEntry&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}
	if (ptc_n.checked == 1) {
		window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/PEM/PEM_AAD.cfm?system=Badger_T&szNewAlarms=10m&RefreshTime=60&screenHeight=980&screenWidth=1670&szFontClass=txtsv&szSort1=tiv_date_reception%20DESC&szSignalDesk=&cbSeverity=0,1,2,3,4,5&cbSystems=PTC-RADIO,PTC-ITCM,PTC-HACC,PTC-ITCR,RDY_TRM,IPNET,PTC-LCM,EOT&szSuppress=suppressAssigned,suppressTicketed,suppressEntry&degradationPercentage=70&&SHOW_SMRY_FLAG=True', '_blank');
	}

}

function disabledIT() {
	alert("Function has been disabled due to ActiveX Dependency !!");
}

// Copy text
function CopyText() {
	var copyText = document.getElementById("PTCcmdline");

	copyText.select();
	document.execCommand("Copy");

	var showResult = document.getElementById("hiddenResult");
	showResult.innerHTML = "Copied to Clipboard";
}

function cleanHiddenResult() {
	var showResult = document.getElementById("hiddenResult");
	showResult.innerHTML = "";
}













