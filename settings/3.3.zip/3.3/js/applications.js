// all lines containing "applicationwinTab##.close()"" have been commented out in order to
// be compatible with google chrome.  Chrome will execute the .close() command too quickly,
// preventing the window from opening the associated URL in the line above it.
// If anything goes wrong in either Internet Explorer or Google Chrome, after these lines
// are commented out, simply remove the comment slashes for the function that's failing.

// Start of .HTA to run Tool Apps
function RunFccui() {
	applicationwinTab01 = applicationwinTab01 = window.open('nocapp.fccui://');
	//applicationwinTab01.close();
}

function RunSwitcher() {
	applicationwinTab01 = applicationwinTab01 = window.open('nocapp.ipxswitch://');
	//applicationwinTab01.close();
}

function RunFilezilla() {
	applicationwinTab01 = applicationwinTab01 = window.open('nocapp.filezilla://');
	//applicationwinTab01.close();
}

function RunInfiniStream() {
	applicationwinTab01 = window.open('nocapp.infstream://');
	//applicationwinTab01.close();
}

function RunPutty() {
	applicationwinTab01 = window.open('nocapp.putty://');
	//applicationwinTab01.close();
}

function RunNetScout() {
	applicationwinTab01 = window.open('nocapp.netconsole://');
	//applicationwinTab01.close();
}

function PTCRadio() {
	applicationwinTab01 = window.open('ptcapp.xtermw://');
	//applicationwinTab01.close();
}

function PTCLoco() {
	applicationwinTab01 = window.open('ptcapp.slot10://');
	//applicationwinTab01.close();
}

function RunTunnelRadio() {
	applicationwinTab01 = window.open('nocapp.tunradio://');
	//applicationwinTab01.close();
}

function RunMsgUtil() {
	applicationwinTab01 = window.open('nocapp.mutil://');
	//applicationwinTab01.close();
}

function RunPingLife() {
	applicationwinTab01 = window.open('nocapp.ping4life://');
	//applicationwinTab01.close();
}

function RunPingPlotter() {
	applicationwinTab01 = window.open('nocapp.pingplotter://');
	//applicationwinTab01.close();
}

function RunMessageInjector() {
	applicationwinTab01 = window.open('nocapp.atcsinject://');
	//applicationwinTab01.close();
}

function RunPNMTj() {
	applicationwinTab01 = window.open('nocapp.necpnmtj://');
	//applicationwinTab01.close();
}

function RunSitemon() {
	applicationwinTab01 = window.open('nocapp.sitemon://');
	//applicationwinTab01.close();
}

function RunAceManager() {
	applicationwinTab01 = window.open('nocapp.acem://');
	//applicationwinTab01.close();
}

function RunZOC() {
	applicationwinTab01 = window.open('nocapp.zoc://');
	//applicationwinTab01.close();
}

function RunTagConverter() {
	applicationwinTab01 = window.open('nocapp.tagconv://');
	//applicationwinTab01.close();
}

function RunLotusNotes() {
	applicationwinTab01 = window.open('nocapp.notes://');
	//applicationwinTab01.close();
}

function RunAgentPlus() {
	applicationwinTab01 = window.open('nocapp.agentp://');
	//applicationwinTab01.close();
}

function RunAvayaOneX() {
	applicationwinTab01 = window.open('nocapp.avaya://');
	//applicationwinTab01.close();
}

function RunOmni() {
	applicationwinTab01 = window.open('nocapp.omni://');
	//applicationwinTab01.close();
}

function RunSecurity() {
	applicationwinTab01 = window.open('nocapp.secdesk://');
	//applicationwinTab01.close();
	window.open('http://wiki.www.uprr.com/confluence/download/attachments/94733736/Wiki_Camera_Systems.xlsx', '_blank');
}

function RunSiteManager() {
	applicationwinTab01 = window.open('nocapp.sitem://');
	//applicationwinTab01.close();
}

function cardmgmttool() {
	window.open('ptcapp.cardmgmt://');
}

function RunPTCdiag() {
	applicationwinTab01 = window.open('ptcapp.ptcdiag://');
	//applicationwinTab01.close();
}

//function RunPTCEnfTool() {
//applicationwinTab01 = window.open('nocapp.ptcenftool://');
//applicationwinTab01.close();  
//}
function ptcenftool() {
	window.open('nocapp.ptcenftool://');
}

function RunPTCWSSMTool() {
	applicationwinTab01 = window.open('nocapp.ptcWSSMtool://');
	//applicationwinTab01.close();
}

function RunLMSTOOL() {
	applicationwinTab01 = window.open('nocapp.RunLMSTOOL://');
	//applicationwinTab01.close();
}

function RunLocoRadioLogs() {
	applicationwinTab01 = window.open('ptcapp.radiotool://');
	//applicationwinTab01.close();
}
function RunXITCSTool() {
	applicationwinTab01 = window.open('ptcapp.xitcstool://');
	//applicationwinTab01.close();
}

function RunWMSConfigTool() {
	applicationwinTab01 = window.open('ptcapp.WMSConfigtool://');
	//applicationwinTab01.close();
}

function RunDropConfig() {
	applicationwinTab01 = window.open('noctools.upconfig://');
	//applicationwinTab01.close();
}

function Run2800to2900Config() {
	applicationwinTab01 = window.open('noctools.2800to2900://');
	//applicationwinTab01.close();
}


// End of .HTA to run Tool Apps


// Add Context Menu
function addContextMenu() {
	applicationwinTab01 = window.open('noctools.iecontext://');
	//applicationwinTab01.close();
}

// Install NOC Protocol
//function installNOCprotocol() {
//	window.open('file://G:/DCOS/ALL/NOC/NOC dashboard/3.3/bin/pluggable_protocols/UriProtocol.bat');
//}


function installNOCprotocol() {
	applicationwinTab01 = window.open('nocdashboard.installNOCprotocol://');
	//applicationwinTab01.close();
}

function updateNocDashboard() {
	applicationwinTab01 = window.open('nocdashboard.updateNocDashboard://')
}

function SetupPythonEnv() {
	applicationwinTab01 = window.open('nocdashboard.setuppyenv://')
}

// Sets up Python Virtual Environments
function SetupPythonVirtualEnv() {
	applicationwinTab01 = window.open('nocdashboard.setuppyvirtenv://');
	//applicationwinTab01.close();
}



function UpdateZOC() {
	//window.open('file://G:/DCOS/ALL/NOC/NOC dashboard/3.2/bin/pluggable_protocols/Bat_File/ZOC_NOC_COPY.bat');
	activexwinTab16 = window.open('noctools.UpdateZOC://');
}

// Remote in to Avtec
function avtecRemote() {
	var rawString = document.getElementById('consoleAvtec').value;
	var avtec = removeSpaces(rawString);
	window.open('file://G:/DCOS/NOC/NOC dashboard/3.3/bin/avtecRemote.bat' + ' ' + avtec);
}

// Update PNMTj password
function changePNMTjPassword() {
	applicationwinTab01 = window.open('noctools.pnmtj://');
	//applicationwinTab01.close();
}


// Update KML file
function UpdateKML() {
	applicationwinTab01 = window.open('noctools.google://');
	//applicationwinTab01.close();
}


// Open NOC Toolbox
function openNOCtoolbox() {
	applicationwinTab01 = window.open('noctools.nocbox://');
	//applicationwinTab01.close();
}

// Update Time Zones
function UpdateTimeZones() {
	applicationwinTab01 = window.open('noctools.UpdateTimeZones://');
	//applicationwinTab01.close();
}

//3.3 UPDATED
// Generates Cisco Device Config when changing to new model
function RunCiscoConfigGen() {
	applicationwinTab01 = window.open('noctools.CiscoConfigGen://');
	//applicationwinTab01.close();
}

// Find password in Cisco or NetVanta Device via AUX
function RunFindPwdAux() {
	applicationwinTab01 = window.open('noctools.findpassaux://');
	//applicationwinTab01.close();
}

//3.3 UPDATED
// FXE tool to change router to FXE Mexico
function FMexTool() {
	applicationwinTab01 = window.open('noctools.changefxe://');
	//applicationwinTab01.close();
}

// Upload NetV Config
function RunNetVCon() {
	applicationwinTab01 = window.open('noctools.upnetvconfig://');
	//applicationwinTab01.close();
}

function accesstool() {
	window.open('nocapp.accesstool://');
}



