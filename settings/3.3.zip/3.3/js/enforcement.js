ENF_DATE_UTC = 0;
ENF_TIME_UTC = 0;
ENF_DATE_CDT = 0;
ENF_TIME_CDT = 0;

WIU_ID = 0;
WMS_ID = 0;
WIU_NBR = 0;
LEAD_UNIT = 0;
SITE_MNEM = "";
IP_ADD = 0;
TCS_USR = "";
TCS_PWD = "";

function get_wms_radiologs() {
	// extract the user entered data
	ENF_DATE_UTC = removeSpaces(document.getElementById('enf_date_utc').value);
	ENF_TIME_UTC = removeSpaces(document.getElementById('enf_time_utc').value);
	ENF_SITE_MNEM = removeSpaces(document.getElementById('enf_site_mnem').value).toUpperCase();
	
	// Validation
	if (ENF_DATE_UTC == "" || ENF_TIME_UTC == "" || ENF_SITE_MNEM == "") {
		alert ("Some data are left blank. Please enter all data !!");
	}  else {
			//WMS_ID = WIU_ID.slice(4,10); // calculate wms_id
			//WIU_NBR = WIU_ID.slice(10); // calculate wiu_nbr

			// call python script with TCS password (first argument) and ext_link (second argument)
			enfwinTab01 = window.open('nocapp.getwmsrlog://' + ENF_SITE_MNEM + "_" + ENF_DATE_UTC + "_" + ENF_TIME_UTC);
			//enfwinTab01.close();
	}
}


// else if (!moment(ENF_DATE_UTC,'MM/DD/YYYY',true).isValid()) {
//	alert ("Wrong Enforcement Date Format !!");
//} else if (!moment(ENF_TIME_UTC,'HH:mm',true).isValid()) {
//	alert ("Wrong Enforcement Time Format !!");
//} else {
//	if (isNaN(ENF_SITE_MNEM)) {
//		alert ("WMS Site Mnemonic is not valid !!");
//	} else if (ENF_SITE_MNEM.toString().length != 13) {
//		alert ("WMS Site Mnemonic should be 13 digits !!");
//	} -->

function enf_load_data() {
	
	// load the data resulted from python script
	$.getScript("H:/noc_dashboard/enf_data/enf_data.js");
	
	// var script = document.createElement('script');
	
	// script.onload = function () {
		// ************************ Inserting Values ******************************************************
		document.getElementById("enfMnem").innerHTML = enf_exData[0];
		document.getElementById("enfSub").innerHTML = enf_exData[1];
		document.getElementById("enfMP").innerHTML = enf_exData[2];
		document.getElementById("enfEcom").innerHTML = enf_exData[3];
		document.getElementById("enfID").innerHTML = enf_exData[4];
		document.getElementById("enfPhone").innerHTML = enf_exData[5];
		document.getElementById("enfIPadd").innerHTML = enf_exData[6];
		document.getElementById("enfESR").innerHTML = enf_exData[7];
		document.getElementById("enfStat1").innerHTML = enf_exData[8];
		document.getElementById("enfPTOTO").innerHTML = enf_exData[9];
		document.getElementById("enfETOTO").innerHTML = enf_exData[10];
		document.getElementById("enfRadioID").innerHTML = enf_exData[11];
		document.getElementById("enfStat2").innerHTML = enf_exData[12];
		
		//Reassigning values again from external javascript just in case page gets refreshed and lose the user entered data
		ENF_DATE_UTC = enf_exData[15];
		ENF_TIME_UTC = enf_exData[16];
		LEAD_UNIT = enf_exData[17].toUpperCase();
		WIU_ID = enf_exData[18];
		SITE_MNEM = enf_exData[0];
		
		WMS_ID = WIU_ID.slice(4,10); // calculate wms_id
		WIU_NBR = WIU_ID.slice(10); // calculate wiu_nbr
		
		
		$("#handleEnforcement").modal()
	// };
	
	// script.src = "H:/enf_data/enf_data.js";
	// document.head.appendChild(script);

	// changing UTC to CDT
	var result_CDT = moment.utc(ENF_DATE_UTC + ' ' + ENF_TIME_UTC, "YYYY-MM-DD HH:mm:ss").tz("America/Chicago").format("YYYY-MM-DD HH:mm:ss");
	
	var CDT = result_CDT.split(" "); // split the result to get date and time
	
	ENF_DATE_CDT = CDT[0]; // set the date in CDT
	ENF_TIME_CDT = CDT[1]; // set the time in CDT

	// Insert Texts
	document.getElementById('enf_heading').innerHTML = "PTC - Enforcement &nbsp;&nbsp; [ &nbsp; Enf. Date (UTC) : " + ENF_DATE_UTC + "&nbsp;&nbsp; | &nbsp;&nbsp;Enf. Time (UTC) : " + ENF_TIME_UTC + "&nbsp;&nbsp; | &nbsp;&nbsp;Enf. Date (CDT) : " + ENF_DATE_CDT + "&nbsp;&nbsp; | &nbsp;&nbsp;Enf. Time (CDT) : " + ENF_TIME_CDT + " &nbsp; ]";
	
	document.getElementById('enf1').innerHTML = "Make Connections (WMS ID: " + WMS_ID + " | Loco: " + LEAD_UNIT + ")";
	document.getElementById('enf2').innerHTML = "Check Existing Ticket/Defect (WMS ID: " + WMS_ID + " | Radio ID: " + enf_exData[11] + " | Loco: " + LEAD_UNIT + ")";
	document.getElementById('enf3').innerHTML = "PTC Diagnostics Script (" + WIU_ID + ")";
	document.getElementById('enf4').innerHTML = "WIU ID No - " + WIU_ID + " &nbsp;&nbsp;&nbsp;";
	document.getElementById('enf5').innerHTML = "WIU ID No - " + WIU_ID + " &nbsp;&nbsp;";
	document.getElementById('enf7').innerHTML = "Locomotive Diagnostics (" + LEAD_UNIT + ")";
	document.getElementById('enf8').innerHTML = "Locomotive Log (" + LEAD_UNIT + ")";
		
	// hour before and after the enforcement
	m = moment(ENF_TIME_UTC, "HH:mm:ss");
	sub_hour = m.subtract(1, 'hour').format("HH:mm:ss");
	add_hour = m.add(2, 'hour').format("HH:mm:ss");
	
	mu = moment(ENF_TIME_UTC, "HH:mm:ss");
	sub_15min = mu.subtract(15, 'minutes').format("HH:mm:ss");
	add_10min = mu.add(25, 'minutes').format("HH:mm:ss");
	
	// hour before and after the enforcement in CDT
	mc = moment(ENF_TIME_CDT, "HH:mm:ss");
	sub_hourc = mc.subtract(1, 'hour').format("HH:mm:ss");
	add_hourc = mc.add(2, 'hour').format("HH:mm:ss");
	
	document.getElementById('WSSMtimeframe_enf').value = moment(ENF_DATE_CDT).format("MM/DD/YYYY") + " " + moment(sub_hourc, "h:mm A").format("h:mm A") + " - " + moment(ENF_DATE_CDT).format("MM/DD/YYYY") + " " + moment(add_hourc, "h:mm A").format("h:mm A");
	
	document.getElementById('hue_status_message').value = 
	"set WIU = '" + WIU_ID + "';" + "\n" +
	"set UTC_dateEnforcement = '" + ENF_DATE_UTC + "';" + "\n" +
	"set UTC_timeBegin = '" + sub_15min + "';" + "\n" +
	"set UTC_timeEnd = '" + add_10min + "';" + "\n" +
	"set tez.queue.name=NOC;" + "\n" +
	"select * from" + "\n" +
	"(" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id,log_date,seq_nbr,vit_ttl_flag,cast(diff_base_vit_tm as string)" + "\n" +
	"from prptc.ptc_emp_5100_vw where log_date = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"union all" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''" + "\n" +
	"from prptc.ptc_emp_5200_vw  where log_date = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"union all" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''" + "\n" +
	"from prptc.ptc_emp_2500_vw where log_date = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"union all" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''" + "\n" +
	"from prptc.ptc_emp_2501_vw  where log_date  = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"union all" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''" + "\n" +
	"from prptc.ptc_emp_1500_vw  where log_date = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"union all" + "\n" +
	"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''" + "\n" +
	"from prptc.ptc_emp_1501_vw  where log_date = ${hiveconf:UTC_dateEnforcement} ) brk_evnt" + "\n" +
	"where brk_evnt.LOG_DATE = ${hiveconf:UTC_dateEnforcement}" + "\n" +
	"and brk_evnt.WIU_ID = ${hiveconf:WIU}" + "\n" +
	"and brk_evnt.TS_UTC >= CONCAT(${hiveconf:UTC_dateEnforcement}, ' ', ${hiveconf:UTC_timeBegin})" + "\n" +
	"and brk_evnt.TS_UTC <= CONCAT(${hiveconf:UTC_dateEnforcement}, ' ', ${hiveconf:UTC_timeEnd})" + "\n" +
	"order by brk_evnt.ts_utc"

	
	if (LEAD_UNIT.indexOf('UP') != -1) {
		document.getElementById('hue_route_map').value = 
		"set LOCO_ID = '" + String(LEAD_UNIT).substr(2,4) + "';" + "\n" +
		"set UTC_date = '" + ENF_DATE_UTC + "';" + "\n" +
		"set UTC_timeBegin = '" + sub_hour + "';" + "\n" +
		"set UTC_timeEnd = '" + add_hour + "';" + "\n" +
		"set tez.queue.name=NOC;" + "\n" +
		"" + "\n" +
		"select * from prptc.ptc_emp_7102_vw x"  + "\n" +
		"where x.log_date = ${hiveconf:UTC_date}" + "\n" +
		"and x.TS_UTC >= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeBegin})"  + "\n" +
		"and x.TS_UTC <= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeEnd})"  + "\n" +
		"and tnu_aset_typ = 'l'" + "\n" +
		"and tnu_aset_id = CONCAT('up+', ${hiveconf:LOCO_ID})"  + "\n" +
		"order by tnu_sys_msg_tm desc"
	} else if (LEAD_UNIT.indexOf('METX') != -1) {
		var for_id = LEAD_UNIT.match(/\d/g);
		for_id = for_id.join("");
		
		document.getElementById('hue_route_map').value = 
		"set RAILROAD = 'metx';"  + "\n" +
		"set LOCO_ID = '" + for_id + "';"  + "\n" +
		"set UTC_date = '" + ENF_DATE_UTC + "';" + "\n" +
		"set UTC_timeBegin = '" + sub_hour + "';" + "\n" +
		"set UTC_timeEnd = '" + add_hour + "';" + "\n" +
		"set tez.queue.name=NOC;"  + "\n" +
		"" + "\n" +
		"select * from prptc.ptc_emp_7102_vw"  + "\n" +
		"where ptc_emp_7102_vw.log_date = ${hiveconf:UTC_date}"  + "\n" +
		"and   ptc_emp_7102_vw.TS_UTC >= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeBegin})"  + "\n" +
		"and   ptc_emp_7102_vw.TS_UTC <= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeEnd})"  + "\n" +
		"and ptc_emp_7102_vw.tnu_aset_typ = 'l'"  + "\n" +
		"and ptc_emp_7102_vw.tnu_aset_id = CONCAT(${hiveconf:RAILROAD}, '+', ${hiveconf:LOCO_ID})"  + "\n" +
		"order by ptc_emp_7102_vw.TS_UTC desc"
		
	} else {
		document.getElementById('hue_route_map').value = "Unknown Railroad Type"
	}
	
	document.getElementById('hue_tmc_log').value = 
	"set LOCO_ID = '" + LEAD_UNIT + "';" + "\n" +
	"set UTC_date = '" + ENF_DATE_UTC + "';" + "\n" +
	"set UTC_timeBegin = '" + sub_15min + "';" + "\n" +
	"set UTC_timeEnd = '" + add_10min + "';" + "\n" +
	"set tez.queue.name=NOC;" + "\n" +
	"" + "\n" +
	"select msg_tm, loco_id, payload, log_date" + "\n" +
	"from prptc.ptc_log_tmc_vw"  + "\n" +
	"where log_date in (${hiveconf:UTC_date})" + "\n" +
	"and msg_tm >= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeBegin})"  + "\n" +
	"and msg_tm <= CONCAT(${hiveconf:UTC_date}, ' ', ${hiveconf:UTC_timeEnd})"  + "\n" +
	"and file like '%app%'" + "\n" +
	"and loco_id = ${hiveconf:LOCO_ID}"  + "\n" +
	"order by msg_tm"

	
}

// connect to wms using phone number
function enfStepsConWMS_phone() {
	enfwinTab01 = window.open('ptctabs.conzoc://' + "d" + enf_exData[5] + ".airlink.uprr.com");
	//enfwinTab01.close();
}

// connect to wms using ip address
function enfStepsConWMS_ipaddress() {
	enfwinTab01 = window.open('ptctabs.conzoc://' + enf_exData[6]);
	//enfwinTab01.close();
}

// Login to Loco
function enfStepsLocoLogin() {
	enfwinTab01 = window.open('ptctabs.locologin://' + LEAD_UNIT);
	//enfwinTab01.close();
}

// Run Beacon Test
function enfStepsBeaonOn() {
	
	var DC = document.getElementById("enf1dc").value;
	
	// get password from cookie
	readCookie("wssm");
	//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
	if (pass == "") {
		$("#launchPasswordSave").modal("show");		
	} else {
		if (DC == "UPC") {
			enfwinTab01 = window.open('ptctabs.beacontest://' + "UPC" + "_" + WIU_ID + "_" + pass);
			//enfwinTab01.close();
		} else {
			enfwinTab01 = window.open('ptctabs.beacontest://' +  "DEX" + "_" + WIU_ID + "_" + pass);
			//enfwinTab01.close();
		}
	}		

}

function enfStepsOpenWIU() {
	if (WIU_NBR == "03") {
		window.open("http://" + enf_exData[6] + ":8083");
	} else if (WIU_NBR == "04") {
		window.open("http://" + enf_exData[6] + ":8084");
	} else if (WIU_NBR == "05") {
		window.open("http://" + enf_exData[6] + ":8085");
	} else {
		window.open("http://" + enf_exData[6] + ":8086");
	}
}


// search ticket with wms id for last 3 months
function enfStepsTicSearch_wms() {
	var desc = enf_exData[4];

	// getting today's date
	var today = new Date();
    var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
        ddL='0'+ddL
    } 
    if(mmL<10){
        mmL='0'+mmL
    } 
    var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC="+desc+"&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}

// search ticket with radio id for last 3 months
function enfStepsTicSearch_radio() {
	var desc = enf_exData[11];

	// getting today's date
	var today = new Date();
    var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
        ddL='0'+ddL
    } 
    if(mmL<10){
        mmL='0'+mmL
    } 
    var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC="+desc+"&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}

// search ticket with loco id for last 3 months
function enfStepsTicSearch_loco() {
	var desc = LEAD_UNIT;

	// getting today's date
	var today = new Date();
    var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
        ddL='0'+ddL
    } 
    if(mmL<10){
        mmL='0'+mmL
    } 
    var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC="+desc+"&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}

// search ticket with site MNEM for last 3 months
function enfStepsTicSearch_mnem() {
	var desc = SITE_MNEM;

	// getting today's date
	var today = new Date();
    var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
        ddL='0'+ddL
    } 
    if(mmL<10){
        mmL='0'+mmL
    } 
    var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER="+desc+"&szKEYWORD_DESC=&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}

// search tickets with loco id for last 2 months (enforcement tickets)
function enfStepsTicSearch_loco_enf() {
	var desc = LEAD_UNIT;
	
    window.open("https://home.www.uprr.com/emp/it/oss/secure/reports/analyze_tickets.cfm?STAT=&OPEN_DATE_RANG=90&szSEV_TYPE=CURR&system=NOC+TRAIN+OPERATIONS&component=TRAINOPS&item=PTC&module=LOCOMOTIVE-ENFORCEMENT&tsfr_type=curr&feField_1=Lead+Unit&feValue_1="+desc+"&fe_cnt=2&szReportSource=PrimaryDB&szCHRT_TYPE=PIE&szORD_BY=OPEN_DATE+DESC&cbSEV=true&cbSCIM=true&last_updt_type=init_cmnt&timer_type=true&tmpt_data=all&fe_cnt2=1&expt_type=basic&flgHF=True&szPage=1&ButtonPressed=Submit");
}

// Run PTC Diagnostics
function enfStepsRunDiag() {
	var modem = enf_exData[6];
    
	if (modem != "") {
		// get password from cookie
		readCookie("wssm");
		//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			enfwinTab01 = window.open('ptctabs.ptcdiag://' + modem + "_" + pass);
			//enfwinTab01.close();
		}
	} else {
		alert ("IP address is missing !!");
	}
}


// Run wayside WSSM Query
function enfStepsWSSMQ() {
	
	var fullWMSid = WIU_ID;
	var DC = document.getElementById("enf4dc").value;
		
	var QueryType = document.getElementById("enf4wssmType").value;
	if (QueryType == "u") {
		var QueryHours = "01";
	} else {
		if (removeSpaces(document.getElementById("enf4wssm_type_hrs").value) == "") {
			var QueryHours = "01";
		} else {
			var check_QueryHours = removeSpaces(document.getElementById("enf4wssm_type_hrs").value);
			if (check_QueryHours.length == "1") {
				QueryHours = "0" + check_QueryHours;
			} else {
				QueryHours = check_QueryHours;
			}
		}
	}

	// get password from cookie
	readCookie("wssm");
	//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);

	if (pass == "") {
		$("#launchPasswordSave").modal("show");		
	} else {
		if (DC == "UPC") {
			enfwinTab01 = window.open('ptctabs.queryway://' + "UPC" + "_" + fullWMSid + "_" + QueryType + "_" + QueryHours + "_" + pass);
			//enfwinTab01.close();
		} else {
			enfwinTab01 = window.open('ptctabs.queryway://' + "DEX" + "_" + fullWMSid + "_" + QueryType + "_" + QueryHours + "_" + pass);
			//enfwinTab01.close();
		}
	}		

}


// Query message content with time frame
function enfStepsWSSMstatus() {
	TIME_FRAME = document.getElementById("WSSMtimeframe_enf").value;
	
	var fullWMSid = WIU_ID;
	var DC = document.getElementById("enf5dc").value;

	// get password from cookie
	readCookie("wssm");
	//pass = removeSpaces(document.getElementById('PTCmyWSSMpassword').value);
	TFS = TIME_FRAME.split("-");
	
	EPOCH_FROM = TFS[0].slice(0, -1); // Get rid of space at the end
	EPOCH_TO = TFS[1].substr(1); // Get rid of space at the front
	//EPOCH_FROM = EPOCH_FROM.replace(/\s/g, ''); // deletes all spaces
	//EPOCH_TO = EPOCH_TO.replace(/\s/g, ''); // deletes all spaces
	
	//alert ("'"+EPOCH_FROM+"'");
	//alert ("'"+EPOCH_TO+"'");
	
	if (document.getElementById('WSSMcurrent_enf').checked) {
		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			if (DC == "UPC") {
				//alert ('ptctabs.msg1://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
				enfwinTab01 = window.open('ptctabs.msg1://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
				//enfwinTab01.close();
			} else {
				enfwinTab01 = window.open('ptctabs.msg1://' + "DEX" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + pass);
				//enfwinTab01.close();
			}
		}			
	} else {
		if (pass == "") {
			$("#launchPasswordSave").modal("show");		
		} else {
			if (DC == "UPC") {
				//alert ('ptctabs.msg2://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
				enfwinTab01 = window.open('ptctabs.msg2://' + "UPC" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
				//enfwinTab01.close();
			} else {
				enfwinTab01 = window.open('ptctabs.msg2://' + "DEX" + "_" + fullWMSid + "_" + EPOCH_FROM + "_" + EPOCH_TO + "_" + pass);
				//enfwinTab01.close();
			}
		}	
	}
}

// open PTC Loco GUI
function enfStepsPSM4Loco() {
	window.open("https://home.www.uprr.com/obc/ptc_monlogview/index.html#/nmt/secure/home/locomotives/" + LEAD_UNIT);
}

// Open loco WinSCP - LOG10E
function enfStepsWinSCP() {
	enfwinTab01 = window.open('ptctabs.locowinscp://' + LEAD_UNIT);
	//enfwinTab01.close();
}


// Copy HUE Messages
function enfStepsHUEmsgs() {
	var copyText = document.getElementById("hue_status_message");
	
	copyText.select();
	document.execCommand("Copy");
	
	alert ("Copied !!");
	window.open("http://prod-hue-phdp001.hdp.tla.uprr.com:8000/beeswax/");
}

// Copy HUE Status
function enfStepsHUEstatus() {
	var copyText = document.getElementById("hue_route_map");
	
	copyText.select();
	document.execCommand("Copy");
	
	alert ("Copied !!");
	window.open("http://prod-hue-phdp001.hdp.tla.uprr.com:8000/beeswax/");
}

// Copy TMC Log
function enfStepsHUEtmc() {
	var copyText = document.getElementById("hue_tmc_log");
	
	copyText.select();
	document.execCommand("Copy");
	
	alert ("Copied !!");
	window.open("http://prod-hue-phdp001.hdp.tla.uprr.com:8000/beeswax/");
}

// Copy work history template
function enfStepsWHtemplate() {
	var copyText = document.getElementById("enf_work_template");

	copyText.select();
	document.execCommand("Copy");
	
	alert ("Copied !!");
}




