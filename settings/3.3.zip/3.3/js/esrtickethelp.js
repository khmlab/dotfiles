ESR_SIG_MNEM = "";
ESR_WMS_ID = 0;
mnem_link = "";
e_com_link = "";
phone_link = "";
ip_link = "";
wms_status_link = "";
radio_status_link = "";

function esrTicketHelp_data() {
	//Read cookie for WSSM password
	readCookie("wssm");
	if (pass == "") {
		$("#launchPasswordSave").modal("show");
	} else {
		// extract the user entered data
		ESR_SIG_MNEM = removeSpaces(document.getElementById('esrTicketHelp').value).toUpperCase();
		TCS_USR = removeSpaces(document.getElementById('enf_tcs_user').value); // get TCS User ID
		TCS_PWD = document.getElementById('enf_tcs_pwd').value; // get TCS password
		
		// Validation
		if (ESR_SIG_MNEM == "") {
			alert ("Please enter SIG Mnemonic !!");
		} else if (TCS_USR == "") {
			alert ("TCS User ID is required");
		} else if (TCS_PWD == "") {
			alert ("TCS Password is required");
		} else {
			// call python script
			esrwinTab01 = window.open('ptctabs.esrhelp://' + TCS_USR + "_" + TCS_PWD + "_" + ESR_SIG_MNEM);
			esrwinTab01.close();
		}
	}
	
}

function esrTicketHelp_load() {
	// load the data resulted from python script
	$.getScript("H:/noc_dashboard/esr_data/esr_data.js");
	
	//Reassigning values again from external javascript just in case page gets refreshed and lose the user entered data
	mnem_link = "https://home.www.uprr.com" + esr_exData[14];
	e_com_link = "https://home.www.uprr.com" + esr_exData[15];
	phone_link = "https://home.www.uprr.com" + esr_exData[16];
	ip_link = "https://home.www.uprr.com" + esr_exData[17];
	wms_status_link = "https://home.www.uprr.com" + esr_exData[18];
	radio_status_link = "https://home.www.uprr.com" + esr_exData[19];
	esr_parent_name = esr_exData[21];
	
	// ************************ Inserting Values ******************************************************
	document.getElementById("esrTicketTitle").innerHTML = "ESR Ticket Help - " + esr_exData[0];
	document.getElementById("esrMnem").innerHTML = "<a href='" + mnem_link + "' target='_blank'>" + esr_exData[0] + "</a>";
	document.getElementById("esrSub").innerHTML = esr_exData[1];
	document.getElementById("esrMP").innerHTML = esr_exData[2];
	document.getElementById("esrEcom").innerHTML = "<a href='" + e_com_link + "' target='_blank'>" + esr_exData[3] + "</a>";
	document.getElementById("esrID").innerHTML = esr_exData[4];
	document.getElementById("esrPhone").innerHTML = "<a href='" + phone_link + "' target='_blank'>" + esr_exData[5] + "</a>";
	document.getElementById("esrIPadd").innerHTML = "<a href='" + ip_link + "' target='_blank'>" + esr_exData[6] + "</a>";
	document.getElementById("esrESR").innerHTML = esr_exData[7];
	document.getElementById("esrStat1").innerHTML = "<a href='" + wms_status_link + "' target='_blank'>" + esr_exData[8] + "</a>";
	document.getElementById("esrPTOTO").innerHTML = esr_exData[9];
	document.getElementById("esrETOTO").innerHTML = esr_exData[10];
	document.getElementById("esrRadioID").innerHTML = esr_exData[11];
	document.getElementById("esrStat2").innerHTML = "<a href='" + radio_status_link + "' target='_blank'>" + esr_exData[12] + "</a>";
	
	// Adding buttons
	document.getElementById("esrPingDigi").innerHTML = "<a class='btn btn-primary btn-sm' href='upping://d" + esr_exData[5] + ".airlink.uprr.com'>Ping Digi</a>"
	document.getElementById("esrPingIP").innerHTML = "<a class='btn btn-primary btn-sm' href='upping://" + esr_exData[6] + "'>Ping IP</a>"
	
	// Assigning WMS ID
	ESR_WMS_ID = "7802" + esr_exData[4] + "03";
	
	// Adding esrframe4 for ticket search
	document.getElementById("esrFrame4").innerHTML = "<iframe src='http:\/\/netsrvprd.dnm.tla.uprr.com\/cgi-bin\/wms\/wms_stat.pl?name=" + esr_parent_name + "' class='iframeESR' frameborder='1'></iframe>"
	
	// Adding esrFrame3 for ticket search
	document.getElementById("esrFrame3").innerHTML = "<iframe src='https:\/\/home.www.uprr.com\/emp\/it\/oss\/secure\/reports\/analyze_tickets.cfm?STAT=&OPEN_DATE_RANG=90&OPEN_STRT_DATE=03%2F18%2F2019&OPEN_END_DATE=06%2F16%2F2019&szSEV_TYPE=CURR&system=NOC+TRAIN+OPERATIONS&component=TRAINOPS&item=PTC&module=WAYSIDE&tsfr_type=curr&desc_kywd=" + esr_exData[4] + "%7C" + esr_exData[11] + "&feField_1=WMS+Replaced&feValue_1=Yes&fe_cnt=2&szReportSource=PrimaryDB&szCHRT_TYPE=PIE&szORD_BY=OPEN_DATE+DESC&cbSEV=true&cbSCIM=true&last_updt_type=init_cmnt&timer_type=true&tmpt_data=all&fe_cnt2=1&expt_type=basic&flgHF=True&szPage=1&ButtonPressed=Submit'  class='iframeESR2' frameborder='1'></iframe>"



	// Call Modal
	$("#esrTicketHelpmodal").modal()
}

// Run Beacon Test
function esrStepsBeaonOn() {
	
	// get password from cookie
	readCookie("wssm");
	if (pass == "") {
		$("#launchPasswordSave").modal("show");		
	} else {
		esrwinTab01 = window.open('ptctabs.beacontest://' + "UPC" + "_" + ESR_WMS_ID + "_" + pass);
		esrwinTab01.close();
	}		

}

// search ticket with wms id for last 3 months
function esrStepsTicSearch_wms() {
	var desc = esr_exData[4];

	// getting today's date
	var today = new Date();
	var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if(dd<10){
		dd='0'+dd
	} 
	if(mm<10){
		mm='0'+mm
	} 
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
		ddL='0'+ddL
	} 
	if(mmL<10){
		mmL='0'+mmL
	} 
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC="+desc+"&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}

// search ticket with radio id for last 3 months
function esrStepsTicSearch_radio() {
	var desc = esr_exData[11];

	// getting today's date
	var today = new Date();
	var mm = today.getMonth()+1; //January is 0!
	var dd = today.getDate();
	var yyyy = today.getFullYear();
	if(dd<10){
		dd='0'+dd
	} 
	if(mm<10){
		mm='0'+mm
	} 
	var todayIs = mm + '%2F' + dd + '%2F' + yyyy;
	
	// getting date 3 months ahead
	var yesterday = new Date(today);
	yesterday.setDate(dd - 90);
	var mmL = yesterday.getMonth()+1;
	var ddL = yesterday.getDate();
	var yyyyL = yesterday.getFullYear();
	if(ddL<10){
		ddL='0'+ddL
	} 
	if(mmL<10){
		mmL='0'+mmL
	} 
	var yesterdayIs = mmL + '%2F' + ddL + '%2F' + yyyyL;
	
	window.open("https://home.www.uprr.com/emp/it/oss/secure/trm/query_problems.cfm?szLATA_SERVER=&szKEYWORD_DESC="+desc+"&szSOLUTION=&KYWD_WH=&szSTART_OPEN_DATE="+yesterdayIs+"&szEND_OPEN_DATE="+todayIs+"&flgHF=false&szPage=1&ButtonPressed=Submit");

}












