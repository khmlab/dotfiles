$(document).ready(function () {

	$("#TimeZone").hide();
	$("#PTCptcTopics").hide();
	$("#NOCXTopics").hide();
	$("#menu_ptc").hide();
	$("#rightMenu4PTC").hide();
	$("#rightMenu4PTC2").hide();
	$("#rightMenu4PTC2Tab").hide();
	$("#ptcDashboardBar").hide();
	$("#NOCnotepad").hide();
	$(".NOCbook").toggle("slide");
	$("#commandTDputty1").hide();
	$("#commandTDputty2").hide();
	$("#commandTDputty3").hide();
	$("#commandTDputty4").hide();
	$("#menu6").hide(); // Hiding PTC Tab from NOC Dashboard

	$("#menuTime").hover(function () {
		$("#TimeZone").toggle();
	});

	$("#menuTime2").hover(function () {
		$("#TimeZone").toggle();
	});

	//Date range picker with time picker
	$('#WSSMtimeframe').daterangepicker({ timePicker: true, timePickerIncrement: 1, format: 'MM/DD/YYYY h:mm A' });
	$('#WSSMtimeframe_enf').daterangepicker({ timePicker: true, timePickerIncrement: 1, format: 'MM/DD/YYYY h:mm A' });

	// **************************************************************** PTC COMMANDS ****************************************************************

	// Toogle PTC Topics
	$("#PTCptcTopicsBtn").click(function () {
		$("#PTCptcTopics").slideToggle("blind");
	});

	// Toogle PTC Topics
	$("#NOCXBtn").click(function () {
		$("#NOCXTopics").slideToggle("blind");
	});

	// Tooltip - use this by adding <data-toggle="tooltip" data-placement="top|bottom|left|right" title="TITLE HERE"> to any element or link you want
	$('[data-toggle="tooltip"]').tooltip();

	// Main Dashboard Switcher (Change to PTC Dashboard)
	$(document).on("click", "#mainSwitcher", function () {
		$("body").removeClass("skin-yellow");
		$("body").addClass("skin-blue");
		$(this).after('<div id="mainSwitcher2"><img src="bin/up_logo_blue.png" class="UPlogo" /></div>');
		$("#menu").hide();
		$("#menu_ptc").show();
		$(".dropdown_menu12").show();
		$("#rightMenu4PTC").show();
		$("#rightMenu4PTC2").show();
		$("#rightMenu4PTC2Tab").show();
		$("#rightMenu4NOC").hide();
		$("#rightMenu4NOC2").hide();
		$("#nocDashboardBar").hide();
		$("#ptcDashboardBar").show();
		$("#NOCXTopics").slideUp();
		$(this).remove();

	});

	// Main Dashboard Switcher (Change to NOC Dashboard)
	$(document).on("click", "#mainSwitcher2", function () {
		$("body").removeClass("skin-blue");
		$("body").addClass("skin-yellow");
		$(this).after('<div id="mainSwitcher"><img src="bin/up_logo.png" class="UPlogo" /></div>');
		$("#menu").show();
		$("#menu_ptc").hide();
		$(".dropdown_menu1").show();
		$("#rightMenu4PTC").hide();
		$("#rightMenu4PTC2").hide();
		$("#rightMenu4PTC2Tab").hide();
		$("#rightMenu4NOC").show();
		$("#rightMenu4NOC2").show();
		$("#ptcDashboardBar").hide();
		$("#nocDashboardBar").show();
		$("#PTCptcTopics").slideUp();
		$(this).remove();

	});


	$("#NOCbooks").click(function () {
		$(".NOCbook").toggle("slide");
	});

	// Add scroll bar to bookmarks
	$('.bookmarkCSS').slimScroll({
		height: '850px',
		color: '#8aa4af'
	});

	// replace normal checkbox with iCheck
	$('#launchForm input').iCheck({
		checkboxClass: 'icheckbox_flat-grey',
		radioClass: 'iradio_flat-grey'
	});

	// instantiate clipboard
	new Clipboard('.copybtn', {
		text: function (trigger) {
			var icom = document.getElementById('icomOut').value;
			var site = document.getElementById('siteOut').value;
			var status = document.querySelector('input[name=techStatus]:checked').value
			var siteUp = site.toUpperCase();
			$("#launchMessage").modal("hide");
			if (status == "checkinTech") {
				return "ICOM" + icom + " is going work at " + siteUp + ". Please ignore alarms.";
			} else {
				return "ICOM" + icom + " is leaving the site " + siteUp + ". No alarms.";
			}
		}
	});


	// DROPDOWN FUNCTIONS *************************************************************** //

	// IP Dropdown ***************************************************************

	$("#ipadd").keyup(function (event) {
		if (event.which == 13) {
			findanyIP();
		}
	});

	$("#userip").keyup(function (event) {
		if (event.which == 13) {
			checkDeviceUser();
		}
	});

	$("#pingstatus").keyup(function (event) {
		if (event.which == 13) {
			checkPingStatus();
		}
	});

	$("#dhcpip").keyup(function (event) {
		if (event.which == 13) {
			finddhcpIP();
		}
	});

	$("#dhcpphone").keyup(function (event) {
		if (event.which == 13) {
			finddhcpPhone();
		}
	});

	$("#userid").keyup(function (event) {
		if (event.which == 13) {
			checkDeviceUser();
		}
	});


	// clear userip textbox when userid is focused
	$("#userid").focus(function () {
		document.getElementById('userip').value = "";
	});

	// clear userid textbox when userip is focused
	$("#userip").focus(function () {
		document.getElementById('userid').value = "";
	});

	// AEI Dropdown ***************************************************************

	$("#aeisitenumber").keyup(function (event) {
		if (event.which == 13) {
			checkAEI();
		}
	});

	$("#aeiSiteTrace").keyup(function (event) {
		if (event.which == 13) {
			aeiSiteTrace();
		}
	});

	$("#traintrace").keyup(function (event) {
		if (event.which == 13) {
			traceTrain();
		}
	});

	$("#ciesitenumber").keyup(function (event) {
		if (event.which == 13) {
			checkCIE();
		}
	});

	$("#tickettrace").keyup(function (event) {
		if (event.which == 13) {
			ticketTrace();
		}
	});

	$("#equiptrace").keyup(function (event) {
		if (event.which == 13) {
			traceEquip();
		}
	});

	// AEI Commands
	var addressValue = "G:/DCOS/NOC/Rick/AEI_INT/AEI_INT.htm#saic"; // Global Variable
	var addressValuePTC = "G:/DCOS/NOC/Rick/PTC_INT/PTC_INT.htm#wms"; // Global Variable

	$("#aeiframeCSS a").bind("click", function () {
		$("#aeiframeCSS a").removeClass("clicked"); // Remove all highlights
		$(this).addClass("clicked"); // Add the class only for actually clicked element
		addressValue = $(this).attr("href"); // Get the address of the clicked href
	});

	// Site Dropdown ***************************************************************

	$("#siteMNEM").keyup(function (event) {
		if (event.which == 13) {
			findMNEM();
		}
	});

	$("#rectMNEM").keyup(function (event) {
		if (event.which == 13) {
			findRECT();
		}
	});

	$("#siteSPARES").keyup(function (event) {
		if (event.which == 13) {
			findSPARES();
		}
	});
	$("#PTCsiteMNEM").keyup(function (event) {
		if (event.which == 13) {
			findPTCSpare();
		}
	});

	$("#analogPhone").keyup(function (event) {
		if (event.which == 13) {
			findAnalog();
		}
	});

	$("#siteALARMS").keyup(function (event) {
		if (event.which == 13) {
			findALARMS();
		}
	});

	$("#TTNsite").keyup(function (event) {
		if (event.which == 13) {
			QuerySiteTTN();
		}
	});


	// Radios Dropdown ***************************************************************
	$("#consoleAvtec").keyup(function (event) {
		if (event.which == 13) {
			lunchAvtecConsole();
		}
	});

	$("#circuitType").keyup(function (event) {
		if (event.which == 13) {
			findCircuit();
		}
	});

	$("#rcdendpoint").keyup(function (event) {
		if (event.which == 13) {
			findRCDendpoint();
		}
	});

	$("#dispNum").keyup(function (event) {
		if (event.which == 13) {
			findDISP();
		}
	});

	// CTC/SOC Dropdown ***************************************************************

	$("#sochbd").keyup(function (event) {
		if (event.which == 13) {
			findHBD();
		}
	});

	$("#CTCcodeline").keyup(function (event) {
		if (event.which == 13) {
			findCTCcodeline();
		}
	});

	$("#socticket").keyup(function (event) {
		if (event.which == 13) {
			readSOCticket();
		}
	});

	$("#cpSOC").keyup(function (event) {
		if (event.which == 13) {
			findCPsoc();
		}
	});

	// PTC Dropdown ***************************************************************

	// PTC Commands
	$("#ptcTDcss a").bind("click", function () {
		$("#ptcTDcss a").removeClass("clicked"); // Remove all highlights
		$(this).addClass("clicked"); // Add the class only for actually clicked element
		addressValuePTC = $(this).attr("href"); // Get the address of the clicked href
	});

	$("#pullIn").fadeOut();
	$("#ptcTDcss").fadeTo(500, 0.3);
	$("#ptcTDcss a").css({ 'cursor': "default" });

	$("#pushOut").click(function () {
		$('#ptcFrame').animate({ width: '100%' });
		$("#pullIn").fadeToggle();
		$("#pushOut").fadeToggle();
		$("#ptcTDcss").fadeTo(500, 1);
		$("#ptcTDcss a").css({ 'cursor': "pointer" });
	});

	$("#pullIn").click(function () {
		$('#ptcFrame').animate({ width: '0px' });
		$("#pullIn").fadeToggle();
		$("#pushOut").fadeToggle();
		$("#ptcTDcss").fadeTo(500, 0.3);
		$("#ptcTDcss a").css({ 'cursor': "default" });
	});


	$("#ptcbasedevice").keyup(function (event) {
		if (event.which == 13) {
			findPTCBase();
		}
	});

	$("#PTCmainSIGlocation").keyup(function (event) {
		if (event.which == 13) {
			SearchForTrains();
		}
	});

	$("#ptcwaysidedevice").keyup(function (event) {
		if (event.which == 13) {
			findPTCWayside();
		}
	});

	$("#BaseKey").keyup(function (event) {
		if (event.which == 13) {
			NMTBaseQ();
		}
	});

	$("#PSM_keyword").keyup(function (event) {
		if (event.which == 13) {
			openPSMgui();
		}
	});

	$("#ptcbasedeviceVET").keyup(function (event) {
		if (event.which == 13) {
			findPTCBaseVET();
		}
	});

	$("#WaysideKey").keyup(function (event) {
		if (event.which == 13) {
			NMTWaysideQ();
		}
	});


	// Vendor Dropdown ***************************************************************

	$("#createatt").keyup(function (event) {
		if (event.which == 13) {
			createATTticket();
		}
	});

	$("#querylease").keyup(function (event) {
		if (event.which == 13) {
			findLease();
		}
	});

	$("#resendOTA").keyup(function (event) {
		if (event.which == 13) {
			ResendOTA();
		}
	});

	$("#att_eod_pwd").keyup(function (event) {
		if (event.which == 13) {
			ResendOTA();
		}
	});

	$("#cell_tcs_pwd").keyup(function (event) {
		if (event.which == 13) {
			CellRouterLaunch();
		}
	});

	$("#CellRouter").keyup(function (event) {
		if (event.which == 13) {
			CellRouterLaunch();
		}
	});

	$("#CiscoPassword").keyup(function (event) {
		if (event.which == 13) {
			TroubleshootCellRouter();
		}
	});

	$("#checkatt").keyup(function (event) {
		if (event.which == 13) {
			checkATTticket();
		}
	});

	$("#findphone").keyup(function (event) {
		if (event.which == 13) {
			findPhone();
		}
	});

	$("#testedDevice").keyup(function (event) {
		if (event.which == 13) {
			CompareDeviceConfig();
		}
	});

	$("#vx1082_pwd").keyup(function (event) {
		if (event.which == 13) {
			CompareDeviceConfig();
		}
	});


	// Misc Dropdown ***************************************************************

	$("#ecomnumber").keyup(function (event) {
		if (event.which == 13) {
			findEcom();
		}
	});

	$("#ecomkeyword").keyup(function (event) {
		if (event.which == 13) {
			findEcomkey();
		}
	});

	$("#outmnem").keyup(function (event) {
		if (event.which == 13) {
			techCheckout();
		}
	});

	$("#ticketqueue").keyup(function (event) {
		if (event.which == 13) {
			checkQueue();
		}
	});

	$("#finduserid").keyup(function (event) {
		if (event.which == 13) {
			findUser();
		}
	});

	$("#unclosedtickets").keyup(function (event) {
		if (event.which == 13) {
			checkUnclosed();
		}
	});

	$("#techticketqueue").keyup(function (event) {
		if (event.which == 13) {
			checktechQueue();
		}
	});

	$("#cmWizard").keyup(function (event) {
		if (event.which == 13) {
			findcmWizard();
		}
	});

	$("#zebra-device-serial").keyup(function (event) {
		if (event.which == 13) {
			ZebraLookup();
		}
	});

	// Tools Dropdown ***************************************************************

	$("#IPXname").keyup(function (event) {
		if (event.which == 13) {
			GenerateIPXconfig();
		}
	});

	$("#ipxTCSpass").keyup(function (event) {
		if (event.which == 13) {
			GenerateIPXconfig();
		}
	});


	// Search Dropdown ***************************************************************

	$("#searchKMdoc").keyup(function (event) {
		if (event.which == 13) {
			searchKMdocs();
		}
	});


	// ******************************************************* PTC DROPDOWNS ***************************************************************

	// Save WSSM Password ***************************************************************	
	$("#PTCmyWSSMpassword").keyup(function (event) {
		if (event.which == 13) {
			PTCsaveWSSMpassword();
		}
	});

	// Main Dropdown ***************************************************************
	$("#PTCmainWMSconnect").keyup(function (event) {
		if (event.which == 13) {
			PTCmainWMSconnectFunc();
		}
	});

	$("#PTCmainPTCdiag").keyup(function (event) {
		if (event.which == 13) {
			PTCmainPTCdiagFunc();
		}
	});

	$("#PTCmainQuerySub").keyup(function (event) {
		if (event.which == 13) {
			PTCmainQuerySubFunc();
		}
	});

	// Wayside Dropdown ***************************************************************

	$("#PTCWaysideKey").keyup(function (event) {
		if (event.which == 13) {
			PTCNMTWaysideQ();
		}
	});


	$("#PTCptcwaysidedeviceGUI").keyup(function (event) {
		if (event.which == 13) {
			PTCopenPTCWaysideGUI();
		}
	});

	$("#PTCptcROA").keyup(function (event) {
		if (event.which == 13) {
			PTCopenPTCroa();
		}
	});


	$("#PTCptcwaysidedevice").keyup(function (event) {
		if (event.which == 13) {
			PTCfindPTCWayside();
		}
	});

	$("#ptcTCSpass").keyup(function (event) {
		if (event.which == 13) {
			SearchForBase();
		}
	});

	$("#TCSpassBEM").keyup(function (event) {
		if (event.which == 13) {
			TestBEMAlarms();
		}
	});

	// Base Dropdown ***************************************************************

	$("#PTCptcbasedevice").keyup(function (event) {
		if (event.which == 13) {
			PTCfindPTCBase();
		}
	});

	$("#PTCBaseKey").keyup(function (event) {
		if (event.which == 13) {
			PTCNMTBaseQ();
		}
	});

	$("#PTCptcbasedeviceGUI").keyup(function (event) {
		if (event.which == 13) {
			PTCopenPTCBaseGUI();
		}
	});

	$("#PTCptcbasedeviceVET").keyup(function (event) {
		if (event.which == 13) {
			PTCfindPTCBaseVET();
		}
	});

	$("#PTCptcbaseradioVET").keyup(function (event) {
		if (event.which == 13) {
			PTCfindPTCBaseVET();
		}
	});


	// Locomotive Dropdown ***************************************************************

	$("#PTCptcLOCOgui").keyup(function (event) {
		if (event.which == 13) {
			PTCopenPTClocoGUI();
		}
	});

	$("#PTCptcLOCOlog").keyup(function (event) {
		if (event.which == 13) {
			PTCopenPTClocoLOG();
		}
	});

	// Back Office Dropdown ***************************************************************	

	$("#PTCbackWSSMqueryBase").keyup(function (event) {
		if (event.which == 13) {
			PTCbackWSSMqueryBaseFunc();
		}
	});

	$("#PTCbackWSSMqueryBaseEMP").keyup(function (event) {
		if (event.which == 13) {
			PTCbackWSSMqueryBaseFunc();
		}
	});

	$("#PTCbackWSSMqueryBase").click(function () {
		document.getElementById("PTCbackWSSMqueryBaseEMP").value = "";
	});

	$("#PTCbackWSSMqueryBaseEMP").click(function () {
		document.getElementById("PTCbackWSSMqueryBase").value = "";
	});

	// EOTR Dropdown *******************************************************************
	$("#PTCeotrID").keyup(function (event) {
		if (event.which == 13) {
			PTCopenEOTRtool();
		}
	});

	// Commands Dropdown ***************************************************************

	// PTC Commands
	$("#ptcCoCss a").bind("click", function () {
		$("#ptcCoCss a").removeClass("clicked"); // Remove all highlights
		$(this).addClass("clicked"); // Add the class only for actually clicked element
		//addressValueCommands = $(this).attr("href"); // Get the address of the clicked href
	});


	// instantiate clipboard
	new Clipboard('.HUEtoolclip', {
		text: function (trigger) {

			var date = removeSpaces(document.getElementById("PTChue_date").value);
			var wiu = removeSpaces(document.getElementById("PTChue_WIU").value);
			var start = removeSpaces(document.getElementById("PTChue_start").value);
			var end = removeSpaces(document.getElementById("PTChue_end").value);

			return "select * from\n" +
				"(\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id,log_date,seq_nbr,vit_ttl_flag,diff_base_vit_tm\n" +
				"from prptc.ptc_emp_5100_vw where log_date = '" + date + "'\n" +
				"union all\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''\n" +
				"from prptc.ptc_emp_5200_vw where log_date = '" + date + "'\n" +
				"union all\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''\n" +
				"from prptc.ptc_emp_2500_vw where log_date = '" + date + "'\n" +
				"union all\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''\n" +
				"from prptc.ptc_emp_2501_vw where log_date = '" + date + "'\n" +
				"union all\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''\n" +
				"from prptc.ptc_emp_1500_vw where log_date = '" + date + "'\n" +
				"union all\n" +
				"select ts_utc,emp_msg_typ,emp_src,emp_dest,wiu_id ,log_date,'','',''\n" +
				"from prptc.ptc_emp_1501_vw where log_date = '" + date + "' ) brk_evnt\n" +
				"where brk_evnt.LOG_DATE = '" + date + "'\n" +
				"and brk_evnt.WIU_ID = '" + wiu + "'\n" +
				"and brk_evnt.TS_UTC >= '" + date + " " + start + "'\n" +
				"and brk_evnt.TS_UTC <= '" + date + " " + end + "'\n" +
				"order by brk_evnt.ts_utc";
		}


	});


	// END OF DROPDOWN FUNCTIONS *************************************************************** //





	// DROPDOWN MENUS DIVS //
	$(".dropdown_menu2").hide();
	$(".dropdown_menu3").hide();
	$(".dropdown_menu4").hide();
	$(".dropdown_menu5").hide();
	$(".dropdown_menu6").hide();
	$(".dropdown_menu7").hide();
	$(".dropdown_menu8").hide();
	$(".dropdown_menu9").hide();
	$(".dropdown_menu10").hide();
	$(".dropdown_menu11").hide();
	$(".dropdown_menu12").hide();
	$(".dropdown_menu13").hide();
	$(".dropdown_menu14").hide();
	$(".dropdown_menu15").hide();
	$(".dropdown_menu16").hide();
	$(".dropdown_menu17").hide();
	$(".dropdown_menu18").hide();
	$(".dropdown_menu19").hide();

	$("#menu1").click(function () {
		$(".dropdown_menu1").show();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
		$("#iframeAEI").attr("src", addressValue);
	});

	$("#menu2").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").show();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu3").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").show();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu4").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").show();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu5").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").show();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu6").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").show();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
		$("#ptcFrame").attr("src", addressValuePTC);
	});

	$("#menu7").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").show();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu8").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").show();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu9").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").show();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu10").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").show();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu11").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").show();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu12").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").show();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu13").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").show();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu14").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").show();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu15").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").show();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu16").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").show();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu17").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").show();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").hide();
	});

	$("#menu18").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").show();
		$(".dropdown_menu19").hide();
	});

	$("#menu19").click(function () {
		$(".dropdown_menu1").hide();
		$(".dropdown_menu2").hide();
		$(".dropdown_menu3").hide();
		$(".dropdown_menu4").hide();
		$(".dropdown_menu5").hide();
		$(".dropdown_menu6").hide();
		$(".dropdown_menu7").hide();
		$(".dropdown_menu8").hide();
		$(".dropdown_menu9").hide();
		$(".dropdown_menu10").hide();
		$(".dropdown_menu11").hide();
		$(".dropdown_menu12").hide();
		$(".dropdown_menu13").hide();
		$(".dropdown_menu14").hide();
		$(".dropdown_menu15").hide();
		$(".dropdown_menu16").hide();
		$(".dropdown_menu17").hide();
		$(".dropdown_menu18").hide();
		$(".dropdown_menu19").show();
	});

});


