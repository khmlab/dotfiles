

	function formatMnem(row){
      if( row[1] == 'undefined'){
         return row[0];
      }
      else{
         var mnem = row[3] + "." + row[1] + "." + row[4];
         addr = row[3] + "." + row[1] + "." + row[4] + " - " + row[5] + "<br>";
         if( row[7] != '' ){
            addr += row[7] + ", ";
         }
         addr += row[0] + ", " + row[1] + " " + row[2];
         if( row[9] != '' ){
            addr += "<br/>Building #" + row[9];
         }
         if( row[11] != '' ){
            addr += "<br/>" + row[10] + ' MP' + row[11];
         }

         return addr;
      }
   }


   function BIND_MNEM_AUTOCOMPLETE(flgIncludeSignal){

      if(flgIncludeSignal == 'True'){
         var URL = 'https://home.www.uprr.com/emp/it/telecom/ttn/com/autocomplete.cfc?method=autoSuggestMnem&FAC_TYPE_EXCL_LIST=5';
      }
      else{
         var URL = 'https://home.www.uprr.com/emp/it/telecom/ttn/com/autocomplete.cfc?method=autoSuggestMnem&FAC_TYPE_EXCL_LIST=5,30';
      }

      $('#KYWD').autocomplete(URL, {
         // Display Controls
         width: 300,
         scrollHeight: 175,
         scroll: true,
         minChars: 2,
         maxItemsToShow: 15,
         // Caching Controls
         delay: 100,
         cacheLength:1,
         matchSubset:0,
         matchContains:0,
         extraParams: { y: Math.round(Math.random()*10000) },
         // Return Data Processing
         formatItem: formatMnem,
          onItemSelect: function(li) {
             if( li == null ) return 0;
             var row = li.extra;
             var mnem = row[2] + "." + row[0] + "." + row[3];
             $(this).val(mnem);
             return mnem;
          },
          onFindValue: function(li) {
             if( li == null ) return 0;
             var row = li.extra;
             var mnem = row[2] + "." + row[0] + "." + row[3];
             return mnem;
          }
      }).result( function(event, item, formatted ) {
         $('#QuerySiteLocations').ricolaPleaseWaitShow();
         if( item == null ) {
            $('#METHOD').val('Submit');
            $('#QuerySiteLocations').submit();
            return 0;
         }
         if( item[1] == "undefined" ) {
            $(this).val(item[0]);
            $('#METHOD').val('Submit');
            $('#QuerySiteLocations').submit();
         } else {
            if($('#DISP_OPTS').val() == 'Browser'){
               if($('#cbSiteSummary').attr('checked')){
                 window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/please_wait.cfm?RIC_VERS=2&/emp/it/telecom/ttn/secure/prov/locations/Site_Location_Summary.cfm?szSite_Loca_ID='+item[6],'_blank');
               }
               else{
                  window.open('https://home.www.uprr.com/emp/it/telecom/ttn/secure/please_wait.cfm?RIC_VERS=2&/emp/it/telecom/ttn/secure/prov/Site_Location.cfm?szSite_Loca_ID='+item[6],'_blank');
               }
            }
            else{
               
               $('#METHOD').val('Submit');
               $('#QuerySiteLocations').submit();
            }
         }
      });
   }









