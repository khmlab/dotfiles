$arg_input = $args[0]
$loco_id = $arg_input.split(":")
$loco_id = $loco_id[1].Trim("/")
Write-Host $loco_id

Set-Location C:\Users\$env:USERNAME\NOC_Dashboard\tools\PTC_Bat\
python .\LocoITCM.py $loco_id