import os
import time
import paramiko
import sys
import warnings
import requests
import getpass

warnings.filterwarnings("ignore", category=DeprecationWarning)

class locoITCM():
    def __init__(self):
        self.loco = sys.argv[1]
        self.loco = str(self.loco)
        os.system('cls')
        
    def getLocoInfo(self):
        if self.loco[0].lower() != "u":
            self.connectLoco()
            sys.exit()
            #come back and finish this
        counter = 0
        #print("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/onboard/view/" + self.loco + "/")
        LocoJson = requests.get("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/onboard/view/" + self.loco + "/").json()
        try:
            self.dns1 = LocoJson[0]['digitalCellOne']
            self.dns1 = self.dns1 + ".airlink.uprr.com"
            print(self.dns1)
        except:
            counter = counter + 1
            self.dns1 = "skip"
            print("Primary cell not listed on backend")
        
        try:
            self.dns2 = LocoJson[0]['digitalCellTwo']
            self.dns2 = self.dns2 + ".airlink.uprr.com"
            print(self.dns2)
        except:
            counter = counter + 1
            self.dns2 = "skip"
            print("Secondary cell not listed on backend")
            
        try:
            self.ip = LocoJson[0]['wifiAdress']
            self.ip = self.ip + ".airlink.uprr.com"
            print(self.ip)
        except:
            counter = counter + 1
            self.ip = "skip"
            print("Wifi Address not listed on backend")
            
        if counter == 3:
            print("No route to the locomotive listed on the back end.  Please manually find an IP address and try again")
            sys.exit()
            
        else:
            self.connectLoco()
            
    def connectLoco(self):
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        temp = False
        print("\n")
        print("Must Type Password")
        passwd = getpass.getpass(prompt="Slot10 Password: ")
        print("\n")
    
        if self.loco[0].lower() != "u":
            try:
                ssh.connect(self.loco, port=7008, username='admin', password=passwd)
                print("Successfully Connected")
                temp = True
            except:
                print("IP Address Given Offline")
                sys.exit()
        else:
            while temp == False:
                if self.dns1 != "skip":
                    try:
                        ssh.connect(self.dns1, port=7008, username='admin', password=passwd)
                        print("Successfully Connected")
                        temp = True
                    except:
                        response = os.system("ping -n 2 " + self.dns1)
                        if response == 0:
                            print("Primary Cell online, Password was incorrect")
                            ssh.close()
                            self.connectLoco()
                            temp = True
                        else:
                            print("Primary Cell offline")
                        self.dns1 = "skip"
                        
                elif self.dns2 != "skip":
                    try:
                        ssh.connect(self.dns2, port=7008, username='admin', password=passwd)
                        print("Successfully Connected")
                        temp = True
                    except:
                        response = os.system("ping -n 2 " + self.dns2)
                        if response == 0:
                            print("Secondary Cell online, Password was incorrect")
                            ssh.close()
                            self.connectLoco()
                            temp = True
                        else:
                            print("Secondary Cell offline")
                        self.dns2 = "skip"
                        
                elif self.ip != "skip":
                    try:
                        ssh.connect(self.ip, port=7008, username='admin', password=passwd)
                        print("Successfully Connected")
                        temp = True
                    except:
                        response = os.system("ping -n 2 " + self.ip)
                        if response == 0:
                            print("Locomotive Wifi connection online, Password was incorrect")
                            ssh.close()
                            self.connectLoco()
                            temp = True

                        else:
                            print("Locomotive Wifi connection offline")
                        self.ip = "skip"
                
                else:
                    print("All methods of connecting to Locomotive are offline.")
                    temp = True
        
        ###########################################################################################################################################################
        #These are where we execute commands#
        print("\n")
        stdin, stdout, stderr, = ssh.exec_command('sudo stop itcm-CM')
        stop = stdout.readlines()   
        stop2 = '\n'.join(stop)
        print(stop2)
        print("Waiting 5 seconds before starting next process")
        time.sleep(1)
        print("4")
        time.sleep(1)
        print("3")
        time.sleep(1)
        print("2")
        time.sleep(1)
        print("1\n")
        stdin, stdout, stderr, = ssh.exec_command('sudo start itcm-CM')
        start = stdout.readlines()   
        start2 = '\n'.join(start)
        print(start2)
        print("please wait while we gather check Radio State\n")
        
        stdin, stdout, stderr, = ssh.exec_command('telnet 192.168.255.201 4004;')
        telnet = ""
        trigger = False
        while trigger == False:
            line = stdout.readline()
            temp = ''.join(line)
            telnet += ''.join(line)

            if ':' in temp:
                break
        
        
        radio = ""
        trigger = False
        counter = 0
        time.sleep(3)
        stdin.write('radio state\r')
        while trigger == False:
            stdin.flush()
            line = stdout.readline()
            temp = ''.join(line)
            radio += ''.join(line)

            if temp == '\n' or temp == '':
                counter = counter + 1

            if counter == 3:
                if "BAD" in radio:
                    print("********** Something is not right here ****************\n" + radio)
                    temp = True
                    break
                else:
                    print("\n" + radio)
                    temp = True
                    break
            
if __name__ == '__main__':
    new_instance = locoITCM()
    new_instance.getLocoInfo()