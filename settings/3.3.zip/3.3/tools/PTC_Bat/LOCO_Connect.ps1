$env:loco_id = $args[0]
function LOCO_Connect
{
$env:User_IDD = [Environment]::UserName
$env:User_ID = $env:User_IDD.ToLower()
$env:date = Date
cd C:\Users\$env:USERNAME\NOC_Dashboard\tools\PTC_Bat\
$ErrorActionPreference = "SilentlyContinue"

clear-host
while ($env:loco_id -eq $null) 
    {
      $env:loco_id = Read-Host "Please Enter The Locomotive ID (UP9906)"
    }
	$env:loco_id_2 = $env:loco_id.Trim()
	
	#Invoke-RestMethod -Uri http://home.www.uprr.com/nmt/base-monitor/jas/ptc/view/onboard/"$env:loco_id_2"/ |format-table -HideTableHeaders  -property wifiAddress | out-file "$env:User_IDwifi.txt"
	#$wifi = get-content "$env:User_IDwifi.txt" | select-string -pattern "[*.*.*.*]"
	#$wifi = $wifi -replace '\s',''
	#rm "$env:User_IDwifi.txt"
    
    Invoke-RestMethod -Uri http://home.www.uprr.com/nmt/base-monitor/jas/ptc/view/onboard/"$env:loco_id_2"/ |format-table -HideTableHeaders  -property digitalCellOne | out-file "$env:User_IDcell1.txt"
	$raw_cell_1 = get-content "$env:User_IDcell1.txt" | select-string -pattern "m[0-9]","d[0-9]","r[0-9]"
	$raw_cell_1 = $raw_cell_1 -replace '\s',''
	rm "$env:User_IDcell1.txt"
	
	Invoke-RestMethod -Uri http://home.www.uprr.com/nmt/base-monitor/jas/ptc/view/onboard/"$env:loco_id_2"/ |format-table -HideTableHeaders  -property digitalCellTwo | out-file "$env:User_IDcell2.txt"
	$raw_cell_2 = get-content "$env:User_IDcell2.txt" | select-string -pattern "m[0-9]","d[0-9]","r[0-9]"
	$raw_cell_2 = $raw_cell_2 -replace '\s',''
	rm "$env:User_IDcell2.txt"
	
     
 
$test_cell1 ="$raw_cell_1"+".airlink.uprr.com"



$test_cell2 = "$raw_cell_2"+".airlink.uprr.com"



if('$test_cell1 or $test_cell2'  -notmatch "[0-9]")

{
   Write-host "Cellular Data Appears To Be Incomplete." -BackgroundColor red -ForegroundColor Black 
   read-host -prompt "Press Enter To Try Again."
   $env:loco_id = $null
   LOCO_Connect
}

clear-host

$env:portselect1 = read-host "Are we connecting to SLOT10 or GP2?"
while ($env:portselect1 -ne "SLOT10" -and $env:portselect1 -ne "GP2" ) 
    {
      $env:portselect1 = read-host "Are we connecting to SLOT10 or GP2?"
    }
	$env:portselect = $env:portselect1.Trim()
	
	
    if ($env:portselect -eq "SLOT10")
	{
	$env:port = "7008"
	}
	else
	{
	$env:port = "22"
	}


 
clear-host


write-host  "Testing $test_cell1  Please Wait...."
Write-Host ----------------------------------------
          
    if (Test-Connection $test_cell1 -count 2 -erroraction silentlycontinue  -Quiet)
	
    {       
	
	  run  "C:\Program Files (x86)\PuTTY\putty.exe" -ssh -P $env:port admin@$test_cell1
	  exit
    }
        
    
		
clear-host
write-host  "Testing $test_cell2  Please Wait...."
Write-Host -----------------------------------------	
    if (Test-Connection $test_cell2 -count 2 -erroraction silentlycontinue  -Quiet)
	
    {     
	   run  "C:\Program Files (x86)\PuTTY\putty.exe" -ssh -P $env:port admin@$test_cell2
	
	}
			
			else{
			clear-host
			Write-host "All Connections Have Failed, Please Try Again Later"  -BackgroundColor red -ForegroundColor Black
			Write-Host --------------------------
			read-host -prompt "Press Enter To Try Again."
			$env:loco_id = $null
			LOCO_Connect
			}
    
	}
	
	
	LOCO_Connect
	
	
	
	
       








