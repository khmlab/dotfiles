regedit.exe /s 'G:\DCOS\ALL\NOC\NOC dashboard\3.3\tools\python_env\Setup_PythonPath.reg'

Write-Output "Python is now setup to your account variables"
Start-Sleep -Seconds 2