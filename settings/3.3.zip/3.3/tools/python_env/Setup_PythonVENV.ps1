# List of Virtual Envrionments
$venv_list = "eotr_venv", "itcm-restart_venv", "get-wmsrlog_venv"
# Check if Main Directory for Virtual Environments exists
$check_maindir = Test-Path -Path "C:\Users\$env:USERNAME\NOC_Dashboard\py_venv"
if ($check_maindir) {
    Set-Location C:\Users\$env:USERNAME\NOC_Dashboard\py_venv
}
else {
    mkdir C:\Users\$env:USERNAME\NOC_Dashboard\py_venv
    Set-Location C:\Users\$env:USERNAME\NOC_Dashboard\py_venv
}

# Check if Virtual Environment exists
foreach ($venv in $venv_list) {
    $check_venv = Test-Path -Path "C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\$venv"
    # If Virtual Environment exists
    if ($check_venv) {
        Write-Output "Virtual Environment Exists running Updates for Environment: $venv"
        & C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\$venv\Scripts\Activate.ps1
        python -m pip install --upgrade pip
        python -m pip install --upgrade setuptools
        python -m pip install --upgrade -r "C:\Users\$env:USERNAME\NOC_Dashboard\tools\python_env\requirements.txt"
        deactivate
    }
    # If Virtual Environment doesnt exist
    else {
        Write-Output "Virtual Environment Does not Exist running initial setup for Environment: $venv"
        C:\Python38\python.exe -m venv $venv
        & C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\$venv\Scripts\Activate.ps1
        python -m pip install --upgrade pip
        python -m pip install --upgrade setuptools
        python -m pip install -r "C:\Users\$env:USERNAME\NOC_Dashboard\tools\python_env\requirements.txt"
        deactivate
    }
}
Write-Output ""
Write-Output ""
Write-Output "Virtual Environments are now setup"
Start-Sleep -Seconds 5

