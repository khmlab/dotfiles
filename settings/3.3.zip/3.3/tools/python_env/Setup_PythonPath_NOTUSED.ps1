#
# Python
#
$userEnvironmentKey = "HKCU:\Environment"
$userEnvironment = (Get-Item -Path $userEnvironmentKey)
$Global:openEnv = 0
Write-Output "Configuring environment for python 3.8"
function Add-CommandToUserPath
{
    param ([string]$PathItem, [string]$PathMatch)

    # We have to do it this way, otherwise the variables are auto-expanded.
    $currPath = $userEnvironment.GetValue(
            "Path",
            "",
            [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)

    if (($currPath -notmatch [Regex]::Escape($PathItem)) -AND ($currPath -notmatch $PathMatch))
    {
        Write-Output " * $PathItem not found on path. Adding"
        $currPath += ";$PathItem"
        $env:Path += [System.Environment]::ExpandEnvironmentVariables(";$PathItem")
    }
    else
    {
        Write-Output " * $PathItem detected on path"
        $Global:openEnv = 1
    }
    Set-ItemProperty -Path $userEnvironmentKey -Name 'Path' -Value $currPath -Type ExpandString
}

# node
$pythonHome = $userEnvironment.GetValue('PYTHONHOME', "C:\Python38")
if (-not(Test-Path $pythonHome))
{
    throw "Couldn't find valid python home. Please reinstall python"
}
Set-ItemProperty -Path $userEnvironmentKey -Name 'PYTHONHOME' -Value $pythonHome
$env:PYTHONHOME = $pythonHome
Add-CommandToUserPath -PathItem '%PYTHONHOME%' -PathMatch 'Python38'
Add-CommandToUserPath -PathItem '%PYTHONHOME%\Scripts' -PathMatch 'Python38'


if (0 -eq $openEnv)
    {
        Write-Output ""
        Write-Output "For some reason, you need to look at your env variables for them to actually take effect."
        Write-Output " I'm going to open it up, you just hit 'OK' and we're good. This will close afterwards."

        Pause

        rundll32 sysdm.cpl,EditEnvironmentVariables
    }
else
    {
        Write-Output "Your environment is already setup"
    }

Start-Sleep -Seconds 5