#
# Python
#
$userEnvironmentKey = "HKCU:\Environment"
$userEnvironment = (Get-Item -Path $userEnvironmentKey)

Write-Output "Configuring environment for python 3.8"
function Add-CommandToUserPath
{
    param ([string]$PathItem, [string]$PathMatch)

    # We have to do it this way, otherwise the variables are auto-expanded.
    $currPath = $userEnvironment.GetValue(
            "Path",
            "",
            [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)

    if (($currPath -notmatch [Regex]::Escape($PathItem)) -AND ($currPath -notmatch $PathMatch))
    {
        Write-Output " * $PathItem not found on path. Adding"
        $currPath += ";$PathItem"
        $env:Path += [System.Environment]::ExpandEnvironmentVariables(";$PathItem")
        $openEnv = 0
    }
    else
    {
        Write-Output " * $PathItem detected on path"
        $openEnv = 1
    }
    Set-ItemProperty -Path $userEnvironmentKey -Name 'Path' -Value $currPath -Type ExpandString
    return $openEnv
}

# node
$pythonHome = $userEnvironment.GetValue('PYTHONHOME', "C:\Python38")
if (-not(Test-Path $pythonHome))
{
    throw "Couldn't find valid python home. Please reinstall python"
}
Set-ItemProperty -Path $userEnvironmentKey -Name 'PYTHONHOME' -Value $pythonHome
$env:PYTHONHOME = $pythonHome
$openEnv1 = Add-CommandToUserPath -PathItem '%PYTHONHOME%' -PathMatch 'Python38'
$openEnv2 = Add-CommandToUserPath -PathItem '%PYTHONHOME%\Scripts' -PathMatch 'Python38'

$openEnv1
$openEnv2

if (0 -eq $openEnv2,$openEnv1)
    {
        Write-Output ""
        Write-Output "For some reason, you need to look at your env variables for them to actually take effect."
        Write-Output " I'm going to open it up, you just hit 'OK' and we're good. This will close afterwards."

        Pause

        rundll32 sysdm.cpl,EditEnvironmentVariables
    }
else
    {
        Write-Output "Your environment is already setup"
    }