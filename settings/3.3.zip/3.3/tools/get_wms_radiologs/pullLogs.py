import os
import time
import paramiko
from multiprocessing import Process
from datetime import datetime, timedelta
import sys
# import pyPullPass
import requests
import time
import subprocess
import getpass

# USAGE python pullLogs.py SIG0618.NE.01 10032022 1428
class pullLogs():
    def __init__(self):
        self.wms = sys.argv[1]
        self.wms = str(self.wms)
        self.check = False
        self.date = sys.argv[2]
        self.time=sys.argv[3]
    try:
            self.itcm = sys.argv[2]
            self.itcm = str(self.itcm)
            self.check = True
    except:
        pass
    
    def getWMSinfo(self):
        
        # date = self.date[0] + self.date[1] + "/" + self.date[2] + self.date[3] + "/" + self.date[4] + self.date[5] + self.date[6] + self.date[7]
        # print("date: " + date)
        # self.date = date
        
        time = self.time[0] + self.time[1] + ":" + self.time[2] + self.time[3]
        print("time: " + time)
        self.time = time
        
        
        try:
            WayJson = requests.get("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/wayside/server/" + self.wms + "/").json()
            RadJson = requests.get("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/wayside/radio/" + self.wms + "/").json()
            self.ipAddress = WayJson[0]['ip']
            try:
                self.wmsid = WayJson[0]['id']
                temp = RadJson[0]['systemManagement']['smId']
                self.wayradid = temp[4:]
            except:
                print("A lot of data missing from NMT server, going to attempt to diag anyway")
        
            try:
                BaseJson = requests.get("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/radio/link/" + self.wayradid + "/").json()
                self.baseid = BaseJson[0]['mnemonic']

                BaseJson2 = requests.get("https://home.www.uprr.com/nmt/base-monitor/jas/ptc/base/" + self.baseid + "/").json()
                self.baseip = BaseJson2[0]['ip']
            except:
                print("Last base unkown by NMT server.")

            print("Wayside Mnemonic: " + self.wms)
            print("Wayside IP Address: " + self.ipAddress)


        except:
            print("Site does not exist on NMT server, exiting diag")
            self.endProgram()
            
        try:
            if not self.wayradid[0].isdigit():
                self.wayradid = "Error pulling radio id from NMT server"
            print("Wayside ID: " + self.wmsid)
            print("Wayside Radio ID: " + self.wayradid)
            try:
                print("Base Mnemonic: " + self.baseid)
                print("Base IP: " + self.baseip)
            except:
                print("Last base is unknown.")

        except:
            print("Error some data for site, will attempt to diag anyway")

        if self.check == True:
            self.itcmPing()
        else:
            self.passvx = getpass.getpass(prompt="Your VX1082 Password: ")
            self.passTech = getpass.getpass(prompt="WMS Tech Password: ")
            self.getRadioLogs()
            
    def getRadioLogs(self):
        try:
            vx1082 = ('67.206.9.17', 22)
            destAddr = ((str(self.ipAddress)), 22)

            print("\nAttempting to connect to VX1082...")
            ssh1082 = paramiko.SSHClient()
            ssh1082.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh1082.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.passvx)
            print("Connected to VX1082")
            print("Attempting to create channel to connect to WMS\n")
            try:
                sshtransport = ssh1082.get_transport()
                sshchannel = sshtransport.open_channel("direct-tcpip", destAddr, vx1082, timeout = 5)
                print("Channel created")
            except:
                os.system('cls')
                print("Wayside Mnemonic: " + self.wms)
                print("Wayside IP Address: " + self.ipAddress)
                print("Wayside ID: " + self.wmsid)
                try:
                    print("Wayside Radio ID: " + self.wayradid)
                except:
                    print("Radio ID has not yet been documented yet, exiting diag")
                    self.radExist = False
                    self.endProgram()
                try:
                    print("Base Mnemonic: " + self.baseid)
                except:
                    print("Base Mnemonic: Unkown")
                try:
                    print("Base IP: " + self.baseip)
                except:
                    print("Base IP: Unknown")

                print("\n*******************************************\n")


                print('\nStatus: WMS is not accessible.')

            print("\nAttempting to connect to WMS (primary)...")

            ssh = paramiko.SSHClient()
            ssh.load_system_host_keys()
            ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
            ssh.connect(self.ipAddress, port=22, username='tech', password=self.passTech, sock=sshchannel)#, look_for_keys=False)
            time.sleep(1)
            os.system('cls')
            print("Successfully connected to WMS.")

        except Exception as e:
            error = str(e)
            print("exception:" + error)
            print("\nUnable to access WMS")
            sys.exit()

        ########################################################################################################################################################################################
        ######################################     Starting Crawling the WMS here     ####################################################
        ##################################################################################################################################
        
        
        print("Telnetting to Radio: ")
        stdin, stdout, stderr, = ssh.exec_command('telnet 10.255.255.200 4004;')
        telnet = ""
        trigger = False
        while trigger == False:
            line = stdout.readline()
            temp = ''.join(line)
            telnet += ''.join(line)

            if ':' in temp:
                break
            
        print("Successfully connected to the radio.")
        
        list = ""
        list2 = ""
        #print(self.date)
        self.timeNum = self.date+ " " + self.time[0]+self.time[1]+" "+self.time[3]+self.time[4]
        
        d = datetime.strptime(self.timeNum,"%m%d%Y %H %M")
        d2 = d.strftime("%m/%d/%Y  %I:%M %p")
        self.enfTime = d
        
        counter = 0
        
        trigger = False
        print("\nCommand being ran, then filtered: \nfiles,dir,b:/itcrlogs")
        stdin.write('files,dir,b:/itcrlogs\r')
        winner = ""
        winnerTimeDif = 1801
        while trigger == False:
            stdin.flush()
            line = stdout.readline()
            #list += ''.join(line)
            close = False
            if counter > 2 and "bytes" not in line:
                spot = line.find(":")
                line = str(line)
                compTime = line[(spot-14):(spot+6)]
                compTime=str(compTime)                                                
                c = datetime.strptime(compTime,"%m/%d/%Y  %I:%M %p")
                c2 = c.strftime("%m/%d/%Y  %I:%M %p")
                timeDif = c- self.enfTime
                if timeDif.total_seconds() <= 1800 and timeDif.total_seconds() >= 0:
                    close = True
                
                
            counter = counter + 1
            
            if close == True:
                if "DLG" in line:
                    if timeDif.total_seconds() <= winnerTimeDif and timeDif.total_seconds() >= 0:
                        winner = line
                        winnerTimeDif = timeDif.total_seconds()
                    list = list + line

            if "bytes" in line:
                break    
        
        winSpot = winner.find(".")
        winningFile = winner[(winSpot-8):(winSpot+4)]
        print("\nAll DLG files within a 30 minutes after given time: \n" + list)
        print("Closest one to time of enforcement: " + winningFile)
        if winningFile == "":
            print("No DLG files within 30 minutes of the enforcement.  Closing.")
            sys.exit()
  
  
  ###############################################################################################################################################################
  ##  We know what file we want, time to grab it.  ##########################
  
  
  
        print("\nFile being grabbed: ")
        stats = ""
        trigger = False
        counter = 0
        escape = 0
        stdin.write('ffiles,type,b:/itcrlogs/' + winningFile + '\r')
        while trigger == False:
            stdin.flush()
            line = stdout.readline()
            stats += ''.join(line)
            counter = counter + 1
            print(line)

            if "\u0004" in line and "<" not in line:
                #print(stats)
                #print("We did it!")
                break

        print("C:\\Users\\" + os.getlogin() + "\\Documents\\radioLogs\\" + str(winningFile))
        # os.mkdir("C:\\Users\\" + os.getlogin() + "\Documents\\radioLogs\\")
        with open ("C:\\Users\\" + os.getlogin() + "\\Documents\\radioLogs\\" + str(winningFile),'w') as f:
            f.write(stats)
            
        application = "notepad++.exe"    
        file = "C:\\Users\\" + os.getlogin() + "\\Documents\\radioLogs\\" + str(winningFile)
        subprocess.call(["C:\\Program Files (x86)\\Notepad++\\notepad++.exe", file,"-n1500"])




        kill = ""
        trigger = False
        counter = 0
        #stdin.close()
        stdin, stdout, stderr, = ssh.exec_command('\x1d')
        # stdin.write('\x1d')
        stdin.write('Quit\r')
        stdin.flush()
        
        
        
        
if __name__ == '__main__':
    new_instance = pullLogs()
    new_instance.getWMSinfo()