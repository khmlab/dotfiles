# args[0] takes input from HTML Form
$arg_input = $args[0]
$arg_input = $arg_input.split(":")
$arg_input = $arg_input[1] + $arg_input[2]
$arg_input = $arg_input.Trim("/")
$arg_input = $arg_input.split("_")


$site_mnem = $arg_input[0]
$enf_date = $arg_input[1]
$enf_time = $arg_input[2]
$enf_date = $enf_date.split("-")
$enf_date = $enf_date[1] + $enf_date[2] + $enf_date[0]

# Write-Output $site_mnem $enf_date $enf_time

# Check radioLogs Directory to see if it exists or not
$check_dir = Test-Path -Path "C:\Users\$env:Username\Documents\radioLogs"
if ($check_dir) {
    Write-Output "C:\Users\$env:Username\Documents\radioLogs" Exists Already
}
# If Directory doesnt exist, Create Directory for output file
else {
    New-Item -ItemType "directory" -Path "C:\Users\$env:Username\Documents\radioLogs"
}

# Activate Virtual Environment and run python script
& C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\get-wmsrlog_venv\Scripts\Activate.ps1
python C:\Users\$env:USERNAME\NOC_Dashboard\tools\get_wms_radiologs\pullLogs.py $site_mnem $enf_date $enf_time
deactivate
