# args[0] takes input from HTML Form
$arg_input = $args[0]
if ($null -eq $arg_input) {
    $eotr_name = Read-Host "Please Enter EOTR name (ex. CA0992)"
}
else {
    $eotr_name = $arg_input.split(":")
    $eotr_name = $eotr_name[1].Trim("/")
}

$eotr_user = "admin"
$eotr_pw = Read-Host "Please Enter EOTR password"
$eotr_hostname = "eotr-01.$eotr_name.uprr.com"

function main_prompt {
    param (
        # OptionalParameters
    )

    Write-Host "Select Option" -BackgroundColor Gray -ForegroundColor Black
    Write-Host "--------------------------------"
    Write-Host "1.) Show EOTR Health"
    Write-Host "2.) Update Firmware"
    Write-Host "3.) Update Config"
	write-host "4.) EOTR Connect"
    Write-host ""
    write-host "0.) Exit" -ForegroundColor Red
    Write-host ""
    Write-Host --------------------------------
    write-host ""

    $prompt1 = Read-Host 'Enter Selection'
    while ($null -eq $prompt1) {
        $prompt1 = Read-Host 'Enter Selection'
    }
    if ($prompt1 -match "1") {
	    clear-host
        show_health
        Write-Output "`n`n`n"
        main_prompt
    }
    elseif ($prompt1 -match "2") {
	    clear-host
        update_firmware
        Write-Output "`n`n`n"
        main_prompt
    }
    elseif ($prompt1 -match "3") {
	    clear-host
        update_config
        Write-Output "`n`n`n"
        main_prompt
    }
    elseif ($prompt1 -match "4") {
        Clear-Host
        EOTR_connect
        Write-Output "`n`n`n"
        main_prompt
    }
    elseif($prompt1 -match "0") {
        Exit
    }
}


function show_health {
    param (
        # OptionalParameters
    )
    & C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\eotr_venv\Scripts\Activate.ps1
    python C:\Users\$env:USERNAME\NOC_Dashboard\tools\EOTR\show_health.py $eotr_hostname $eotr_pw
    deactivate
}

function update_firmware {
    param (
        # OptionalParameters
    )
    Write-Host "Updating Firmware"
    & pscp C:\Users\$env:username\NOC_Dashboard\tools\EOTR\Firmware\4040eRepeaterV2.07.bin $eotr_user"@"$eotr_hostname":/"
    & C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\eotr_venv\Scripts\Activate.ps1
    python C:\Users\$env:USERNAME\NOC_Dashboard\tools\EOTR\resetunit.py $eotr_hostname $eotr_pw
    deactivate
}

function update_config {
    param (
        # OptionalParameters
    )
    # This Creates the full CA0123-EOTR-01 Name and stores it in $eotr_devname
    $eotr_devname = $eotr_name.ToUpper() + '-EOTR-01'
    # This stores the files contents in $baseconfig variable
    $baseconfig = Get-Content -Path "C:\Users\$env:USERNAME\NOC_Dashboard\tools\EOTR\Config\base_config.cfg"
    # This reads the the $baseconfig file contents and replaces the text "DEV_NAME" with the $eotr_devname above
    $newconfig = $baseconfig -replace "DEV_NAME", $eotr_devname
    # This is the function that writes the new contents into a new file and names it RptrCfg.cfg
    $newconfig | Set-Content -Path "C:\Users\$env:USERNAME\NOC_Dashboard\tools\EOTR\Config\RptrCfg.cfg"
    # This calls putty SCP to transfer the config to the EOTR device itself and places in the config/ directory
    & pscp C:\Users\$env:username\NOC_Dashboard\tools\EOTR\Config\RptrCfg.cfg $eotr_user"@"$eotr_hostname":/config/"
    # This activates the Python Virtual Environment I have setup for each NOC PC
    & C:\Users\$env:USERNAME\NOC_Dashboard\py_venv\eotr_venv\Scripts\Activate.ps1
    # This runs the python script passing 2 arguments EOTR Hostname and EOTR Password
    python C:\Users\$env:USERNAME\NOC_Dashboard\tools\EOTR\resetunit.py $eotr_hostname $eotr_pw
    # This deactivates the Virtual Environment
    deactivate
}

function EOTR_connect {
    param (
        #OptionalParameters
    )
    ssh $eotr_user@$eotr_hostname
}

main_prompt