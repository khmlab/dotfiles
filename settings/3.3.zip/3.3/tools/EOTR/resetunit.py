import paramiko
import time
import sys

def connect(eotr_ip, eotr_port, user, passwd):
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print(f'Connecting to {eotr_ip}')
    ssh_client.connect(hostname=eotr_ip, port=eotr_port, username=user, password=passwd,
                       look_for_keys=False, allow_agent=False)
    return ssh_client

def get_shell(ssh_client):
    shell = ssh_client.invoke_shell()
    return shell

def send_command(shell, command, timout=2):
    print(f'Sending command: {command}')
    shell.send(command + '\r')
    time.sleep(timout)

def show(shell, n=10000):
    output = shell.recv(n)
    return output.decode('utf-8')

def close(ssh_client):
    # checking if the connection is active
    if ssh_client.get_transport().is_active() == True:
        print('Closing connection')
        ssh_client.close()

if __name__ == '__main__':
    eotr1 = {'eotr_ip': sys.argv[1], 'eotr_port': '22', 'user':'admin', 'passwd': sys.argv[2]}
    client = connect(**eotr1)
    shell = get_shell(client)
    send_command(shell, 'resetUnit')
    output = show(shell)
    print(output)