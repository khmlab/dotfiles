$ErrorActionPreference = 'silentlycontinue'

$pshost = get-host

$pswindow = $pshost.ui.rawui

$newsize = $pswindow.buffersize

$newsize.height = 100

$newsize.width = 95

$pswindow.buffersize = $newsize


$newsize = $pswindow.windowsize

$newsize.height = 30

$newsize.width = 95

$pswindow.windowsize = $newsize







function modem_setup
{
$env:User_IDD = [Environment]::UserName
$env:User_ID = $env:User_IDD.ToLower()
   
clear-host
write-host "Card Management"
write-host "---------------"
$env:mobile0 = $null
while ($env:mobile0 -eq $null) 
    {
	  
      $env:mobile0 = Read-Host "Enter Mobile0 IP"
    }
	$env:mobile0 = $env:mobile0.Trim()
	
	clear-host
write-host "Card Management"
write-host "---------------"
	$env:modempass = Read-Host "Enter modem password"
	while ($env:modempass -eq $null) 
    {
      $env:modempass = Read-Host "Please Enter your password for VX1082"
    }
	$env:modempass = $env:modempass.Trim()
	
	
	clear-host 
    write-host  "Checking Connection To Modem...."
Write-Host -----------------------------------	
    if (Test-Connection $env:mobile0 -count 2 -erroraction silentlycontinue  -Quiet)
	
    {
	        Write-host 'Modem Is Online!!!!' -BackgroundColor green -ForegroundColor Black
			read-host -prompt "Press Enter To Connect."
			}
			
			else{ Write-host "The Modem Is Offline or Incorrect"  -BackgroundColor red -ForegroundColor Black
			Write-Host --------------------------
			read-host -prompt "Press Enter To Try Again."
			modem_setup
    }
	
	clear-host
    
	
	Write-Host "User Account" -BackgroundColor Gray -ForegroundColor Black
    Write-Host "--------------------------------"
    Write-Host "1.) root"
    Write-Host "2.) mtadm"
	write-host ""
    write-host "0.) Exit" -ForegroundColor Red
    Write-host ""
    Write-Host --------------------------------
    write-host ""
    
    $env:useraccount = Read-Host 'Enter Selection'
    while ($env:useraccount -eq $null) 
    {
         $env:useraccount = Read-Host 'Enter Selection'
    }
    if ($env:useraccount -match "1")
    {
	clear-host
	    $env:useraccount = "root"
    }
    elseif ($env:useraccount -match "2")
	{
	clear-host
     $env:useraccount = "mtadm"
    }
	elseif($env:useraccount -match "0")
    {
        modem_setup
		
     }
	 
	write-host "Card Management"
    write-host "---------------"
	write-host "Configuring modem for remote reset"
    write-host "***If access is denied after entering password a couple times, close and try other user***"	
	C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh $env:mobile0 -P 8022 -l $env:useraccount -pw $env:modempass  'set service range=9 state=on;sudo /usr/sbin/iptables -A INPUT -i ppp0 -p udp -m udp --dport 2053 -m state --state NEW -j ACCEPT'
	$env:netstat = C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh -t $env:mobile0 -P 8022 -l $env:useraccount -pw $env:modempass  'netstat -l'
	          if ($env:netstat -like '*2053*')
			  {
			  wms_reset
			  }
			  else 
			  {
			  clear-host
			  write-host "Card Management"
              write-host "---------------"
			  write-host "IPTABLES failed to update on modem, please try again."
			  read-host -Prompt "Press Enter To Try Again"
			  modem_setup
			  }
			 
	
	
	}
	
function wms_reset
{
$env:User_IDD = [Environment]::UserName
$env:User_ID = $env:User_IDD.ToLower()
clear-host
clear-host
    Write-Host "Modem Type" -BackgroundColor Gray -ForegroundColor Black
    Write-Host "--------------------------------"
    Write-Host "1.) Verizon"
    Write-Host "2.) ATT"
	write-host ""
    write-host "0.) Exit" -ForegroundColor Red
    Write-host ""
    Write-Host --------------------------------
    write-host ""
    
    $env:modemtype = Read-Host 'Enter Selection'
    while ($env:modemtype -eq $null) 
    {
         $env:modemtype = Read-Host 'Enter Selection'
    }
    if ($env:modemtype -match "1")
    {
	    clear-host
write-host "Card Management"
write-host "---------------"
        Write-host "Sending Reset Command please wait"
        ssh $env:User_ID@vx1082 "/upapps/wms/bin/cmutil -p 2053 -c cold_rst -S 0x24 -D 0x10 -s $env:mobile0"
		read-host -Prompt "Press Enter To Exit"
		modem_setup
    }
    elseif ($env:modemtype -match "2")
	{
	clear-host
write-host "Card Management"
write-host "---------------"
	Write-host "Sending Reset Command please wait"
    ssh $env:User_ID@vx1082 "/upapps/wms/bin/cmutil -p 2053 -c cold_rst -S 0x22 -D 0x10 -s $env:mobile0"
	read-host -Prompt "Press Enter To Exit"
	modem_setup
    {
	elseif($env:modemtype -match "0")
    {
        modem_setup
		
     }
	}
	


}
}


	
modem_setup
	
	
	