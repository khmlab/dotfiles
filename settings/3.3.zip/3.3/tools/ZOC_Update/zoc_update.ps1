Copy-Item -Path 'G:\DCOS\ALL\NOC\HostDirectory.zocini' -Destination 'C:\Program Files (x86)\ZOC6\Userfiles\Options\' -Recurse -Force -Verbose
Read-Host -Prompt "Press Enter to exit"