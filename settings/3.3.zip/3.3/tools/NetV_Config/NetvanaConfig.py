import time
import sys
import telnetlib
import getpass
import os
#userid,password,serverIP
print ("NETV CONFIG")
print ("----------------")
UserID_1 = input ("Enter Your UserID: ")
UserID = UserID_1.lower()
os.system('cls')
print ("NETV CONFIG")
print ("----------------")
print ("Enter Your Password For VX1082")
password = getpass.getpass()
VX1082 = "67.206.9.17"

#Device and Config Information
os.system('cls')
print ("NETV CONFIG")
print ("----------------")
Failed_Device_1 = input ("Enter The Name Of The Failed Netvana As It Appears In TTN: ")
Failed_Device = Failed_Device_1.upper()
os.system('cls')
print ("NETV CONFIG")
print ("----------------")
Failed_Device_config_1 = input ("Enter The Failed Device Config File As It Appears In TTN: ")
Failed_Device_config = Failed_Device_config_1.lower()

#sending commands to VX1082 to move config file to TFTpboot directory, and then check if config is in directory
VX_Input_1 = "cd /data/rtrconf/configs/{}".format(Failed_Device)
VX_Input_2 = "cp {} /data/tftpboot".format(Failed_Device_config)
VX_Input_3 = "cd /data/tftpboot"
VX_Input_4 = "chmod 777 {}".format(Failed_Device_config)
VX_Input_5 = "ls"
VX_Input_6 = "cd /data/tftpboot"
VX_Input_7 = "rm {}".format(Failed_Device_config)


os.system('cls')

connection_1 = telnetlib.Telnet(VX1082)

print ('Copying Config To /data/tftpboot please wait...')

connection_1.read_until("login: ")
connection_1.write(UserID + "\n")
time.sleep(2)
connection_1.write(password + "\n")
time.sleep(2)
connection_1.write(VX_Input_1 + "\n")
time.sleep(2)
connection_1.write(VX_Input_2 + "\n")
time.sleep(2)
connection_1.write(VX_Input_3 + "\n")
time.sleep(2)
connection_1.write(VX_Input_4 + "\n")
time.sleep(2)
connection_1.write(VX_Input_5 + "\n")
time.sleep(1)

output = connection_1.read_very_eager()

connection_1.close()



os.system('cls')
print ("NETV CONFIG")
print ("----------------")
if Failed_Device_config not in output:
    print ("Copy To TFTP Directory Failed, Script Will Now Exit.")
    exit(3)	
else:
    print ("Copy To TFTP Directory Successful, Will Now Upload Config To Device.")

input("Press Enter to continue...")

os.system('cls')
#user input for spare IP
NetID = "uprr"
os.system('cls')
print ("NETV CONFIG")
print ("----------------")
SpareIP = input ("Please Enter The IP Of The Online Spare: ")

os.system('cls')
print ("NETV CONFIG")
print ("----------------")

rep = os.system("ping " + SpareIP)

os.system('cls')

#checking if spare is online
print ("NETV CONFIG")
print ("----------------")
if rep == 0:
      input("Spare Is Online, Press Enter To Continue.")
    
else:
     input ("Spare Is Not Reachable, Press Enter To Exit")

   	  
     sys.exit(1)
	  

os.system('cls')
#sending commands to spare device
print ("NETV CONFIG")
print ("----------------")
print ("Enter Current Router Password")
Netpassword = getpass.getpass()
Net_Input_1 = "copy tftp flash"
Net_Input_2 = VX1082
Net_Input_3 = Failed_Device_config
Net_Input_4 = "sh flash"
Net_Input_5 = "en"

connection_2 = telnetlib.Telnet(SpareIP)

os.system('cls')
print ("NETV CONFIG")
print ("----------------")
print ("Pulling Config To Device, Please Wait....")
time.sleep(5)
connection_2.write(NetID + "\n")
time.sleep(2)
connection_2.write(Netpassword + "\n")
time.sleep(2)
connection_2.write(Net_Input_5 + "\n")
time.sleep(2)
connection_2.write(Net_Input_1 + "\n")
time.sleep(10)
connection_2.write(Net_Input_2 + "\n")
time.sleep(2)
connection_2.write(Net_Input_3 + "\n")
time.sleep(2)
connection_2.write(Net_Input_4 + "\n")


output = connection_2.read_very_eager()

connection_2.close()

os.system('cls')
#checking for config in spare device flash and giving manuel instructions
print ("NETV CONFIG")
print ("----------------")
if Failed_Device_config not in output:
    print ("Copy To Device Flash Has Failed.")
    exit(3)	
else:
    print ("Copy To Device Flash Has Succeeded.")
	
input("Press Enter to continue...")
connection_3 = telnetlib.Telnet(VX1082)

os.system('cls')
#removing config file from VX1082 tftpboot
print ("NETV CONFIG")
print ("----------------")

print ('Cleaning Up VX1082 please wait...')

connection_3.read_until("login: ")
connection_3.write(UserID + "\n")
time.sleep(2)
connection_3.write(password + "\n")
time.sleep(2)
connection_3.write(VX_Input_6 + "\n")
time.sleep(2)
connection_3.write(VX_Input_7 + "\n")
time.sleep(2)

connection_3.close()

os.system('cls')
print ("NETV CONFIG")
print ("----------------")
print ("Please Log In To Spare And Run sh flash to verify.")
print ("--------------------------------------------------")
print ("--------------------------------------------------")
print ("Then Run [copy NewDevice.cfg start].")
print ("--------------------------------------------------")
print ("--------------------------------------------------")
print ("Ensure operating mode is correctly set to match original. Manually enter config t mode and type [shdsl mode ltu] if far end unit, [shdsl mode ntu] if head-end.")
print ("--------------------------------------------------")
print ("--------------------------------------------------")

input("Press Enter to exit...")



sys.exit(1)

