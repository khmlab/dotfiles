import os
import sys
import base64
import time
import subprocess
import webbrowser
try:
    import kivy
except:
    print("failed to import kivy")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install','kivy'])
from kivy.core.window import Window
from kivy.config import Config
from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.lang import Builder
from kivy.uix.widget import Widget
from kivy.uix.checkbox import CheckBox
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.properties import ObjectProperty
try:
    import six
except:
    print("failed to import six")
    subprocess.check_call([sys.executable,'-m', 'pip', 'install','six'])
try:
    import paramiko
except:
    print("failed to import paramiko")
    subprocess.check_call([sys.executable,'-m', 'pip', 'install','paramiko'])



kivy.config.Config.set('graphics','resizable', 0)
#Window.borderless = 'True'
Builder.load_file('bg.kv')

class MyLayout(TabbedPanel):
    pass

class reconfigApp(App):
    def build(self):
        Window.size = (350,410)
        self.title='WMS Reconfiguration Tool'
        os.system('cls')
        return MyLayout()

#all my getters
    def getSigId1(self):
        sigId = self.root.ids.sigId1.text
        sigId = sigId.strip().upper()
        if sigId[0] == 'S' and len(sigId) == 13:
            sigId = sigId[8] + sigId[9] + sigId[3] + sigId[4] + sigId[5] + sigId[6] + "-WMS-" + sigId[11] + sigId[12]
        return sigId

    def getSigId2(self):
        sigId = self.root.ids.sigId2.text
        sigId = sigId.strip().upper()
        if sigId[0] == 'S':
            sigId = sigId[8] + sigId[9] + sigId[3] + sigId[4] + sigId[5] + sigId[6] + "-WMS-" + sigId[11] + sigId[12]
        return sigId

    def getWmsWeb(self):
        wms = self.root.ids.webWms.text
        wms = wms.strip().upper()
        try:
            if wms[0] == 'S':
                wms = wms[8] + wms[9] + wms[3] + wms[4] + wms[5] + wms[6] + "-WMS-" + wms[11] + wms[12]
        except:
            pass
        return wms

    def getSpareId1(self):
        spareId = self.root.ids.spareDevice1.text
        spareId = spareId.strip().upper()
        return spareId

    def getSpareId2(self):
        spareId = self.root.ids.spareDevice2.text
        spareId = spareId.strip().upper()
        return spareId

    def getVX1082Password1(self):
        vx1082 = self.root.ids.vx1082password1.text
        return vx1082

    def getVX1082Password2(self):
        vx1082 = self.root.ids.vx1082password2.text
        return vx1082
     
    def getVX1082Password3(self):
        vx1082 = self.root.ids.vx1082password3.text
        return vx1082
      
    def getPhoneNumber(self):
        phone = self.root.ids.phoneNumber.text
        return phone

    def getCarrier(self):
        verizon = self.root.ids.verizon.active
        att = self.root.ids.att.active
        if verizon == True:
            return "verizon"
        elif att == True:
            return "att"
        else:
            print("error")

    def getWMSCurrent(self):
        wms = self.root.ids.currentWms.text
        return wms

    def getipAddress(self):
        ip = self.root.ids.ipAddress.text
        return ip
    def getModem(self):
        wms = self.getSigId2()
        carrier = self.getCarrier().upper()
        modem = wms[0]+wms[1]+wms[2]+wms[3]+wms[4]+wms[5]+wms[6]+'MTSMC'+carrier[0]+'-'+wms[11]+wms[12]
        return modem

#All the logic for programming
    def programSpare(self):     
        # print(self.getSigId1())
        # print(self.getSpareId1())
        #print(self.getVX1082Password1())
        
        
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            print(os.getlogin())
            ssh = paramiko.SSHClient()
            print("used paramiko")
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password1())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        deadWms = self.getSigId1()
        spare = self.getSpareId1()
        print('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_reconfig.pl -f ' + deadWms + ' -s ' + spare)
        stdin, stdout, stderr, = ssh.exec_command('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_reconfig.pl -f ' + deadWms + ' -s ' + spare, get_pty=True)
        for line in iter(stdout.readline, ""):
            print(line, end="")
        return
    
    def updateTTN(self):
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password2())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        deadWms = self.getSigId2()
        phone = self.getPhoneNumber()
        print('sudo -u ddnm999 /upapps/wms/scripts/ttn_update_phone_number.pl -h ' + deadWms + ' -p ' + phone)
        stdin, stdout, stderr, = ssh.exec_command('sudo -u ddnm999 /upapps/wms/scripts/ttn_update_phone_number.pl -h ' + deadWms + ' -p ' + phone, get_pty=True)
        for line in iter(stdout.readline, ""):
            if "proceed?" in line:
                stdin.write('y\n')
            print(line, end="")
        return

    def confTunnel(self):
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password2())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        deadWms = self.getSigId2()
        print('/upapps/wms/scripts/conf_headend_tun_dst.pl -h ' + deadWms)
        stdin, stdout, stderr, = ssh.exec_command('/upapps/wms/scripts/conf_headend_tun_dst.pl -h ' + deadWms, get_pty=True)
        for line in iter(stdout.readline, ""):
            print(line, end="")
        return

    def confModem(self):
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password2())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        modem = self.getModem()
        print('/upapps/wms/scripts/configure_wms_modem.pl -h ' + modem)
        stdin, stdout, stderr, = ssh.exec_command('/upapps/wms/scripts/configure_wms_modem.pl -h ' + modem, get_pty=True)
        for line in iter(stdout.readline, ""):
            print(line, end="")
        return

    def validateInstall(self):
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password2())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        wms = self.getSigId2()
        print('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_validate.pl -h ' + wms)
        stdin, stdout, stderr, = ssh.exec_command('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_validate.pl -h ' + wms, get_pty=True)
        for line in iter(stdout.readline, ""):
            print(line, end="")
        return

    def revertSpare(self):
        spareName = self.getSpareId2()
        wmsCurrent = self.getWMSCurrent()
        ip = self.getipAddress()
        vx1082 = ('67.206.9.17', 22)
        print("\nAttempting to connect to VX1082...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('67.206.9.17', port=22, username=os.getlogin(), password=self.getVX1082Password3())
            print(os.getlogin() + " connected to VX1082")
        except:
            print("Unable to connect to VX1082, did you enter your password correctly?\nPlease try again.")
            return

        print('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_reconfig.pl -f ' + spareName + ' -s ' + wmsCurrent + ' -i ' + ip)
        stdin, stdout, stderr, = ssh.exec_command('sudo LD_LIBRARY_PATH=$LD_LIBRARY_PATH ORACLE_HOME=$ORACLE_HOME -u ddnm999 /upapps/wms/scripts/wms_reconfig.pl -f ' + spareName + ' -s ' + wmsCurrent + ' -i ' + ip, get_pty=True)
        for line in iter(stdout.readline, ""):
            print(line, end="")
        return


    def wmsLookUp(self):
        url = 'https://home.www.uprr.com/dnm/network-management/secure/#/wms_status/'
        webbrowser.open_new_tab(url)
    
if __name__ == '__main__':
    reconfigApp().run()