Get-Content -Raw C:\Users\$env:Username\NOC_Dashboard\tools\Cisco_Config_Generator\ascii-art.txt                                                                       
$continue = $true

while ($continue) {
    Write-Host "Select which type of device you are converting from:"
    Write-Host "1. C3560"
    Write-Host "2. C3650"
    Write-Host "3. C2800"
    Write-Host "4. C2900"
    Write-Host "5. Exit"
    $device_input = Read-Host -Prompt 'Please select an option'

    switch ($device_input) {
        '1' { 
            Write-Host 'You selected C3560'
            $deviceType = 'C3560' 
        }
        '2' { 
            Write-Host 'You selected C3650'
            $deviceType = 'C3650' 
        }
        '3' { 
            Write-Host 'You selected C2800'
            $deviceType = 'C2800' 
        }
        '4' { 
            Write-Host 'You selected C2900'
            $deviceType = 'C2900' 
        }
        '5' { 
            return # Exit the script
        }
        default { Write-Host 'Invalid selection. Please try again.' }
    }

    do {
        $mnemonic = Read-Host -Prompt 'Enter the 4-letter mnemonic of the site'
        $mnemonic = $mnemonic.ToUpper() # Capitalize the mnemonic
        if ($mnemonic.Length -ne 4 -or $mnemonic -match '[^A-Z]') {
            Write-Host 'Invalid mnemonic. It must be exactly 4 uppercase letters. Please try again.'
        }
    } while ($mnemonic.Length -ne 4 -or $mnemonic -match '[^A-Z]')
    
    do {
        $deviceNumber = Read-Host -Prompt 'Enter the device number (2-3 digits, ex. 001 or 24)'
        if ($deviceNumber -notmatch '^\d{2,3}$') {
            Write-Host 'Invalid device number. It must be 2 or 3 digits. Please try again.'
        }
    } while ($deviceNumber -notmatch '^\d{2,3}$')

    $deviceName = "$mnemonic-$deviceType-$deviceNumber"
    $confirmation = Read-Host -Prompt "Is this your Device Name? $deviceName (Yes/No)"

    if ($confirmation -eq 'Yes') {
        Write-Host "Confirmed Device Name: $deviceName"
        $continue = $false # Exit the loop
    }
}


ssh vx1083 -l $env:Username /upapps/dnm/switch_transform_config/python/switch_transform_config.py -n $deviceName