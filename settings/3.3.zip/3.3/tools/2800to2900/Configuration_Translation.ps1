function Convert_C2800_C2900
{	
    #####Obtaining name of C2800 unit and config file path in VX1082
    clear-host
    Write-Host "Convert C2800 Config to C2900" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ------------------------------
	$env:User_ID = [Environment]::UserName
	$env:input_file = Read-Host "Enter the name of C2800 to be replaced (ex: OMHQ-C2800-53)"
	while ($env:input_file -eq $null) 
    {
      $env:input_file = Read-Host "Enter the name of C2800 to be replaced (ex: OMHQ-C2800-53)"
    }
	$env:input_file_2 = $env:input_file.Trim().ToUpper()
	$env:input_file_3 = $env:input_file_2.ToLower()
	
	if ($env:input_file_3.Contains("spare")) {
    $env:input_file_3 = $env:input_file_3 -replace '[-]', ''
    $env:input_file_3 = $env:input_file_3 + ".cfg"
    } else {
    $env:input_file_3 = $env:input_file_3.split("-")[0] + $env:input_file_3.split("-")[1] + "-" + $env:input_file_3.split("-")[2] + ".cfg"
    }
	
	$env:input_file_path = "/data/rtrconf/configs/$env:input_file_2/$env:input_file_3"
	
	#####Creating name for C2900 config file
	$env:output_file_2 = $env:input_file_3.Replace("c2800","c2900")
   
	#####Obtaining name of IOS image running on the C2900
	clear-host
	Write-Host "Convert C2800 Config to C2900" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ------------------------------
	$env:ios_file = Read-Host "Enter IOS running on C2900 spare (Ex: c2900-universalk9-mz.SPA.154-3.M.bin)"
	while ($env:ios_file -eq $null) 
    {
      $env:ios_file = Read-Host "Enter IOS running on C2900 spare (Ex: c2900-universalk9-mz.SPA.154-3.M.bin)"
    }
	$env:ios_file_2 = $env:ios_file.Trim()
	
	#####Obtaining user password for VX1082"
	clear-host
	Write-Host "Convert C2800 Config to C2900" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ------------------------------
	
	$User_Password = Read-Host "Please enter your password for VX1082" -assecurestring
	while ($User_Password.length -eq 0 ) 
    {
      $User_Password = Read-Host "Please enter your password for VX1082" -assecurestring
    }
	$User_Password_1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($User_Password))
	$User_Password_2 = $User_Password_1.Trim()

		
	#####Populating log
	$env:date=get-date
	
	out-file -append -filepath G:\DCOS\ALL\NOC\Sayuj\2800to2900\log.txt -inputobject "$env:date $env:User_ID $env:output_file_2 $env:input_file_2"

	#####Connecting to VX1082 and running script on server
	clear-host						
    write-host  "Connecting To VX1082...Please Wait" -BackgroundColor Green -ForegroundColor Black
	Write-Host --------------------------------------
    
	C:\'Program Files (x86)'\PuTTY\Plink.exe -ssh VX1082 -l $env:User_ID -pw $User_Password_2  /data/netadmin/scripts/conf_xlate.pl -i $env:input_file_path -o /privdir/$env:User_ID/$env:output_file_2 -b $env:ios_file_2
	
	Write-Host ----------------------------------------------
	Write-Host "If no error shown, C2900 config file has been created & placed on your home directory: /privdir/$env:User_ID/$env:output_file_2" -BackgroundColor Gray -ForegroundColor Black
	Write-Host ----------------------------------------------
		
	Write-Host ""
	$back = read-host -Prompt "You can now press 'Enter' to upload file or type 'YES/Y' to try again::To Exit Just Close Window"
	$back_1 = $back.Trim()
	$back_2 = $back_1.ToLower()
	
    if ($back_2 -eq "yes" -Or $back_2 -eq "y") {
		Convert_C2800_C2900
	} else {
	
	
	#####Editing C2900 config file wtih FileZilla
	start  G:\DCOS\ALL\NOC\FileZilla-3.3.4.1\filezilla.exe ftp://$env:User_ID":"$User_Password_2@VX1082

	
 	#####Checking connection to C2900
	$flag2 = 1
	while ($flag2 -eq 1){
		clear-host
		Write-Host "1. FileZilla is opened in case you need to edit a config file prior to upload it to the spare. If not, go to 3." -BackgroundColor Gray -ForegroundColor Black
		Write-Host "2. Copy spare file to your local hard drive, edit it and transfer file back to your user folder in VX1082." -BackgroundColor Gray -ForegroundColor Black
		Write-Host "3. Config_Upload" -BackgroundColor Gray -ForegroundColor Black
		Write-Host ----------------------------------------------------------------------------------------------------------------
		$env:Spare_Device = Read-Host "Please Enter The IP Address of C2900 Spare"

    	while ($env:Spare_Device -eq $null) 
		{
		$env:Spare_Device = Read-Host "Please Enter The IP Address of C2900 Spare" 
		}
		$env:Spare_Device_2 = $env:Spare_Device.Trim() 
		
		clear-host 
		Write-Host  "Checking Connection Please Wait...."
		Write-Host ------------------------	

		if (Test-Connection $env:Spare_device_2 -count 2 -erroraction silentlycontinue  -Quiet)
		{
	        Write-host "Spare Is Online" -BackgroundColor green -ForegroundColor Black
			Write-Host ------------------------
			read-host -prompt "Press Enter to Continue..."
			$flag2 = 0
		}
		else
		{ 	Clear-Item Variable:User_Password
			Write-host "Spare Is Offline or Incorrect"  -BackgroundColor red -ForegroundColor Black
			Write-Host ------------------------
			read-host -prompt "Press Enter to Try Again."
		}
	}
	
    #####Config file upload.
	clear-host
	
	Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host --------------------------------------
	write-host  "Connecting To VX1082...Please Wait" -BackgroundColor green -ForegroundColor Black
	Write-Host --------------------------------------
    Write-Host --------------------------------------
	
        
	C:\'Program Files (x86)'\PuTTY\Plink.exe -ssh VX1082 -l $env:User_ID -pw $User_Password_2  /data/netadmin/scripts/ciscoput $env:Spare_Device_2 /privdir/$env:User_ID/$env:output_file_2 flash:
	
	Write-Host ""
	Write-Host "Script Complete. Go to 'Copy Configuration file to startup-config' section now."
	Write-Host ""
		
	read-host -Prompt "Press Enter To Try Again :: To Exit Just Close Window"
	}
	Convert_C2800_C2900
}
Convert_C2800_C2900
	
	

	

	
