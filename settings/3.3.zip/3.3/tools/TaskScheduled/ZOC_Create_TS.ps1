Write-Host "Creating Task Scheduled Items for keeping ZOC for AEI Up to Date"
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument '& C:\Users\$env:USERNAME\NOC_Dashboard\tools\ZOC_Update\zoc_update_silent.ps1'
$startTimes = @("8am", "12pm", "4pm", "12am")
$triggers = @()
foreach ( $startTime in $startTimes ) {
    $trigger = New-ScheduledTaskTrigger -Daily -At $startTime
    $triggers += $trigger
    Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "ZOC_Update $startTime"  -Description "Copys master ZOC Directory Locally to PC"
}