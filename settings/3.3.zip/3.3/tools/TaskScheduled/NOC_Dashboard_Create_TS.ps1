Write-Host "Creating Task Scheduled Items for keeping NOC Dashboard Up to Date"
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument '& C:\Users\$env:USERNAME\NOC_Dashboard\nocdashboard_env_setup.ps1'
$startTimes = @("7:30am", "11:30am", "3:30pm", "11:30pm")
$triggers = @()
foreach ( $startTime in $startTimes ) {
    $trigger = New-ScheduledTaskTrigger -Daily -At $startTime
    $triggers += $trigger
    $startTime = $startTime -replace ":", "_"
    Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "NOC_Dashboard_Update $startTime"  -Description "Updates NOC Dashboard Files automatically"
}