$startTimes = @("7:30am", "11:30am", "3:30pm", "11:30pm")

foreach ( $startTime in $startTimes ) {
    $startTime = $startTime -replace ":", "_"
    $taskName = "NOC_Dashboard_Update $startTime"
    $taskExists = Get-ScheduledTask | Where-Object { $_.TaskName -like $taskName }
    if ($taskExists) {
        Write-Host "Task Exists"
    }
    else {
        Write-Host "Task does not Exist"
    }
}