#!C:/Python39/python.exe

'''
Module name: fxe3.py
Author: Kaje Maly
Contact: khmaly@up.com
Desc: This script changes route of FXE Mexico
'''

import telnetlib
import time
import os
import subprocess
import sys
import getpass
import datetime

# Input from User
def user_entry():
    print ("INFO\n----")
    print ("FXE uses two managed routers at UPC - both connect to OMHQ-ASR1000-A. \nFailover requires a manual change to re-point the static routes.\n")

    passwd = getpass.getpass('Please enter current router password: ')
    open_telnet('167.132.254.29', passwd, '23')

# Open telnet connection to devices
def open_telnet(device, password, port):
    ip = device.strip()
    pwd = password
    TELNET_PORT = port
    TELNET_TIMEOUT = 5
    READ_TIMEOUT = 5

    # Checking IP reachability
    print ('\nChecking IP connectivity...')
    # Pinging IP address
    ping_reply = subprocess.call(['ping', '-n', '4', '-w', '3', ip])

    # Checking ping results
    if ping_reply == 0:
        # Connect to device
        try:
            print ("\n\nLogging into OMHQ-ASR1000-A...")
            # Logging into device
            connection = telnetlib.Telnet(ip, TELNET_PORT, TELNET_TIMEOUT)

            connection.read_until(b"Password:", READ_TIMEOUT)
            connection.write(pwd.encode('ascii') + b"\n")
            time.sleep(1)

            # Read the output
            output = connection.read_very_eager()
            output = output.decode()
            if ">" not in output:
                print ("Logging in Failed !! Your password is incorrect.")
                connection.close()
                pause('exit')
                sys.exit()
            else:
                # Entering enable mode
                connection.write(b"enable\n")

                connection.read_very_eager()

                connection.read_until(b"Password: ", READ_TIMEOUT)
                connection.write(pwd.encode('ascii') + b"\n")
                time.sleep(1)

                # Setting terminal length for entire output - no pagination
                connection.write(b"terminal length 0\n")
                time.sleep(1)
                print ("Logging in Successful !!")

                pause("continue")
                os.system('cls')

                print ("Checking current FXE route status...\n")

                # Checking the route for FXE1
                connection.write(b"sho ip route vrf CONTRACTOR 192.168.95.128\n")
                time.sleep(1)

                # Read the output
                FXE1 = connection.read_very_eager()
                FXE1 = FXE1.decode()
                print ("Route Status\n------------")

                # Print Current Route
                if '192.168.95.190' in FXE1:
                    print ("FXE1 is on primary route.")
                else:
                    print ("FXE1 is on backup route.")


                # Checking the route for FXE4
                connection.write(b"sho ip route vrf CONTRACTOR 192.168.95.112\n")
                time.sleep(1)

                # Read the output
                FXE4 = connection.read_very_eager()
                FXE4 = FXE4.decode()
                # Print Current Route
                if '192.168.95.190' in FXE4:
                    print ("FXE4 is on primary route.")
                else:
                    print ("FXE4 is on backup route.")

                # Route Selection
                print ("\n\nChanging Route Options:\n-----------------------")
                print ("1. Change FXE1 and FXE4 to primary route\n2. Change FXE1 and FXE4 to backup route\n3. Cancel and exit\n\n")

                routeSel = input("Route Selection (1, 2 or 3): ")
                routeSel = int(routeSel)

                while routeSel not in (1,2,3):
                    os.system('cls')
                    print ("Illegal selection detected")

                    print ("\nChanging Route Options:\n-----------------------")
                    print ("1. Change FXE1 and FXE4 to primary route\n2. Change FXE1 and FXE4 to backup route\n3. Cancel and exit\n\n")

                    routeSel = input("Route Selection (1, 2 or 3): ")
                    routeSel = int(routeSel)

                pause("continue")
                os.system('cls')

                # Changing route
                if routeSel == 1:
                    print ("You have selected: " + str(routeSel))
                    print ("\nChanging FXE1 and FXE4 to primary route...")

                    # Logging
                    now = datetime.datetime.now()
                    fh = open("log.txt", "a")
                    fh.write(str(now) + " " + os.environ['username'] + " Changed FXE1 and FXE4 to primary route\n")
                    fh.close()

                    connection.write(b"config t\n")
                    time.sleep(1)
                    connection.write(b"no ip route vrf CONTRACTOR 192.168.95.128 255.255.255.240 TenGigabitEthernet2/0/0.3472 192.168.95.170 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"ip route vrf CONTRACTOR 192.168.95.128 255.255.255.240 TenGigabitEthernet1/0/0.2826 192.168.95.190 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"no ip route vrf CONTRACTOR 192.168.95.112 255.255.255.240 TenGigabitEthernet2/0/0.3472 192.168.95.170 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"ip route vrf CONTRACTOR 192.168.95.112 255.255.255.240 TenGigabitEthernet1/0/0.2826 192.168.95.190 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"end\n")
                    connection.read_very_eager()

                    print ("Route change successful !!\n\n")
                elif routeSel == 2:
                    print ("You have selected: " + str(routeSel))
                    print ("\nChanging FXE1 and FXE4 to backup route")

                    # Logging
                    now = datetime.datetime.now()
                    fh = open("log.txt", "a")
                    fh.write(str(now) + " " + os.environ['username'] + " Changed FXE1 and FXE4 to backup route\n")
                    fh.close()

                    connection.write(b"config t\n")
                    time.sleep(1)
                    connection.write(b"no ip route vrf CONTRACTOR 192.168.95.128 255.255.255.240 TenGigabitEthernet1/0/0.2826 192.168.95.190 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"ip route vrf CONTRACTOR 192.168.95.128 255.255.255.240 TenGigabitEthernet2/0/0.3472 192.168.95.170 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"no ip route vrf CONTRACTOR 192.168.95.112 255.255.255.240 TenGigabitEthernet1/0/0.2826 192.168.95.190 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"ip route vrf CONTRACTOR 192.168.95.112 255.255.255.240 TenGigabitEthernet2/0/0.3472 192.168.95.170 20 tag 3300\n")
                    time.sleep(1)
                    connection.write(b"end\n")
                    connection.read_very_eager()

                    print ("Route change successful !!\n\n")
                else:
                    print ("You have selected: " + str(routeSel))
                    print ("\nExiting out...")
                    connection.close()
                    pause("exit")
                    sys.exit()

                # Verifying Current Route
                print ("Verifying FXE route status...\n")

                # Checking the route for FXE1
                time.sleep(3)
                connection.write(b"sho ip route vrf CONTRACTOR 192.168.95.128\n")
                time.sleep(1)

                # Read the output
                FXE1 = connection.read_very_eager()
                FXE1 = FXE1.decode()
                
                #Command for testing output from read function
                #print ("This is the FXE1 Output\n " + FXE1)
                
                print ("Route Status\n------------")

                # Print Current Route
                if '192.168.95.190' in FXE1:
                    print ("FXE1 is on primary route.")
                else:
                    print ("FXE1 is on backup route.")


                # Checking the route for FXE4
                connection.write(b"sho ip route vrf CONTRACTOR 192.168.95.112\n")
                time.sleep(1)

                # Read the output
                FXE4 = connection.read_very_eager()
                FXE4 = FXE4.decode()
                
                #Command for testing output from read function
                # print ("This is the FXE4 Output\n " + FXE4)
                
                # Print Current Route
                if '192.168.95.190' in FXE4:
                    print ("FXE4 is on primary route.")
                else:
                    print ("FXE4 is on backup route.")


                # Closing the connection
                connection.close()

                pause('exit')

        except IOError:
            print ("\n\n\nOops !! Something went wrong.")
    elif ping_reply == 2:
        print ("\n  No response from device %s." % ip)
        pause('exit')
        sys.exit()
    else:
        print ("\n  Ping to the following device has FAILED:", ip)
        pause('exit')
        sys.exit()


def pause(entry):
    input("\n\nPress enter to " + entry + "...")

user_entry()