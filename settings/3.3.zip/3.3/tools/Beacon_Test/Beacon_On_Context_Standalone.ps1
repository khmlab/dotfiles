$ErrorActionPreference = 'silentlycontinue'

$pshost = get-host

$pswindow = $pshost.ui.rawui

$newsize = $pswindow.buffersize

$newsize.height = 100

$newsize.width = 125

$pswindow.buffersize = $newsize


$newsize = $pswindow.windowsize

$newsize.height = 30

$newsize.width = 125

$pswindow.windowsize = $newsize


	clear-host
	Write-Host "Beacon_On" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	$env:User_IDD = [Environment]::UserName
	
	 while ($env:User_IDD -match 'iadm')
 {
 if (test-path -path H:\user_id.txt)
 {
 $env:User_IDD = get-content -path H:\user_id.txt
 }
 else
 {
  $env:User_IDD = Read-Host "Please Enter User ID"
  $env:User_IDD > H:\user_id.txt
  }
  }
    $env:User_IDD = $env:User_IDD.trim()
	
	$env:User_ID = $env:User_IDD.ToLower()
	$env:WIU = $args[0]
	$User_Password = $args[1]
	
	
	$User_Password_3 = $null
	
	
	while ($User_Password3 -eq $null ) 
    {
      $User_Password3 = Read-Host "Please Enter your password for Launchpad" -assecurestring
    }
	$User_Password_2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($User_Password3))
	$User_Password_4 = $User_Password_2.Trim()
	
	
	
	clear-host
	
	Write-Host "Beacon_On" -BackgroundColor Gray -ForegroundColor Black
    Write-Host --------------------------------------
	   
		$env:date=get-date
	

	clear-host						
    write-host  "Connecting To launchpadprd.sos.tla.uprr.com ...Please Wait" -BackgroundColor green -ForegroundColor Black
	Write-Host -------------------------------------
    Write-Host -------------------------------------
        
	C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh -t launchpadprd.sos.tla.uprr.com  -l $env:User_ID -pw $User_Password_4  "ssh dhac004@VX42B7 sh /upapps/ptc/hac/wiutt/prod/kits/scripts/runWIU_TT.sh -w $env:WIU -s 20 -c4 " 
	
	
	Write-Host ------------------
	Write-Host ------------------
	write-host "You're doing a great job on PTC!!.  Remember to stay positive and support your team."  -ForegroundColor yellow
	Write-Host -----------------
		  
	read-host -Prompt "Press Enter To Close"
	