$env:pass = Read-Host 'Please Enter New Password.'
	while ($env:pass -eq $null) 
    {
        $env:pass = Read-Host 'Please Enter New Password.'
    }
	$env:pass2 = $env:pass.Trim()
	
	(get-content C:/software/PNMTj/config/Pnmt.properties) | foreach-object {$_ -replace "Community=(.*)", "Community=$env:pass2"} | set-content C:/software/PNMTj/config/Pnmt.properties
	clear-host
 read-host "Password Updated Press Enter To Exit"
	
	
