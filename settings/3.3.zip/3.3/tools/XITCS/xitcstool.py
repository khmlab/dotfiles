import os
import sys
from rich import print as rprint


# Verifies your os type
OS_TYPE = os.name
# Sets the count modifier to the os type
count = "-n" if OS_TYPE == "nt" else "-c"


def create_ip_list():
    """Creates an ip address list
    return: Return the ip_list
    rtype: list
    """
    ip_list = []
    with open(os.path.join(sys.path[0], "masteriplist.txt"), "r") as file:
        for line in file:
            ip_list.append(line.strip())
    return ip_list


last_distance = 0


def ping_device(ip_list):
    """Ping ip_list and return results
    return: None
    rtype: None
    """
    results_file = open(os.path.join(sys.path[0], "results.txt"), "w")
    for ip in ip_list:
        if "172.23" not in ip:
            if "Concentrate" in ip:
                rprint(f"[bold purple]{ip}[/]")
                continue
            rprint(f"[bold blue]{ip}[/]")
            continue
        response = os.popen(f"ping {ip} {count} 2").read()
        if "Received = 2" and "Approximate" in response:
            rprint(f"[bold green]UP[/] {ip} Ping Successful\n")
            results_file.write(f"UP {ip} Ping Successful" + "\n")
        elif "Received = 1" and "Approximate" in response:
            rprint(f"[bold yellow]UP[/] {ip} Intermittent Ping\n")
            results_file.write(f"UP {ip} Intermittent Ping" + "\n")
        else:
            rprint(f"[bold red]Down {ip} [/]Ping Unsuccessful\n")
            results_file.write(f"Down {ip} Ping Unsuccessful" + "\n")
            traceresponse = os.popen(f"tracert -w 1000 -h 20 {ip}").read()
            rprint(traceresponse)

    results_file.close()


if __name__ == "__main__":
    ping_device(create_ip_list())
