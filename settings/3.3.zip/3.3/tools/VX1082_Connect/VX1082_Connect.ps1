function find_spare {
    clear-host
    Write-Host "FIND_SPARE" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
    $env:User_IDD = [Environment]::UserName
   
    while ($env:User_IDD -match 'iadm') {
        $env:User_IDD = Read-Host "Please Enter User ID"
    }
    $env:User_IDD = $env:User_IDD.trim()
	
    clear-host
	
    $env:User_ID = $env:User_IDD.ToLower()
    $env:SITE_MNENONIC = Read-Host "Please Enter The SITE MNENONIC to Search"
    while ($env:SITE_MNENONIC -eq $null) {
        $env:SITE_MNENONIC = Read-Host "Please Enter The SITE MNENONIC to Search" 
    }
    $env:SITE_MNENONIC_2 = $env:SITE_MNENONIC.Trim() 
	
    clear-host
	
    Write-Host "FIND_SPARE" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	
    $env:User_Password = Read-Host "Please Enter your password for VX1082"
    while ($env:User_Password -eq $null) {
        $env:User_Password = Read-Host "Please Enter your password for VX1082"
    }
    $env:User_Password_2 = $env:User_Password.Trim()
	
	
    clear-host
	
	
  
    Write-host "Opening A List Of Available spare devices for the specified site....Please Wait" -BackgroundColor green -ForegroundColor Black
    Write-Host ------------------------------------
   
    C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh vx1082 -l $env:User_ID -pw $env:User_Password_2 "ls /data/rtrconf/configs/ | grep $env:SITE_MNENONIC_2 -i | grep -i spare"
    $env:date = get-date
    out-file -append -filepath G:\DCOS\All\NOC\Rick\VX1082_Connect\vx1082_log.txt -inputobject "$env:date $env:User_ID FIND_SPARE"
    Write-Host ------------------------------------
    Write-Host ------------------------------------
    read-host -Prompt "Press Enter To Exit"
   
   
    menu
}
   
      
function IOS_Upload {
    clear-host
    Write-Host "IOS_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
    $env:User_IDD = [Environment]::UserName
   
    while ($env:User_IDD -match 'iadm') {
        $env:User_IDD = Read-Host "Please Enter User ID"
    }
    $env:User_IDD = $env:User_IDD.trim()
	
    $env:User_ID = $env:User_IDD.ToLower()
    
    clear-host	
  
    $env:Target_Device = Read-Host "Please Enter The IP Of The Target Device"
    while ($env:Target_Device -eq $null) {
        $env:Target_Device = Read-Host "Please Enter The IP Of The Target Device" 
    }
    $env:Target_Device_2 = $env:Target_Device.Trim() 
	
    if (Test-Connection $env:Target_Device_2 -count 2 -erroraction silentlycontinue  -Quiet)
    {
        clear-host
        Write-host "Host Is Online" -BackgroundColor green -ForegroundColor Black
        Write-Host ------------------------
        read-host -prompt "Press Enter to Continue."
    }
			
    else {
        Write-host "The Host Is Offline or Incorrect"  -BackgroundColor red -ForegroundColor Black
        Write-Host ------------------------
        read-host -prompt "Press Enter to Try Again."
        IOS_upload
    }
	
	
	
    clear-host
    Write-Host "IOS_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	
    $env:Device_Type = Read-Host "Please Enter The Device Model (c2800,C3560...)"
    while ($env:Device_Type -eq $null) {
        $env:Device_Type = Read-Host "Please Enter The Device Model (c2800,C3560...)"
    }
    $env:Device_Type_2 = $env:Device_Type.Trim()
	
	
    clear-host
	
    Write-Host "IOS_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	
    $env:User_Password = Read-Host "Please Enter your password for VX1082"
    while ($env:User_Password -eq $null) {
        $env:User_Password = Read-Host "Please Enter your password for VX1082"
    }
    $env:User_Password_2 = $env:User_Password.Trim()
	
    clear-host
	
	
    Write-Host ------------------------------------
    Write-Host "IOS_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ------------------------------------
    Write-host "Opening A List Of Available IOS Images For The Specified Model....Please Wait" -BackgroundColor green -ForegroundColor Black
    Write-Host ------------------------------------
   
    C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh vx1082 -l $env:User_ID -pw $env:User_Password_2 "ls /data/tftpboot/img/ | grep -i $env:Device_Type_2"
   
    Write-Host ------------------------------------
            
  
    $env:IOS_IMG = Read-Host "Please Enter The IOS Image To Upload From The Provided List"
    while ($env:IOS_IMG -eq $null) {
        $env:IOS_IMG = Read-Host "Please Enter The IOS Image To Upload From The Provided List" 
    }
    $env:IOS_IMG_2 = $env:IOS_IMG.Trim() 
	
    clear-host
	
    Write-Host "IOS_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -------------------------------------
	
    Write-host "You are about to load IOS Image "$env:IOS_IMG_2" To "$env:Target_Device_2"  " -BackgroundColor red -ForegroundColor Black
    Write-Host --------------------------------------
    Write-Host --------------------------------------
    read-host -Prompt "To Continue Press Enter::To Abort Close Window"
    $env:date = get-date
	
    out-file -append -filepath G:\DCOS\All\NOC\Rick\VX1082_Connect\vx1082_log.txt -inputobject "$env:date $env:User_ID $env:IOS_IMG_2 $env:Target_Device_2"

    clear-host						
    write-host  "Loading IOS To Device..Please Wait..." -BackgroundColor green -ForegroundColor Black
    Write-Host --------------------------------------
    Write-Host --------------------------------------
	        
    C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh vx1082 -l $env:User_ID -pw $env:User_Password_2  /data/netadmin/scripts/ciscoput $env:Target_Device_2 /data/tftpboot/img/$env:IOS_IMG_2 flash:
	
    read-host -Prompt "Press Enter To Exit"
    Menu	
}
   
function Manual_Commands {
    clear-host
    Write-Host "Pull From Router Or Switch (run from device)" -BackgroundColor green -ForegroundColor Black
    Write-Host ---------------------------
    Write-Host "Load IOS::  copy ftp://username:password@67.206.9.17//data/tftpboot/img/ios_file.bin flash:"
    Write-Host ---------------------------
    Write-Host "Load Config::  copy ftp://username:password@67.206.9.17//data/rtrconf/configs/spare_device_name/device_config.cfg flash:"
    Write-Host ---------------------------
    Write-Host ---------------------------
    Write-Host "Push To Router Or Switch (run from server)" -BackgroundColor green -ForegroundColor Black
    Write-Host ---------------------------
    Write-Host "./ciscoput device_IP /data/tftpboot/img/ios_file.bin flash:"
    Write-Host ---------------------------
    read-host -Prompt "Press Enter To Exit"
    Menu
}
   
   
   
   
   
   
   
   
   
function Config_Upload {
    clear-host
    Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ---------------------------------

    $env:User_IDD = [Environment]::UserName
	
    while ($env:User_IDD -match 'iadm') {
        $env:User_IDD = Read-Host "Please Enter User ID"
    }
    $env:User_IDD = $env:User_IDD.trim()
	
    clear-host
	
    $env:User_ID = $env:User_IDD.ToLower()
    $env:Spare_Device = Read-Host "Please Enter The IP Of The Spare Device"
    clear-host 
    write-host  "Checking Connection Please Wait...."
    Write-Host ------------------------	
   
			
    while ($env:Spare_Device -eq $null) {
        $env:Spare_Device = Read-Host "Please Enter The IP Of The Spare Device" 
    }
    $env:Spare_Device_2 = $env:Spare_Device.Trim() 
	
    if (Test-Connection $env:Spare_device_2 -count 2 -erroraction silentlycontinue  -Quiet)
    {
        Write-host "Host Is Online" -BackgroundColor green -ForegroundColor Black
        Write-Host ------------------------
        read-host -prompt "Press Enter to Continue."
    }
			
    else {
        Write-host "The Host Is Offline or Incorrect"  -BackgroundColor red -ForegroundColor Black
        Write-Host ------------------------
        read-host -prompt "Press Enter to Try Again."
        Config_upload
    }
    
    clear-host

    Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host ----------------------------------

	
    $env:Failed_Device = Read-Host "Please Enter The Name Of The Failed Device"
    while ($env:Failed_Device -eq $null) {
        $env:Failed_Device = Read-Host "Please Enter The Name Of The Failed Device"
    }
    $env:Failed_Device_2 = $env:Failed_Device.Trim().ToUpper()
	
    clear-host
	
    Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	
    $env:Device_Config = Read-Host "Please Enter The Name Of The Config File"
    while ($env:Device_Config -eq $null) {
        $env:Device_Config = Read-Host "Please Enter The Name Of The Config File"
    }
    $env:Device_Config_2 = $env:Device_Config.Trim()
	
	
    clear-host
	
    Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host -----------------------------------
	
    $env:User_Password = Read-Host "Please Enter your password for VX1082"
    while ($env:User_Password -eq $null) {
        $env:Device_Config = Read-Host "Please Enter your password for VX1082"
    }
    $env:User_Password_2 = $env:User_Password.Trim()
	
    clear-host
	
    Write-Host "Config_Upload" -BackgroundColor Gray -ForegroundColor Black
    Write-Host --------------------------------------
	
    Write-host "You are about to load a config for "$env:Failed_Device_2" on to "$env:Spare_Device_2""  -BackgroundColor red -ForegroundColor Black
    Write-Host --------------------------------------
    Write-Host --------------------------------------
    read-host -Prompt "To Continue Press Enter::To Abort Close Window"
    $env:date = get-date
	
    out-file -append -filepath G:\DCOS\All\NOC\NOC dashboard\3.3\tools\VX1082_Connect\vx1082_log.txt -inputobject "$env:date $env:User_ID $env:Failed_Device_2 $env:Spare_Device_2"

							
    write-host  "Loading Config to Device...Please Wait" -BackgroundColor green -ForegroundColor Black
    Write-Host --------------------------------------
    Write-Host --------------------------------------
	
        
    C:\'Program Files (x86)'\PuTTY\Plink.exe  -ssh vx1082 -l $env:User_ID -pw $env:User_Password_2  /data/netadmin/scripts/ciscoput $env:Spare_Device_2 /data/rtrconf/configs/$env:Failed_Device_2/$env:Device_Config_2 flash:
	
	
    Write-Host --------------------------------------
    Write-Host --------------------------------------
    write-host "Please Remember To Check That The IOS Version Is Up To Date" -BackgroundColor red -ForegroundColor Black
    Write-Host --------------------------------------
    Write-Host --------------------------------------
    Write-host "Please Make Sure Installed HardWare Matches The Desired Application" -BackgroundColor red -ForegroundColor Black
    Write-Host --------------------------------------
	
		  
    read-host -Prompt "Press Enter To Exit"
	
			 
    Menu
   
}
	
Function Menu {
    clear-host
    Write-Host "VX1082_Connect" -BackgroundColor Gray -ForegroundColor Black
    Write-Host "--------------------------------"
    Write-Host "1.) Config Upload"
    Write-Host "2.) IOS Upload"
    Write-Host "3.) FIND SPARE"
    Write-Host "4.) Manual Commands"
    write-host ""
    write-host "0.) Exit" -ForegroundColor Red
    Write-host ""
    Write-Host --------------------------------
    write-host ""
    
    $env:choice = Read-Host 'Enter Selection'
    while ($env:choice -eq $null) {
        $env:choice = Read-Host 'Enter Selection'
    }
    if ($env:choice -match "1") {
        Config_Upload
    }
    elseif ($env:choice -match "2") {
        IOS_Upload
    } 
    elseif ($env:choice -match "3") {
        find_spare
    }
    elseif ($env:choice -match "4") {
        Manual_Commands
    }	 
    elseif ($env:choice -match "0") {
        exit
    }
}

Menu
	
	

	

	
